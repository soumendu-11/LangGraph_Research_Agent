# tools.py
import json
import httpx
from langchain_core.tools import tool
from typing import Dict, Any

from geoscience_agent.config import config

@tool
async def cortex_analyst_retrieval(query: str, semantic_model_name: str = None) -> str:
    """
    Retrieves geoscience data using Cortex Analyst for complex analytical queries.
    Use this for geological data, well logs, production metrics, reservoir properties, or seismic data.
    Handles queries about formations, basins, wells, discoveries, and subsurface analytics.
    Returns structured data including summaries, data tables, and exploration insights.
    
    Args:
        query: The question to ask Cortex Analyst
        semantic_model_name: Required semantic model name (determined by intent router)
    """
    print(f"🔍 Cortex Analyst Query: {query}")
    
    # Semantic model must be provided by intent router
    if not semantic_model_name:
        error_msg = "Semantic model name is required but not provided by intent router"
        print(f"❌ {error_msg}")
        return json.dumps({
            "status": "error",
            "error": error_msg,
            "query": query
        }, indent=2)
    
    model_name = semantic_model_name
    
    # Prepare request payload
    payload = {
        "question": query,
        "semantic_model_name": model_name
    }
    
    try:
        async with httpx.AsyncClient(timeout=config.CORTEX_API_TIMEOUT) as client:
            print(f"📡 Calling Cortex API: {config.CORTEX_API_URL}")
            response = await client.post(config.CORTEX_API_URL, json=payload)
            
            # Don't raise for 400 errors - Cortex Analyst returns 400 with helpful guidance
            if response.status_code == 400:
                data = response.json()
                analyst_response = data.get("analyst_response")
                
                if analyst_response:
                    message = analyst_response.get("message", {})
                    content = message.get("content", [])
                    
                    analyst_text = ""
                    suggestions = []
                    
                    for item in content:
                        if item.get("type") == "text":
                            analyst_text = item.get("text", "")
                        elif item.get("type") == "suggestions":
                            suggestions = item.get("suggestions", [])
                    
                    print(f"✓ Cortex Analyst provided guidance: {len(suggestions)} suggestions")
                    
                    return json.dumps({
                        "status": "analyst_response",
                        "query": query,
                        "analyst_message": analyst_text,
                        "suggestions": suggestions,
                        "results": [],
                        "generated_sql": None
                    }, indent=2)
            
            # For other errors, raise
            response.raise_for_status()
            
            data = response.json()
            
            # Cortex Analyst returns data in analysis.data, not results
            analysis = data.get("analysis", {})
            results = analysis.get("data") or []
            columns = analysis.get("columns") or []
            
            print(f"✓ Cortex Analyst Response received: {len(results)} rows")
            
            # Return structured results
            return json.dumps({
                "status": "success",
                "query": query,
                "generated_sql": data.get("generated_sql"),
                "results": results,
                "columns": columns,
                "queryid": data.get("correlation_id"),
                "total_rows": len(results)
            }, indent=2)
            
    except httpx.TimeoutException:
        error_msg = f"Timeout calling Cortex Analyst API after {CORTEX_API_TIMEOUT}s"
        print(f"⚠️ {error_msg}")
        return json.dumps({
            "status": "error",
            "error": error_msg,
            "error_type": "timeout",
            "error_category": "network",
            "query": query,
            "suggestion": "The API request timed out. Please try again or check your network connection."
        })
        
    except httpx.HTTPStatusError as e:
        status_code = e.response.status_code
        error_text = e.response.text
        
        # Categorize HTTP errors
        if status_code == 401:
            error_type = "authentication_failed"
            error_category = "auth"
            suggestion = "Authentication failed. Please refresh your AWS credentials using 'aws sso login'."
        elif status_code == 403:
            error_type = "forbidden"
            error_category = "auth"
            suggestion = "Access denied. Your AWS credentials may have expired or lack permissions. Run 'aws sso login' to refresh."
        elif status_code == 429:
            error_type = "rate_limit"
            error_category = "api"
            suggestion = "Rate limit exceeded. Please wait a moment and try again."
        elif status_code >= 500:
            error_type = "server_error"
            error_category = "api"
            suggestion = "Cortex Analyst API is experiencing issues. Please try again later."
        else:
            error_type = "http_error"
            error_category = "api"
            suggestion = "An API error occurred. Please try again or contact support."
        
        error_msg = f"HTTP {status_code} from Cortex Analyst: {error_text}"
        print(f"⚠️ {error_msg}")
        
        return json.dumps({
            "status": "error",
            "error": error_msg,
            "error_type": error_type,
            "error_category": error_category,
            "status_code": status_code,
            "query": query,
            "suggestion": suggestion
        })
        
    except httpx.ConnectError as e:
        error_msg = f"Connection error: Cannot reach Cortex Analyst API - {str(e)}"
        print(f"⚠️ {error_msg}")
        return json.dumps({
            "status": "error",
            "error": error_msg,
            "error_type": "connection_error",
            "error_category": "network",
            "query": query,
            "suggestion": "Cannot connect to the API. Check your network connection or VPN status."
        })
        
    except Exception as e:
        error_msg = f"Unexpected error calling Cortex Analyst: {str(e)}"
        error_type = type(e).__name__
        print(f"⚠️ {error_msg}")
        
        # Check if it's an AWS credential error
        if "ExpiredToken" in str(e) or "ExpiredCredentials" in str(e):
            error_category = "auth"
            suggestion = "Your AWS credentials have expired. Run 'aws sso login' to refresh them."
        elif "NoCredentials" in str(e) or "CredentialRetrievalError" in str(e):
            error_category = "auth"
            suggestion = "AWS credentials not found. Run 'aws sso login' to authenticate."
        else:
            error_category = "unknown"
            suggestion = "An unexpected error occurred. Please try again or contact support."
        
        return json.dumps({
            "status": "error",
            "error": error_msg,
            "error_type": error_type,
            "error_category": error_category,
            "query": query,
            "suggestion": suggestion
        })

# Export the list of tools
def get_tools():
    return [cortex_analyst_retrieval]
