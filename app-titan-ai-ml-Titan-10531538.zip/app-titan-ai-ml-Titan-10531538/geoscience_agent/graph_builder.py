"""
LangGraph Workflow Builder
Orchestrates the geoscience agent workflow by wiring nodes together
"""

import json
import time
import uuid
from datetime import datetime
from typing import Dict, Optional

import mlflow
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

from geoscience_agent.config import config
from geoscience_agent.models import HAIKU_CONFIG
from geoscience_agent.nodes import (
    guardrail_check_node,
    initialize_session_node,
    intent_router_node,
    load_json_tool_node,
    multiturn_handler_node,
    save_session_node,
)
from geoscience_agent.state import DiscoveryState
from geoscience_agent.storage import DynamoDBSaver, SessionManager

# Setup State Persistence
# Use DynamoDB in production, MemorySaver for local dev
if config.USE_DYNAMODB:
    checkpointer = DynamoDBSaver(table_name=config.DYNAMODB_TABLE_NAME)
    print(f"✓ Using DynamoDB checkpointer (table: {config.DYNAMODB_TABLE_NAME})")
else:
    checkpointer = MemorySaver()
    print("✓ Using MemorySaver (local development)")


# ==============================================================================
# ROUTING FUNCTIONS
# ==============================================================================

def route_after_guardrail(state: DiscoveryState) -> str:
    """
    Route after guardrail check based on whether request is blocked
    
    Returns:
        'blocked' if question is inappropriate (goes to save_session -> END)
        'allowed' if allowed to proceed (goes to intent_router)
    """
    is_blocked = state.get("is_blocked", False)
    
    if is_blocked:
        print(f"\nRouting to: save_session (blocked)")
        return "blocked"
    else:
        print(f"\nRouting to: intent_router (allowed)")
        return "allowed"


def route_after_intent(state: DiscoveryState) -> str:
    """
    Route after intent classification based on the classified intent
    
    Routes:
        - cortex: analytical_question -> Cortex Analyst API
        - dashboard: dashboard_load -> Dashboard response (skip Cortex)
        - map: map_update -> Map response (skip Cortex)
    """
    intent_route = state.get("intent_route", "cortex")
    print(f"  Routing decision: {intent_route}")
    return intent_route


def dashboard_response_node(state: DiscoveryState) -> DiscoveryState:
    """
    Handle dashboard_load and map_update intents without calling Cortex Analyst
    Returns a structured response indicating dashboard should be loaded
    """
    print(f"\n{'='*60}")
    print("DASHBOARD RESPONSE NODE")
    print(f"{'='*60}")
    
    intent_classification = state.get("intent_classification", {})
    print(f"  Intent classification: {intent_classification}")
    
    # Extract key values from classification
    parameters = intent_classification.get("parameters", {}) if intent_classification else {}
    dashboard_name = parameters.get("workflow_dashboard_name", "unknown")
    field_name = parameters.get("field_name", "")
    route_name = intent_classification.get("route_name", "unknown") if intent_classification else "unknown"
    
    print(f"  Dashboard: {dashboard_name}")
    print(f"  Field Name: {field_name}")
    print(f"  Route: {route_name}")
    
    # Create response for frontend to load dashboard
    if field_name:
        response_summary = f"📊 Loading {dashboard_name} dashboard for field: {field_name}"
    else:
        response_summary = f"📊 Loading {dashboard_name} dashboard"
    
    response = {
        "summary": response_summary,
        "key_insights": [
            {
                "insight": "Dashboard Routing",
                "description": f"Frontend should display the {dashboard_name} dashboard"
            },
            {
                "insight": "Route Information",
                "description": f"Route: {route_name}"
            }
        ],
        "data_table": [],
        "dashboard_name": dashboard_name,
        "field_name": field_name,
        "route_name": route_name
    }
    
    return {
        **state,
        "current_response": response,
        "response_summary": response_summary,
        "status": "dashboard_routed"
    }


# ==============================================================================
# WORKFLOW BUILDER
# ==============================================================================

def build_discovery_workflow(model_id: Optional[str] = None):
    """
    Build and compile the geoscience agent workflow with Cortex Analyst integration.
    
    Workflow structure (7 nodes, 2 conditional routes):
        START 
          |
        initialize_session
          |
        guardrail_check (LLM call)
          |
        [GUARDRAIL ROUTING]
          |-> BLOCKED -> save_session -> END
          |-> ALLOWED -> intent_router (Bedrock classification)
                           |
                        [INTENT ROUTING]
                           |-> cortex: load_json_tool -> multiturn_handler -> save_session -> END
                           |-> dashboard: dashboard_response -> save_session -> END
                           |-> map: dashboard_response -> save_session -> END
    
    Args:
        model_id: Model to use (default: Haiku)
    
    Returns:
        Compiled LangGraph workflow
    """
    print(f"\n{'='*60}")
    print("BUILDING GEOSCIENCE AGENT WORKFLOW")
    print(f"{'='*60}")
    
    workflow = StateGraph(DiscoveryState)
    
    # Add all nodes
    workflow.add_node("initialize_session", initialize_session_node)
    workflow.add_node("guardrail_check", guardrail_check_node)
    workflow.add_node("intent_router", intent_router_node)
    workflow.add_node("load_json_tool", load_json_tool_node)
    workflow.add_node("dashboard_response", dashboard_response_node)
    workflow.add_node("multiturn_handler", multiturn_handler_node)
    workflow.add_node("save_session", save_session_node)
    
    # Define workflow edges
    workflow.add_edge(START, "initialize_session")
    workflow.add_edge("initialize_session", "guardrail_check")
    
    # Conditional routing after guardrail check
    workflow.add_conditional_edges(
        "guardrail_check",
        route_after_guardrail,
        {
            "blocked": "save_session",
            "allowed": "intent_router"
        }
    )
    
    # Conditional routing after intent classification
    workflow.add_conditional_edges(
        "intent_router",
        route_after_intent,
        {
            "cortex": "load_json_tool",      # analytical_question -> Cortex Analyst
            "dashboard": "dashboard_response", # dashboard_load -> Skip Cortex
            "map": "dashboard_response"        # map_update -> Skip Cortex (reuse dashboard for now)
        }
    )
    
    # Cortex path: load_json_tool -> multiturn_handler
    workflow.add_edge("load_json_tool", "multiturn_handler")
    
    # Dashboard path: dashboard_response -> save_session (skip multiturn)
    workflow.add_edge("dashboard_response", "save_session")
    
    # Final steps: multiturn_handler -> save_session -> END
    workflow.add_edge("multiturn_handler", "save_session")
    workflow.add_edge("save_session", END)
    
    # Compile with checkpointer for state persistence
    app = workflow.compile(checkpointer=checkpointer)
    
    persistence_backend = "DynamoDB" if config.USE_DYNAMODB else "MemorySaver (local)"
    print("✓ Workflow compiled successfully")
    print(f"  Nodes: 7 (initialize_session, guardrail, intent_router, load_json_tool, dashboard_response, multiturn, save_session)")
    print(f"  Conditional routes: 2 (guardrail, intent)")
    print(f"  State Persistence: {persistence_backend}")

    print(f"  Guardrail: Haiku-based content moderation")
    print(f"  Intent Router: Bedrock Sonnet + route_registry.json")
    print(f"  Data Retrieval: Cortex Analyst API (analytical_question only)")
    print(f"  Response: Deterministic + G-Eval scoring (cortex path) | Dashboard routing (dashboard/map path)")
    
    return app


# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

def query_discoveries(
    request: str,
    session_id: Optional[str] = None,
    metadata: Optional[Dict] = None
) -> Dict:
    """
    Convenience function to query discoveries with the geoscience agent
    
    Args:
        request: The discovery query/request
        session_id: Existing session ID or None for new session
        metadata: Optional metadata for Cortex Analyst/data API parameters
    
    Returns:
        Dict containing the final state with response
    """
    # Set MLflow experiment
    mlflow.set_experiment(config.MLFLOW_EXPERIMENT_NAME)
    
    # Start MLflow run for complete observability
    with mlflow.start_run():
        start_time = time.time()
        
        # Log input parameters
        mlflow.log_param("request", request[:500])  # Truncate long requests
        mlflow.log_param("session_id", session_id or "new_session")
        
        if metadata:
            mlflow.log_param("metadata", json.dumps(metadata))
        
        # Build workflow
        workflow = build_discovery_workflow()
        
        # Determine turn number
        if session_id:
            sm = SessionManager()
            session = sm.load_session(session_id)
            turn_number = len(session.get("conversation_history", [])) + 1 if session else 1
        else:
            turn_number = 1
        
        mlflow.log_param("turn_number", turn_number)
        
        # Generate unique thread_id for new sessions
        if session_id:
            thread_id = session_id
        else:
            thread_id = str(uuid.uuid4())
            session_id = thread_id
        
        # Configure checkpointer with thread_id
        checkpoint_config = {"configurable": {"thread_id": thread_id}}
        
        # Check if this is a continuation (checkpointer has existing state)
        existing_state = workflow.get_state(checkpoint_config)
        
        if existing_state and existing_state.values:
            # Continuing existing conversation - only pass new data
            print(f"Continuing conversation with thread_id: {thread_id}")
            initial_state = {
                "current_request": request,
                "metadata": metadata,
                "turn_number": turn_number,
            }
        else:
            # New conversation - initialize full state
            print(f"Starting new conversation with thread_id: {thread_id}")
            initial_state = {
                "session_id": session_id,
                "thread_id": thread_id,
                "current_request": request,
                "metadata": metadata,
                "turn_number": turn_number,
                "model_id": HAIKU_CONFIG["model_id"],
                "conversation_history": [],
                "messages": [],
                "is_blocked": False,
                "status": "initialized",
                "error": None,
                "timestamp": datetime.now().isoformat()
            }
        
        # Execute workflow with checkpointer
        result = workflow.invoke(initial_state, config=checkpoint_config)
        
        # Calculate execution time
        execution_time = time.time() - start_time
        mlflow.log_metric("execution_time_seconds", execution_time)
        
        # Log guardrail results
        is_blocked = result.get("is_blocked", False)
        mlflow.log_param("is_blocked", is_blocked)
        
        if is_blocked:
            guardrail_check = result.get("guardrail_check", {})
            mlflow.log_param("block_category", guardrail_check.get("category", "unknown"))
            mlflow.log_param("block_reason", guardrail_check.get("reason", "unknown"))
            mlflow.log_metric("blocked", 1)
        else:
            mlflow.log_metric("blocked", 0)
            
            # Log intent routing
            intent_route = result.get("routing_path") or result.get("intent_route", "unknown")
            mlflow.log_param("intent_route", intent_route)
            
            # Log classification results
            if result.get("classification_confidence"):
                mlflow.log_metric("classification_confidence", result["classification_confidence"])
            
            if result.get("classification_scores"):
                scores = result["classification_scores"]
                for key, value in scores.items():
                    if isinstance(value, (int, float)):
                        mlflow.log_metric(f"classification_{key}", value)
            
            # Log matched entry details
            matched_entry = result.get("matched_json_entry", {})
            if matched_entry:
                mlflow.log_param("matched_question", matched_entry.get("question", "unknown")[:200])
                if "id" in matched_entry:
                    mlflow.log_param("matched_entry_id", matched_entry["id"])
            
            # Log G-Eval evaluation scores
            eval_scores = result.get("evaluation_scores", {})
            if eval_scores:
                # Log individual metrics
                for metric in ["coherence", "consistency", "fluency", "relevance", "groundedness"]:
                    if metric in eval_scores:
                        mlflow.log_metric(f"g_eval_{metric}", eval_scores[metric])
                
                # Log overall score
                if "overall_score" in eval_scores:
                    mlflow.log_metric("g_eval_overall", eval_scores["overall_score"])
                
                # Log evaluation metadata
                eval_metadata = eval_scores.get("evaluation_metadata", {})
                if eval_metadata:
                    mlflow.log_param("evaluator_model", eval_metadata.get("evaluator_model", "unknown"))
                    if "usage" in eval_metadata:
                        usage = eval_metadata["usage"]
                        mlflow.log_metric("eval_input_tokens", usage.get("input_tokens", 0))
                        mlflow.log_metric("eval_output_tokens", usage.get("output_tokens", 0))
            
            # Log response summary
            response_summary = result.get("response_summary")
            if response_summary:
                mlflow.log_param("response_summary", response_summary[:500])  # Truncate
            
            # Log response structure
            current_response = result.get("current_response", {})
            if current_response:
                mlflow.log_param("has_data_table", bool(current_response.get("data_table")))
                mlflow.log_param("has_key_insights", bool(current_response.get("key_insights")))
                
                if current_response.get("data_table"):
                    mlflow.log_metric("data_table_rows", len(current_response["data_table"]))
                if current_response.get("key_insights"):
                    mlflow.log_metric("key_insights_count", len(current_response["key_insights"]))
            
            # Log session continuity
            final_session_id = result.get("session_id")
            if final_session_id:
                mlflow.log_param("final_session_id", final_session_id)
        
        # Log workflow status
        mlflow.log_param("workflow_status", result.get("status", "unknown"))
        
        print(f"✓ MLflow run logged: execution_time={execution_time:.2f}s, blocked={is_blocked}")
        
        return result


__all__ = ['build_discovery_workflow', 'query_discoveries']
