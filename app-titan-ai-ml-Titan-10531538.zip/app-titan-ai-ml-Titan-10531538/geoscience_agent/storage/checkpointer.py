# dynamodb_checkpointer.py
import json
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

import boto3
from botocore.exceptions import ClientError
from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint, CheckpointMetadata

from geoscience_agent.config import config


class DynamoDBSaver(BaseCheckpointSaver):
    """
    DynamoDB-backed checkpointer for LangGraph state persistence.
    Stores conversation state in DynamoDB for production use.
    """
    
    def __init__(self, table_name: Optional[str] = None):
        """
        Initialize DynamoDB checkpointer.
        
        Args:
            table_name: Name of the DynamoDB table. If None, uses config.DYNAMODB_TABLE_NAME.
        """
        self.table_name = table_name or config.DYNAMODB_TABLE_NAME
        
        # Initialize DynamoDB client
        dynamodb = boto3.resource('dynamodb', region_name=config.AWS_REGION)
        self.table = dynamodb.Table(self.table_name)
        
        print(f"✓ DynamoDB checkpointer initialized with table: {self.table_name}")
    
    def put(self, config: Dict[str, Any], checkpoint: Checkpoint, metadata: Dict[str, Any], new_versions: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Save checkpoint to DynamoDB.
        
        Args:
            config: Configuration containing thread_id
            checkpoint: The checkpoint data to save
            metadata: Additional metadata
            new_versions: Optional new version information (for compatibility)
            
        Returns:
            Dictionary with the saved configuration
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            raise ValueError("thread_id is required in config")
        
        try:
            # Serialize checkpoint data
            item = {
                "thread_id": thread_id,
                "checkpoint_id": checkpoint.get("id", datetime.utcnow().isoformat()),
                "checkpoint_data": json.dumps(checkpoint),
                "metadata": json.dumps(metadata) if metadata else "{}",
                "created_at": datetime.utcnow().isoformat(),
                "ttl": int(datetime.utcnow().timestamp()) + (30 * 24 * 60 * 60)  # 30 days TTL
            }
            
            self.table.put_item(Item=item)
            print(f"✓ Checkpoint saved for thread: {thread_id}")
            
            return config
            
        except ClientError as e:
            print(f"✗ Error saving checkpoint: {e.response['Error']['Message']}")
            raise
    
    def get(self, config: Dict[str, Any]) -> Optional[Checkpoint]:
        """
        Retrieve checkpoint from DynamoDB.
        
        Args:
            config: Configuration containing thread_id
            
        Returns:
            The checkpoint data or None if not found
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return None
        
        try:
            response = self.table.get_item(Key={"thread_id": thread_id})
            
            if "Item" in response:
                checkpoint_data = json.loads(response["Item"]["checkpoint_data"])
                print(f"✓ Checkpoint loaded for thread: {thread_id}")
                return checkpoint_data
            else:
                print(f"○ No checkpoint found for thread: {thread_id}")
                return None
                
        except ClientError as e:
            print(f"✗ Error retrieving checkpoint: {e.response['Error']['Message']}")
            return None
    
    def get_tuple(self, config: Dict[str, Any]) -> Optional[Tuple[Checkpoint, CheckpointMetadata]]:
        """
        Retrieve checkpoint tuple (checkpoint, metadata) from DynamoDB.
        Required by BaseCheckpointSaver interface.
        
        Args:
            config: Configuration containing thread_id
            
        Returns:
            Tuple of (checkpoint, metadata) or None if not found
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return None
        
        try:
            response = self.table.get_item(Key={"thread_id": thread_id})
            
            if "Item" in response:
                item = response["Item"]
                checkpoint_data = json.loads(item["checkpoint_data"])
                metadata = json.loads(item.get("metadata", "{}"))
                print(f"✓ Checkpoint tuple loaded for thread: {thread_id}")
                return (checkpoint_data, metadata)
            else:
                print(f"○ No checkpoint found for thread: {thread_id}")
                return None
                
        except ClientError as e:
            print(f"✗ Error retrieving checkpoint tuple: {e.response['Error']['Message']}")
            return None
    
    def list(self, config: Dict[str, Any]) -> list:
        """
        List all checkpoints for a thread.
        
        Args:
            config: Configuration containing thread_id
            
        Returns:
            List of checkpoints
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return []
        
        try:
            response = self.table.query(
                KeyConditionExpression="thread_id = :tid",
                ExpressionAttributeValues={":tid": thread_id}
            )
            return response.get("Items", [])
            
        except ClientError as e:
            print(f"✗ Error listing checkpoints: {e.response['Error']['Message']}")
            return []
