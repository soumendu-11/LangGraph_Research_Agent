"""
Centralized Configuration Management
Loads environment-specific settings from environment variables with sensible defaults
"""

import os
from pathlib import Path
from typing import Optional


class Config:
    """Centralized configuration for geoscience agent"""
    
    # ============================================================================
    # ENVIRONMENT
    # ============================================================================
    ENVIRONMENT = os.getenv("DEPLOYMENT_ENV", "local")  # local, production, staging
    IS_PRODUCTION = ENVIRONMENT == "production"
    IS_LOCAL = ENVIRONMENT == "local"
    
    # ============================================================================
    # AWS CONFIGURATION
    # ============================================================================
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
    
    # ============================================================================
    # BEDROCK MODEL CONFIGURATION
    # ============================================================================
    # Default model IDs
    BEDROCK_HAIKU_MODEL_ID = os.getenv(
        "BEDROCK_HAIKU_MODEL_ID",
        "anthropic.claude-3-haiku-20240307-v1:0"
    )
    BEDROCK_SONNET_MODEL_ID = os.getenv(
        "BEDROCK_SONNET_MODEL_ID",
        "us.anthropic.claude-sonnet-4-20250514-v1:0"
    )
    # Default model to use (can be overridden per request)
    BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", BEDROCK_HAIKU_MODEL_ID)
    
    # ============================================================================
    # CORTEX ANALYST API CONFIGURATION
    # ============================================================================
    CORTEX_API_URL = os.getenv(
        "CORTEX_API_URL",
        "https://dev-api.titan.spglobal.com/spge-titan-api-stage/titan-data-products/ask-analyst"
    )
    CORTEX_API_TIMEOUT = int(os.getenv("CORTEX_API_TIMEOUT", "60"))
    
    # ============================================================================
    # MLFLOW CONFIGURATION
    # ============================================================================
    # Use different MLflow URLs for local vs production
    if IS_LOCAL:
        MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://mlflow:5000")
    else:
        MLFLOW_TRACKING_URI = os.getenv(
            "MLFLOW_TRACKING_URI",
            "https://dev-api.titan.spglobal.com/spge-titan-api-stage/mlflow"
        )
    
    MLFLOW_EXPERIMENT_NAME = os.getenv("MLFLOW_EXPERIMENT_NAME", "Discovery_Workflow")
    
    # ============================================================================
    # DYNAMODB CONFIGURATION
    # ============================================================================
    USE_DYNAMODB = os.getenv("USE_DYNAMODB", "false").lower() == "true"
    DYNAMODB_TABLE_NAME = os.getenv(
        "DYNAMODB_TABLE_NAME",
        "spge-titan-langgraph-checkpoints" if IS_PRODUCTION else "langgraph_checkpoints"
    )
    
    # ============================================================================
    # SESSION MANAGEMENT
    # ============================================================================
    SESSIONS_DIR = os.getenv("SESSIONS_DIR", "sessions")
    
    # ============================================================================
    # FILE PATHS (relative to geoscience_agent directory)
    # ============================================================================
    # Base directory for data files
    BASE_DIR = Path(__file__).parent
    DATA_DIR = BASE_DIR / "data"
    PROMPTS_DIR = BASE_DIR / "prompts"
    
    # Specific data files
    ROUTE_REGISTRY_FILE = os.getenv(
        "ROUTE_REGISTRY_FILE",
        str(DATA_DIR / "route_registry.json")
    )
    
    # Prompt files
    GUARDRAIL_PROMPT_FILE = os.getenv(
        "GUARDRAIL_PROMPT_FILE",
        str(PROMPTS_DIR / "guardrail_prompt.txt")
    )
    INTENT_ROUTER_PROMPT_FILE = os.getenv(
        "INTENT_ROUTER_PROMPT_FILE",
        str(PROMPTS_DIR / "intent_router_prompt.txt")
    )
    GEOSCIENCE_DOMAIN_PROMPT_FILE = os.getenv(
        "GEOSCIENCE_DOMAIN_PROMPT_FILE",
        str(PROMPTS_DIR / "geoscience_domain_prompt.md")
    )
    
    # ============================================================================
    # LOGGING
    # ============================================================================
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
    
    # ============================================================================
    # API CONFIGURATION
    # ============================================================================
    API_HOST = os.getenv("API_HOST", "0.0.0.0")
    API_PORT = int(os.getenv("API_PORT", "8000"))
    API_WORKERS = int(os.getenv("API_WORKERS", "1"))
    
    # ============================================================================
    # CORS CONFIGURATION
    # ============================================================================
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
    
    @classmethod
    def get_config_summary(cls) -> dict:
        """Get a summary of current configuration (for debugging)"""
        return {
            "environment": cls.ENVIRONMENT,
            "aws_region": cls.AWS_REGION,
            "bedrock_model_id": cls.BEDROCK_MODEL_ID,
            "cortex_api_url": cls.CORTEX_API_URL,
            "mlflow_tracking_uri": cls.MLFLOW_TRACKING_URI,
            "use_dynamodb": cls.USE_DYNAMODB,
            "dynamodb_table_name": cls.DYNAMODB_TABLE_NAME,
            "sessions_dir": cls.SESSIONS_DIR,
            "log_level": cls.LOG_LEVEL,
        }
    
    @classmethod
    def validate_config(cls) -> list:
        """Validate configuration and return list of warnings/errors"""
        warnings = []
        
        # Check if critical files exist
        if not Path(cls.ROUTE_REGISTRY_FILE).exists():
            warnings.append(f"Route registry file not found: {cls.ROUTE_REGISTRY_FILE}")
        
        if not Path(cls.DISCOVERIES_FILE).exists():
            warnings.append(f"Discoveries file not found: {cls.DISCOVERIES_FILE}")
        
        # Check environment-specific settings
        if cls.IS_PRODUCTION and not cls.USE_DYNAMODB:
            warnings.append("Production environment should use DynamoDB for checkpointing")
        
        return warnings


# Create a singleton instance for easy importing
config = Config()


# Convenience exports
__all__ = [
    'Config',
    'config',
]
