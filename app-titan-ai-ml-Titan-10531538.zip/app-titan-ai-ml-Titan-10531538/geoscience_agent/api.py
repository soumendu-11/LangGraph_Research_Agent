# api.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, AsyncGenerator, Dict, Any
import json
import asyncio
from datetime import datetime
import sys
import os

from geoscience_agent.config import config
from geoscience_agent.graph_builder import build_discovery_workflow, query_discoveries
from geoscience_agent.integrations import cortex_analyst_retrieval
from geoscience_agent.integrations.cortex_analyst import get_tools
from geoscience_agent.models import HAIKU_CONFIG, SONNET_45_CONFIG
import mlflow

app = FastAPI(
    title="Geoscience LangGraph Agent API",
    description="Enterprise geoscience analytics powered by LangGraph, AWS Bedrock, MLflow, and DynamoDB",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request Model
class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=5000, description="User query to process")
    thread_id: str = Field(..., min_length=1, max_length=100, description="Thread ID for conversation context")
    user_id: Optional[str] = Field(None, max_length=100, description="User identifier")
    metadata: Optional[dict] = Field(None, description="Additional metadata")


# Discovery Workflow Request Model (v8_org)
class DiscoveryQueryRequest(BaseModel):
    request: str = Field(..., min_length=1, max_length=5000, description="Discovery query")
    session_id: Optional[str] = Field(None, max_length=100, description="Session ID for multi-turn conversations")
    metadata: Optional[dict] = Field(None, description="Additional metadata for Cortex Analyst API or data API parameters")


# Discovery Response Model
class DiscoveryResponse(BaseModel):
    status: str
    session_id: str
    is_blocked: bool
    response_summary: Optional[str] = None
    current_response: Optional[Dict[Any, Any]] = None
    evaluation_scores: Optional[Dict[str, float]] = None
    guardrail_check: Optional[Dict[str, Any]] = None
    routing_path: Optional[str] = None
    timestamp: str


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint for ECS/Fargate"""
    return {
        "status": "healthy",
        "service": "geoscience-langgraph-agent",
        "timestamp": datetime.utcnow().isoformat()
    }


# Configuration endpoint
@app.get("/config")
async def get_config():
    """
    Get current configuration settings (for debugging)
    Returns environment-aware configuration
    """
    config_summary = config.get_config_summary()
    warnings = config.validate_config()
    
    return {
        "config": config_summary,
        "warnings": warnings if warnings else None,
        "timestamp": datetime.utcnow().isoformat()
    }


# ============================================================
# DISCOVERY WORKFLOW ENDPOINT
# Current: 7 nodes, 2 conditional routes (guardrail, intent)
# START → initialize_session → guardrail_check (LLM)
#    → [BLOCKED] → save_session → END
#    → [ALLOWED] → intent_router (Bedrock classification)
#       → [analytical_question] → load_json_tool → multiturn_handler → save_session → END
#       → [dashboard_load] → dashboard_response → save_session → END
#       → [map_update] → dashboard_response → save_session → END
# ============================================================

@app.post("/discovery/query")
async def discovery_query(request: DiscoveryQueryRequest):
    """
    Execute discovery workflow with guardrail, intent classification, and conditional routing.
    
    Current Workflow (7 nodes, 2 conditional routes):
    START → initialize_session → guardrail_check (LLM)
      → [BLOCKED] → save_session → END
      → [ALLOWED] → intent_router (Bedrock Sonnet classification)
        → [analytical_question] → load_json_tool (Cortex Analyst) → multiturn_handler → save_session → END
        → [dashboard_load] → dashboard_response → save_session → END
        → [map_update] → dashboard_response → save_session → END
    
    Intents:
    - analytical_question: Complex queries requiring Cortex Analyst API + G-Eval
    - dashboard_load: Field/reservoir dashboard routing (skips Cortex)
    - map_update: Map layer updates (skips Cortex)
    
    Returns:
    - SSE stream with workflow steps, intent classification, and final response
    
    Features:
    - Streaming with Server-Sent Events (SSE)
    - Multi-turn conversation support
    - Real-time step-by-step updates
    - MLflow logging
    """
    async def event_generator() -> AsyncGenerator[str, None]:
        try:
            # START
            yield f"data: {json.dumps({'type': 'start', 'step': 'START', 'message': 'Initializing discovery workflow', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            await asyncio.sleep(0.1)
            
            # STEP 1: initialize_session
            yield f"data: {json.dumps({'type': 'step', 'step': 'initialize_session', 'message': 'Creating/resuming session', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            await asyncio.sleep(0.1)
            
            # STEP 2: guardrail_check
            yield f"data: {json.dumps({'type': 'step', 'step': 'guardrail_check', 'message': 'LLM content filtering (Haiku)', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            await asyncio.sleep(0.1)
            
            # Clean up session_id from Swagger UI defaults
            valid_session_id = request.session_id if request.session_id and request.session_id.strip() else None
            
            # Execute full workflow in thread pool to avoid blocking async event loop
            result = await asyncio.to_thread(
                query_discoveries,
                request=request.request,
                session_id=valid_session_id,
                metadata=request.metadata
            )
            
            # Check if BLOCKED
            if result.get('is_blocked'):
                yield f"data: {json.dumps({'type': 'blocked', 'step': 'BLOCKED', 'category': result.get('guardrail_check', {}).get('category'), 'reason': result.get('guardrail_check', {}).get('reason'), 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                # save_session
                yield f"data: {json.dumps({'type': 'step', 'step': 'save_session', 'message': 'Saving blocked session', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                # END
                yield f"data: {json.dumps({'type': 'end', 'step': 'END', 'session_id': result.get('session_id'), 'is_blocked': True, 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            
            else:
                # ALLOWED path
                # STEP 3: intent_router
                intent_route = result.get('intent_route', 'cortex')
                intent_classification = result.get('intent_classification', {})
                classified_intent = intent_classification.get('intent', 'unknown')
                
                yield f"data: {json.dumps({'type': 'step', 'step': 'intent_router', 'message': 'Intent classification', 'intent': classified_intent, 'route': intent_route, 'timestamp': datetime.utcnow().isoformat()})}\\n\\n"
                await asyncio.sleep(0.1)
                
                # STEP 4: Route-specific processing
                if intent_route == "dashboard":
                    yield f"data: {json.dumps({'type': 'step', 'step': 'dashboard_response', 'message': 'Dashboard load (skip Cortex)', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                    # Dashboard goes directly to save_session, skip multiturn_handler
                elif intent_route == "map":
                    yield f"data: {json.dumps({'type': 'step', 'step': 'map_response', 'message': 'Map update (skip Cortex)', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                    # Map goes directly to save_session, skip multiturn_handler
                else:
                    # cortex route
                    yield f"data: {json.dumps({'type': 'step', 'step': 'cortex_analyst_retrieval', 'message': 'Calling Cortex Analyst tool', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                    
                    # STEP 5: multiturn_handler (only for cortex route)
                    yield f"data: {json.dumps({'type': 'step', 'step': 'multiturn_handler', 'message': 'Deterministic response + G-Eval', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                
                # Response with evaluation scores and error details
                response_data = {
                    'type': 'response',
                    'response': result.get('current_response'),
                    'response_summary': result.get('response_summary'),
                    'evaluation_scores': result.get('evaluation_scores'),
                    'intent_route': intent_route,
                    'timestamp': datetime.utcnow().isoformat()
                }
                
                # Add error details if present
                if result.get('error_type'):
                    response_data['error_details'] = {
                        'error_type': result.get('error_type'),
                        'error_category': result.get('error_category'),
                        'error_suggestion': result.get('error_suggestion')
                    }
                
                yield f"data: {json.dumps(response_data)}\n\n"
                await asyncio.sleep(0.1)
                
                # STEP 6
                # STEP 6: g_eval (optional)
                if result.get('evaluation_scores'):
                    yield f"data: {json.dumps({'type': 'step', 'step': 'g_eval', 'message': 'LLM verification', 'scores': result.get('evaluation_scores'), 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                
                # STEP 7: save_session
                yield f"data: {json.dumps({'type': 'step', 'step': 'save_session', 'message': 'Persisting to DynamoDB', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                # END
                yield f"data: {json.dumps({'type': 'end', 'step': 'END', 'session_id': result.get('session_id'), 'is_blocked': False, 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            
        except Exception as e:
            import traceback
            error_details = {
                "type": "error",
                "error": str(e),
                "error_type": type(e).__name__,
                "traceback": traceback.format_exc(),
                "timestamp": datetime.utcnow().isoformat()
            }
            yield f"data: {json.dumps(error_details)}\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


# ============================================================
# CONVERSATION HISTORY & TOOLS ENDPOINTS
# ============================================================

# Get conversation history endpoint
@app.get("/conversations/{thread_id}")
async def get_conversation_history(thread_id: str):
    """Retrieve conversation history for a given thread."""
    try:
        # This is a placeholder - implement actual history retrieval
        return {
            "status": "success",
            "thread_id": thread_id,
            "message": "History retrieval not yet implemented. Use checkpointer.get_tuple(config)"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# List available tools endpoint
@app.get("/tools")
async def list_tools():
    """List all available geoscience agent tools"""
    tools = get_tools()
    tool_list = [
        {
            "name": tool.name,
            "description": tool.description,
        }
        for tool in tools
    ]
    
    return {
        "status": "success",
        "tools": tool_list,
        "count": len(tool_list)
    }


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "service": "Geoscience LangGraph Agent API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "health": "/health",
            "discovery": "/discovery/query (POST - SSE streaming with state management)",
            "conversations": "/conversations/{thread_id} (GET - conversation history)",
            "tools": "/tools",
            "docs": "/docs"
        },
        "discovery_workflow": {
            "endpoint": "/discovery/query",
            "method": "POST",
            "description": "Complete discovery agent with multi-turn conversations and state persistence",
            "flow": "START → initialize_session → guardrail_check → [BLOCKED/ALLOWED] → intent_router → cortex_analyst_retrieval → multiturn_handler → save_session → END",
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
