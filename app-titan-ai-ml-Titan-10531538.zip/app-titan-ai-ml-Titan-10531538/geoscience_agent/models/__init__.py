"""
Models Package - LLM and Bedrock Interactions

This package contains all AWS Bedrock model integrations:
- configs: Model configurations (Haiku, Sonnet)
- intent_router: Bedrock-based intent classification
- evaluator: G-Eval implementation for response quality
- guardrail: Content moderation and policy validation
"""

from .configs import DEFAULT_MODEL, HAIKU_CONFIG, SONNET_45_CONFIG
from .evaluator import HaikuEvaluator
from .guardrail import HaikuGuardrail
from .intent_router import BedrockIntentRouter

__all__ = [
    'DEFAULT_MODEL',
    'HAIKU_CONFIG',
    'SONNET_45_CONFIG',
    'HaikuEvaluator',
    'HaikuGuardrail',
    'BedrockIntentRouter',
]
