"""
AWS Bedrock Model Configurations
Haiku and Sonnet model settings for LangGraph workflow

Note: Model IDs are now centralized in geoscience_agent.config
This file maintains backward compatibility for model configuration dictionaries
"""

from geoscience_agent.config import config

# Haiku Configuration - Fast, cost-effective model
HAIKU_CONFIG = {
    "model_id": config.BEDROCK_HAIKU_MODEL_ID,
    "max_tokens": 4096,
    "temperature": 0.0,
    "top_k": 1,
    "top_p": 0.999,
    "anthropic_version": "bedrock-2023-05-31",
    "use_cases": [
        "query_generation",
        "response_evaluation",
        "g_eval_scoring"
    ],
    "cost_per_1k_tokens": {
        "input": 0.00025,
        "output": 0.00125
    }
}

# Sonnet 4.5 Configuration - High capability model
SONNET_45_CONFIG = {
    "model_id": config.BEDROCK_SONNET_MODEL_ID,
    "max_tokens": 4096,
    "temperature": 0.0,
    "top_k": 1,
    "top_p": 0.999,
    "anthropic_version": "bedrock-2023-05-31",
    "use_cases": [
        "complex_reasoning",
        "detailed_analysis"
    ],
    "cost_per_1k_tokens": {
        "input": 0.003,
        "output": 0.015
    }
}

# Default model for workflow (points to config)
DEFAULT_MODEL = config.BEDROCK_MODEL_ID

__all__ = ['HAIKU_CONFIG', 'SONNET_45_CONFIG', 'DEFAULT_MODEL']