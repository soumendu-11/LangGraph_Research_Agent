"""
LLM Intent Router Module
Uses Claude Haiku to classify user queries into intent categories
and determine which JSON data file should be loaded.

Routes:
  - "discovery"    -> data/discoveries.json  (discovery data queries)
"""

import json
import boto3
from typing import Dict, Optional

from geoscience_agent.config import config


class LLMIntentRouter:
    """
    LLM-based intent router using Claude Haiku.
    Classifies user questions to decide which JSON data source to use.
    Loads prompt from prompts/intent_router_prompt.txt.
    """

    def __init__(self, model_id: Optional[str] = None):
        self.model_id = model_id or config.BEDROCK_HAIKU_MODEL_ID
        self.bedrock = boto3.client('bedrock-runtime', region_name=config.AWS_REGION, verify=False)
        self.router_prompt = self._load_prompt()

    @staticmethod
    def _load_prompt() -> str:
        """Load intent router prompt from prompts/ folder."""
        with open(config.INTENT_ROUTER_PROMPT_FILE, 'r', encoding='utf-8') as f:
            return f.read()

    def classify(self, question: str) -> Dict:
        """
        Classify a user question into an intent category.

        Args:
            question: The user's question text

        Returns:
            Dict with keys: route ("discovery"), reason
        """
        print(f"\n{'='*60}")
        print("LLM INTENT ROUTER")
        print(f"{'='*60}")
        print(f"Question: {question}")

        formatted_prompt = self.router_prompt.format(question=question)

        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 256,
            "temperature": 0.0,
            "top_k": 1,
            "messages": [
                {"role": "user", "content": formatted_prompt}
            ]
        })

        try:
            response = self.bedrock.invoke_model(
                modelId=self.model_id,
                body=body,
                contentType='application/json',
                accept='application/json'
            )

            response_body = json.loads(response['body'].read())
            result_text = response_body.get("content", [{}])[0].get("text", "{}")

            parsed = self._parse_response(result_text)

            print(f"Route: {parsed['route']}")
            return parsed

        except Exception as e:
            print(f"LLM Intent Router failed: {e}")
            # Default to discovery on error
            return {"route": "discovery", "reason": f"Router error: {e}"}

    # ------------------------------------------------------------------
    def _parse_response(self, text: str) -> Dict:
        """Parse the LLM JSON response."""
        try:
            # Strip markdown fences if present
            clean = text.strip()
            if "```json" in clean:
                clean = clean.split("```json")[1].split("```")[0].strip()
            elif "```" in clean:
                clean = clean.split("```")[1].split("```")[0].strip()

            result = json.loads(clean)
            route = result.get("route", "discovery")
            if route not in ("discovery", "react_agent"):
                route = "discovery"
            return {"route": route, "reason": result.get("reason", "")}

        except Exception:
            # Keyword fallback
            lower = text.lower()
            if "react_agent" in lower:
                return {"route": "react_agent", "reason": "parsed from text"}
            return {"route": "discovery", "reason": "default fallback"}


class HaikuGuardrail:
    """
    LLM-based guardrail using Claude Haiku.
    Analyzes user questions before processing to block inappropriate content.
    Loads prompt from prompts/guardrail_prompt.txt.
    """
    
    def __init__(self, model_id: Optional[str] = None):
        self.model_id = model_id or config.BEDROCK_HAIKU_MODEL_ID
        self.bedrock = boto3.client('bedrock-runtime', region_name=config.AWS_REGION, verify=False)
        self.guardrail_prompt = self._load_prompt()
    
    @staticmethod
    def _load_prompt() -> str:
        """Load guardrail prompt from prompts/ folder."""
        with open(config.GUARDRAIL_PROMPT_FILE, 'r', encoding='utf-8') as f:
            return f.read()
    
    def check_question(self, question: str) -> Dict:
        """
        Check if a question is allowed.
        
        Args:
            question: User's question to check
        
        Returns:
            Dict with is_allowed, category, reason, suggested_response
        """
        print(f"\n{'='*60}")
        print("🛡️  HAIKU GUARDRAIL CHECK")
        print(f"{'='*60}")
        print(f"Question: {question}")
        
        formatted_prompt = self.guardrail_prompt.format(question=question)
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 512,
            "temperature": 0.0,
            "top_k": 1,
            "messages": [
                {"role": "user", "content": formatted_prompt}
            ]
        })
        
        try:
            response = self.bedrock.invoke_model(
                modelId=self.model_id,
                body=body,
                contentType='application/json',
                accept='application/json'
            )
            
            response_body = json.loads(response['body'].read())
            result_text = response_body.get("content", [{}])[0].get("text", "{}")
            
            result = self._parse_guardrail_response(result_text)
            
            if result["is_allowed"]:
                print(f"✅ ALLOWED - Category: {result['category']}")
            else:
                print(f"🚫 BLOCKED - Category: {result['category']}")
                print(f"   Reason: {result['reason']}")
            
            return result
            
        except Exception as e:
            print(f"⚠️  Guardrail check failed: {str(e)}")
            # Fail open (allow) if guardrail has an error
            return {
                "is_allowed": True,
                "category": "error",
                "reason": f"Guardrail check failed: {str(e)}",
                "suggested_response": None
            }
    
    def _parse_guardrail_response(self, response_text: str) -> Dict:
        """Parse guardrail response"""
        try:
            # Extract JSON
            clean = response_text.strip()
            if "```json" in clean:
                clean = clean.split("```json")[1].split("```")[0].strip()
            elif "```" in clean:
                clean = clean.split("```")[1].split("```")[0].strip()
            
            result = json.loads(clean)
            
            # Ensure required fields
            return {
                "is_allowed": result.get("is_allowed", True),
                "category": result.get("category", "unknown"),
                "reason": result.get("reason", "No reason provided"),
                "suggested_response": result.get("suggested_response", 
                    "I apologize, but I can only answer questions about oil & gas discoveries and technical petroleum engineering topics.")
            }
            
        except Exception as e:
            print(f"Warning: Failed to parse guardrail response: {str(e)}")
            # Fail open on parse error
            return {
                "is_allowed": True,
                "category": "parse_error",
                "reason": f"Parse error: {str(e)}",
                "suggested_response": None
            }


__all__ = ['LLMIntentRouter', 'HaikuGuardrail']