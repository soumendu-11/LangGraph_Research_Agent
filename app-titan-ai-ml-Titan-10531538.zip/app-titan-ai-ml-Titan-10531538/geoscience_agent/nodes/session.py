"""
Session Management Nodes
Initialize and save session state
"""

from langchain_core.messages import HumanMessage

from geoscience_agent.state import DiscoveryState
from geoscience_agent.storage import SessionManager


def initialize_session_node(state: DiscoveryState) -> DiscoveryState:
    """Initialize or load a session with LangGraph message support"""
    print(f"\n{'='*60}")
    print("INITIALIZE SESSION NODE")
    print(f"{'='*60}")
    
    session_manager = SessionManager()
    session_id = state.get("session_id")
    thread_id = state.get("thread_id") or session_id  # Use thread_id for DynamoDB
    
    # Get existing messages or initialize empty list
    messages = state.get("messages", [])
    
    # Add current request as HumanMessage
    current_request = state.get("current_request", "")
    if current_request and not any(isinstance(m, HumanMessage) and m.content == current_request for m in messages):
        messages.append(HumanMessage(content=current_request))
        print(f"Added HumanMessage: {current_request[:100]}...")
    
    if session_id:
        # Load existing session
        print(f"Loading existing session: {session_id}")
        session = session_manager.load_session(session_id)
        
        if session:
            print(f"Session loaded ({len(session['conversation_history'])} previous turns)")
            conversation_history = session["conversation_history"]
        else:
            print(f"Session not found, creating new session")
            session = session_manager.create_session()
            session_id = session["session_id"]
            conversation_history = []
    else:
        # Create new session
        print("Creating new session...")
        session = session_manager.create_session()
        session_id = session["session_id"]
        thread_id = session_id  # Use session_id as thread_id
        conversation_history = []
        print(f"New session created: {session_id}")
    
    return {
        **state,
        "messages": messages,
        "session_id": session_id,
        "thread_id": thread_id,
        "conversation_history": conversation_history,
        "status": "session_initialized",
        "error": None
    }


def save_session_node(state: DiscoveryState) -> DiscoveryState:
    """Save the current turn to the session"""
    print(f"\n{'='*60}")
    print("SAVE SESSION NODE")
    print(f"{'='*60}")
    
    if state.get("status") == "error":
        print("Not saving due to error")
        return state
    
    session_id = state.get("session_id")
    
    if not session_id:
        print("No session ID")
        return state
    
    # Instantiate SessionManager locally (not stored in state)
    session_manager = SessionManager()
    # Load current session
    session = session_manager.load_session(session_id)
    
    if not session:
        print("Could not load session")
        return state
    
    # Prepare turn data
    current_request = state.get("current_request")
    current_response = state.get("current_response")
    evaluation_scores = state.get("evaluation_scores")
    
    # Add metadata
    metadata = {
        "query_type": state.get("query_type"),
        "routing_path": state.get("routing_path"),
        "timestamp": state.get("timestamp"),
        "is_deterministic": True
    }
    
    # Add evaluation to metadata if available
    if evaluation_scores:
        metadata["evaluation"] = evaluation_scores
    
    # Add classification scores
    if state.get("classification_scores"):
        metadata["classification"] = state.get("classification_scores")
    
    # Add the turn
    session = session_manager.add_turn(
        session=session,
        question=current_request,
        answer=current_response,
        metadata=metadata
    )
    
    print(f"Turn saved to session (Total turns: {len(session['conversation_history'])})")
    
    return {
        **state,
        "conversation_history": session["conversation_history"],
        "status": "completed"
    }
