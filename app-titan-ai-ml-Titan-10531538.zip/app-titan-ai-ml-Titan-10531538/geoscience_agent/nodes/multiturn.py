"""
Multi-turn Handler Node
Processes queries with conversation history and G-Eval scoring
"""

from langchain_core.messages import AIMessage, HumanMessage

from geoscience_agent.models import HAIKU_CONFIG
from geoscience_agent.processors import MultiTurnProcessor
from geoscience_agent.state import DiscoveryState


def multiturn_handler_node(state: DiscoveryState) -> DiscoveryState:
    """Handle multi-turn conversational queries - deterministic response from JSON + G-Eval"""
    print(f"\n{'='*60}")
    print("MULTI-TURN HANDLER NODE (Deterministic + G-Eval)")
    print(f"{'='*60}")
    
    # Get conversation history from messages for context
    messages = state.get("messages", [])
    conversation_context = "\n".join([
        f"{msg.type}: {msg.content}"
        for msg in messages[:-1]  # Exclude current message
        if isinstance(msg, (HumanMessage, AIMessage))
    ])
    
    if conversation_context:
        print(f"Conversation context: {len(messages)-1} previous messages")
    
    model_id = state.get("model_id", HAIKU_CONFIG["model_id"])
    processor = MultiTurnProcessor(model_id=model_id)
    
    result = processor.process_deterministic(state)
    
    # Add AI response to messages
    response_summary = result.get("response_summary", "No response generated")
    messages.append(AIMessage(content=response_summary))
    print(f"Added AIMessage to conversation history")
    
    return {
        **result,
        "messages": messages
    }
