"""
Intent Router Node
Classifies user intent using Bedrock and route registry
"""
import re

from geoscience_agent.models import BedrockIntentRouter
from geoscience_agent.state import DiscoveryState


def intent_router_node(state: DiscoveryState) -> DiscoveryState:
    """
    Bedrock-based intent router using route_registry.json
    Classifies intent as: map_update, dashboard_load, or analytical_question
    Selects appropriate semantic model based on the question type
    """
    print(f"\n{'='*60}")
    print("BEDROCK INTENT ROUTER NODE")
    print(f"{'='*60}")

    request = state.get("current_request", "")
    
    try:
        print(f"  Initializing BedrockIntentRouter...")
        router = BedrockIntentRouter()
        print(f"  ✓ Router initialized successfully")
        print(f"🤖 Classifying intent for request: {request[:100]}...")
        
        result = router.classify(
            prompt=request,
            workflow="GEOSCIENCE",
            country_name=None
        )
        
        print(f"✓ Classification complete, parsing result...")
        
        intent = result.get("intent", "analytical_question")
        confidence = result.get("confidence", 0.0)
        parameters = result.get("parameters", {})
        route_name = result.get("route_name")
        
        print(f"\n✓ Intent Classification Result:")
        print(f"  Intent: {intent} (confidence: {confidence})")
        print(f"  Route Name: {route_name or 'N/A'}")
        print(f"  Parameters: {parameters}")
        print(f"  Full Result: {result}")
        
        # Map intent to workflow route based on classification
        # analytical_question -> Cortex Analyst (discovery path)
        # dashboard_load -> Skip Cortex, go directly to response formatting
        # map_update -> Would need separate handler (future)
        if intent == "dashboard_load":
            workflow_route = "dashboard"
            print(f"  → Routing to: dashboard (skip Cortex Analyst)")
        elif intent == "map_update":
            workflow_route = "map"
            print(f"  → Routing to: map (skip Cortex Analyst)")
        else:
            # Default: analytical_question or unknown
            workflow_route = "cortex"
            print(f"  → Routing to: cortex (Cortex Analyst API)")
        
        # Extract semantic model from parameters (set by LLM during classification)
        semantic_model = parameters.get("semantic_view")
        
        # If no semantic model specified, use smart defaults based on question type
        if not semantic_model:
            # Analyze question to determine if it's field-level or reservoir-level
            request_lower = request.lower()
            
            # Reservoir-specific keywords
            reservoir_keywords = [
                "reservoir", "formation", "pay zone", "porosity", "permeability",
                "thickness", "depth", "pressure", "saturation", "rock properties"
            ]
            
            # Field-level keywords
            field_keywords = [
                "field", "discovery", "basin", "operator", "company",
                "total recoverable", "reserves", "resources", "production status"
            ]
            
            # Count keyword matches
            reservoir_score = sum(1 for kw in reservoir_keywords if kw in request_lower)
            field_score = sum(1 for kw in field_keywords if kw in request_lower)
            
            # Select semantic model based on question focus
            if reservoir_score > field_score:
                semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_RESERVOIR_SUMMARY"
                print(f"  Auto-selected: Reservoir semantic model (reservoir keywords: {reservoir_score})")
            else:
                semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_FIELD_SUMMARY"
                print(f"  Auto-selected: Field semantic model (field keywords: {field_score})")
        else:
            print(f"  Using LLM-selected semantic model: {semantic_model}")
        
        final_state = {
            **state,
            "intent_route": workflow_route,
            "intent_classification": result,
            "semantic_model_name": semantic_model,
            "status": "intent_classified"
        }
        print(f"  DEBUG: Returning state with intent_classification = {final_state.get('intent_classification', {}).get('intent', 'MISSING')}")
        return final_state
        
    except Exception as e:
        print(f"⚠️ Intent router error: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        print(f"   Using fallback classification logic")
        
        # Analyze question for semantic model selection even in fallback
        request_lower = request.lower()
        
        # Check for dashboard_load intent patterns
        dashboard_patterns = [
            r"show\s+(?:me\s+)?(?:the\s+)?details?\s+(?:of|for)\s+(?:field|reservoir)",
            r"load\s+(?:field|reservoir)\s+(?:summary|dashboard)",
            r"(?:field|reservoir)\s+summary\s+for",
            r"details?\s+(?:on|about)\s+(?:field|reservoir)"
        ]
        
        is_dashboard_load = any(re.search(pattern, request_lower) for pattern in dashboard_patterns)
        
        # Reservoir-specific keywords
        reservoir_keywords = [
            "reservoir", "formation", "pay zone", "porosity", "permeability",
            "thickness", "depth", "pressure", "saturation", "rock properties"
        ]
        
        # Field-level keywords
        field_keywords = [
            "field", "discovery", "basin", "operator", "company"
        ]
        
        # Count keyword matches
        reservoir_score = sum(1 for kw in reservoir_keywords if kw in request_lower)
        field_score = sum(1 for kw in field_keywords if kw in request_lower)
        
        # Determine intent
        if is_dashboard_load:
            intent = "dashboard_load"
            print(f"   Detected dashboard_load intent via pattern matching")
        else:
            intent = "analytical_question"
            print(f"   Defaulting to analytical_question intent")
        
        # Select semantic model based on question focus
        if reservoir_score > field_score:
            semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_RESERVOIR_SUMMARY"
            print(f"   Using reservoir semantic model (reservoir keywords: {reservoir_score}, field keywords: {field_score})")
        else:
            semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_FIELD_SUMMARY"
            print(f"   Using field semantic model (reservoir keywords: {reservoir_score}, field keywords: {field_score})")
        
        # Return fallback result
        return {
            **state,
            "intent_route": "discovery",
            "intent_classification": {
                "intent": intent,
                "confidence": 0.5,
                "parameters": {"question": request, "semantic_view": semantic_model},
                "route_name": None,
                "route_reason": f"Fallback due to error: {str(e)}"
            },
            "semantic_model_name": semantic_model,
            "status": "intent_classified"
        }
