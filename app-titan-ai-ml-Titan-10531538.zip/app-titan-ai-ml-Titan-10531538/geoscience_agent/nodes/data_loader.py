"""
Data Loader Node
Calls Cortex Analyst API to retrieve geoscience data
"""

import asyncio
import json
from concurrent.futures import ThreadPoolExecutor

from geoscience_agent.integrations import cortex_analyst_retrieval
from geoscience_agent.state import DiscoveryState


def load_json_tool_node(state: DiscoveryState) -> DiscoveryState:
    """
    Tool node: Call Cortex Analyst retrieval tool for geoscience data.
    
    This node calls the cortex_analyst_retrieval tool which:
    - Makes HTTP POST request to Cortex Analyst API
    - Returns generated SQL, results, columns, and queryid
    - Supports queries about discoveries, wells, formations, production, seismic data
    
    The semantic model is dynamically determined by the intent router.
    """
    print(f"\n{'='*60}")
    print("CORTEX ANALYST RETRIEVAL TOOL NODE")
    print(f"{'='*60}")
    
    # Get semantic model and refined question from intent classification
    intent_classification = state.get("intent_classification", {})
    semantic_model = None
    refined_question = None
    
    if intent_classification and isinstance(intent_classification, dict):
        parameters = intent_classification.get("parameters", {})
        semantic_model = parameters.get("semantic_view")
        refined_question = parameters.get("question")  # LLM may refine the question
    
    # Use refined question if available, otherwise use original request
    query = refined_question if refined_question else state.get("current_request", "")
    
    # Fallback to request-level semantic_model_name if provided
    if not semantic_model:
        semantic_model = state.get("semantic_model_name")
    
    try:
        # Call Cortex Analyst retrieval tool (async tool)
        print(f"Calling Cortex Analyst API with query: {query}")
        if semantic_model:
            print(f"  Using semantic model: {semantic_model}")
        else:
            print(f"  ⚠️ No semantic model specified, using tool default")
        
        # Since we're in a sync context but within an async event loop (FastAPI),
        # we need to run the async function in a thread pool
        def run_async_in_thread():
            """Run async function in a new thread with its own event loop"""
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                # Pass semantic_model_name if determined by intent router
                tool_params = {"query": query}
                if semantic_model:
                    tool_params["semantic_model_name"] = semantic_model
                return new_loop.run_until_complete(
                    cortex_analyst_retrieval.ainvoke(tool_params)
                )
            finally:
                new_loop.close()
        
        with ThreadPoolExecutor() as executor:
            future = executor.submit(run_async_in_thread)
            tool_response = future.result()
        
        # Parse the JSON response from the tool
        response_data = json.loads(tool_response)
        
        status = response_data.get('status', 'unknown')
        print(f"✓ Cortex Analyst returned: {status}")
        
        # Handle analyst response (no SQL but has suggestions)
        if status == "analyst_response":
            analyst_message = response_data.get("analyst_message", "")
            suggestions = response_data.get("suggestions", [])
            print(f"  Analyst message: {analyst_message[:100]}...")
            print(f"  Suggestions provided: {len(suggestions)}")
            
            return {
                **state,
                "qa_data": [],
                "discoveries_data": [],
                "context": json.dumps({"analyst_message": analyst_message, "suggestions": suggestions}, indent=2),
                "full_context": json.dumps(response_data, indent=2),
                "analyst_message": analyst_message,
                "analyst_suggestions": suggestions,
                "status": "analyst_guidance"
            }
        
        # Check for API errors
        if status == "error":
            error_msg = response_data.get("error", "Unknown error")
            error_type = response_data.get("error_type", "unknown")
            error_category = response_data.get("error_category", "unknown")
            suggestion = response_data.get("suggestion", "")
            status_code = response_data.get("status_code")
            
            print(f"⚠️ API Error ({error_category}/{error_type}): {error_msg}")
            if suggestion:
                print(f"💡 Suggestion: {suggestion}")
            
            return {
                **state,
                "qa_data": [],
                "discoveries_data": [],
                "context": "",
                "full_context": json.dumps(response_data, indent=2),
                "status": "error",
                "error": error_msg,
                "error_type": error_type,
                "error_category": error_category,
                "error_suggestion": suggestion,
                "error_status_code": status_code
            }
        
        # Get results from API response
        results = response_data.get("results") or []
        generated_sql = response_data.get("generated_sql", "")
        
        print(f"  Results returned: {len(results)} rows")
        print(f"  Generated SQL: {generated_sql[:100] if generated_sql else 'N/A'}...")
        
        # Store raw API response in state for downstream processing
        context = json.dumps(results, indent=2) if results else "{}"
        full_json = json.dumps(response_data, indent=2)
        
        return {
            **state,
            "qa_data": results,  # Raw API results
            "discoveries_data": results,  # Same data for compatibility
            "context": context,
            "full_context": full_json,
            "generated_sql": generated_sql,
            "status": "cortex_data_loaded"
        }
        
    except Exception as e:
        error_msg = f"Cortex Analyst tool error: {str(e)}"
        print(f"ERROR: {error_msg}")
        import traceback
        print(traceback.format_exc())
        return {
            **state,
            "qa_data": [],
            "discoveries_data": [],
            "context": "",
            "full_context": "",
            "status": "error",
            "error": error_msg
        }
