"""
Guardrail Check Node
Validates user requests against content policies
"""

from datetime import datetime

from geoscience_agent.models import HaikuGuardrail
from geoscience_agent.state import DiscoveryState


def guardrail_check_node(state: DiscoveryState) -> DiscoveryState:
    """Check if the question should be blocked by guardrail (LLM call)"""
    print(f"\n{'='*60}")
    print("GUARDRAIL CHECK NODE")
    print(f"{'='*60}")
    
    request = state.get("current_request", "")
    
    guardrail = HaikuGuardrail()
    check_result = guardrail.check_question(request)
    
    is_blocked = not check_result["is_allowed"]
    
    if is_blocked:
        # Create blocked response
        blocked_response = {
            "summary": check_result["suggested_response"],
            "key_insights": [
                {
                    "insight": "Content Policy Violation",
                    "description": check_result["reason"]
                }
            ],
            "data_table": []
        }
        
        print(f"\nRequest BLOCKED by guardrail")
        print(f"   Category: {check_result['category']}")
        print(f"   Reason: {check_result['reason']}")
        
        return {
            **state,
            "guardrail_check": check_result,
            "is_blocked": True,
            "current_response": blocked_response,
            "response_summary": blocked_response["summary"],
            "key_insights": blocked_response["key_insights"],
            "data_table": blocked_response["data_table"],
            "status": "blocked_by_guardrail",
            "timestamp": datetime.now().isoformat()
        }
    else:
        print(f"\nRequest ALLOWED by guardrail")
        return {
            **state,
            "guardrail_check": check_result,
            "is_blocked": False,
            "status": "guardrail_passed"
        }
