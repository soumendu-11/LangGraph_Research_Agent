#!/bin/bash

# Local development and testing setup script

echo "=========================================="
echo "Geoscience LangGraph Agent - Local Setup"
echo "=========================================="
echo ""

# Check if Docker is installed
if ! command -v docker &> /dev/null; then
    echo "❌ Docker is not installed. Please install Docker first."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install Docker Compose first."
    exit 1
fi

echo "✅ Docker and Docker Compose found"
echo ""

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file from template..."
    cp .env.example .env
    echo "⚠️  Please edit .env file with your AWS credentials"
    echo ""
fi

# Build and start containers
echo "🐳 Building Docker containers..."
docker-compose build

echo ""
echo "🚀 Starting services..."
docker-compose up -d

echo ""
echo "⏳ Waiting for services to be ready..."
sleep 5

# Check service health
echo ""
echo "🔍 Checking service health..."

# Check API
API_HEALTH=$(curl -s http://localhost:8000/health | grep -o "healthy" || echo "unhealthy")
if [ "$API_HEALTH" = "healthy" ]; then
    echo "✅ API Service: healthy (http://localhost:8000)"
else
    echo "⚠️  API Service: starting up... (check logs with: docker-compose logs geoscience-api)"
fi

# Check MLflow
MLFLOW_STATUS=$(curl -s http://localhost:5000/health | grep -o "OK" || echo "starting")
if [ "$MLFLOW_STATUS" = "OK" ]; then
    echo "✅ MLflow Service: running (http://localhost:5000)"
else
    echo "⚠️  MLflow Service: starting up... (check logs with: docker-compose logs mlflow)"
fi

echo ""
echo "=========================================="
echo "🎉 Setup Complete!"
echo "=========================================="
echo ""
echo "Available services:"
echo "  📡 API:          http://localhost:8000"
echo "  📚 API Docs:     http://localhost:8000/docs"
echo "  📊 MLflow UI:    http://localhost:5000"
echo ""
echo "Useful commands:"
echo "  View logs:       docker-compose logs -f"
echo "  Stop services:   docker-compose down"
echo "  Restart:         docker-compose restart"
echo "  Shell access:    docker-compose exec geoscience-api bash"
echo ""
echo "Test the API:"
echo '  curl -X POST http://localhost:8000/query -H "Content-Type: application/json" -d '"'"'{"query": "Hello", "thread_id": "test-123"}'"'"''
echo ""
