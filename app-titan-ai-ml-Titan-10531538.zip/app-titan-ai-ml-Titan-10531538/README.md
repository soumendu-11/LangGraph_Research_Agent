# Geoscience LangGraph Agent

Enterprise geoscience analytics powered by LangGraph, AWS Bedrock, Cortex Analyst, and DynamoDB.

## Architecture

**Workflow**: Conditional routing with intent classification
- **Guardrails**: AWS Bedrock Haiku for content filtering
- **Intent Router**: Bedrock Sonnet classifies queries into analytical_question, dashboard_load, or map_update
- **Data Retrieval**: Cortex Analyst API for analytical queries with dynamic semantic model selection
- **State Persistence**: DynamoDB checkpointer (MemorySaver for local)
- **Observability**: MLflow tracking

## Key Components

### API Endpoint
**File**: `api.py`
- FastAPI server with SSE streaming
- POST `/discovery/query` - Main workflow endpoint
- Request: `{"request": "query", "session_id": "optional", "metadata": {}}`

### Workflow Nodes
**Files**: `geoscience_agent/nodes/`
- `initialize_session` - Session management
- `guardrail_check` - Content filtering (Haiku)
- `intent_router` - Bedrock classification with route_registry.json
- `load_json_tool` - Cortex Analyst API call
- `multiturn_handler` - Response formatting + G-Eval
- `dashboard_response` - Dashboard/map routing
- `save_session` - State persistence

### Intent Classification
**File**: `models/intent_router.py`
- Uses Bedrock Sonnet for intent classification
- Selects semantic model: SV_INTL_FIELD_SUMMARY or SV_INTL_RESERVOIR_SUMMARY
- Route registry: `data/route_registry.json`

### Cortex Analyst Integration
**File**: `integrations/cortex_analyst.py`
- Async HTTP POST to dev-api endpoint
- Dynamic semantic model from intent router
- Returns SQL, results, columns

## Configuration

**File**: `.env`
- `CORTEX_API_URL` - Cortex Analyst endpoint (dev-api)
- `USE_DYNAMODB` - State persistence (false for local)
- `BEDROCK_MODEL_ID` - Default Bedrock model

## Local Setup

1. **Configure environment**
   ```bash
   cp .env.example .env
   # Edit .env with your AWS credentials path
   ```

2. **Start services**
   ```bash
   docker-compose up -d
   ```

3. **Test API**
   ```bash
   curl -X POST http://localhost:8000/discovery/query \
     -H "Content-Type: application/json" \
     -d '{"request": "Which fields in Saudi Arabia have highest gas production?"}'
   ```

4. **View logs**
   ```bash
   docker logs -f geoscience-langgraph-api
   ```

**Services:**
- API: http://localhost:8000
- Swagger UI: http://localhost:8000/docs
- MLflow: http://localhost:5000


