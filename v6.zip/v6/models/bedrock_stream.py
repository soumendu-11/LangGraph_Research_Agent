"""
Anthropic Claude on AWS Bedrock — streaming invoke with aggregated text + usage.
"""

from __future__ import annotations

import json
import threading
import uuid
from queue import Queue
from typing import Any, Callable, Dict, Optional, Tuple

# Queues must not live in LangGraph checkpoint state (not msgpack-serializable).
# FastAPI registers the queue here and passes only llm_stream_queue_id in metadata.
_stream_queues_lock = threading.Lock()
_stream_queues: Dict[str, Queue] = {}


def register_llm_stream_queue(q: Queue) -> str:
    """Store queue in-process; return an ID safe to put in checkpointed metadata."""
    key = uuid.uuid4().hex
    with _stream_queues_lock:
        _stream_queues[key] = q
    return key


def unregister_llm_stream_queue(queue_id: str) -> None:
    """Remove queue after the request completes (avoids leaks)."""
    with _stream_queues_lock:
        _stream_queues.pop(queue_id, None)


def resolve_llm_stream_callback(
    metadata: Optional[Dict[str, Any]],
    phase: str,
) -> Optional[Callable[[str], None]]:
    """
    Build a per-token callback from request metadata.

    - metadata["llm_stream_queue_id"]: lookup a Queue registered via register_llm_stream_queue
      (checkpoint-safe; preferred for LangGraph).
    - metadata["llm_stream_queue"]: direct Queue reference (not checkpoint-safe — avoid in graph state).
    - metadata["llm_stream_print"]: if truthy, print each chunk (notebook).
    """
    if not metadata:
        return None
    queue_id = metadata.get("llm_stream_queue_id")
    if queue_id is not None:
        with _stream_queues_lock:
            q = _stream_queues.get(str(queue_id))
        if q is not None:

            def _queue_cb_by_id(text: str) -> None:
                if text:
                    q.put({"type": "llm_delta", "phase": phase, "text": text})

            return _queue_cb_by_id
    q = metadata.get("llm_stream_queue")
    if q is not None:

        def _queue_cb(text: str) -> None:
            if text:
                q.put({"type": "llm_delta", "phase": phase, "text": text})

        return _queue_cb
    if metadata.get("llm_stream_print"):

        def _print_cb(text: str) -> None:
            if text:
                print(text, end="", flush=True)

        return _print_cb
    return None


def invoke_anthropic_bedrock_stream(
    bedrock_client: Any,
    model_id: str,
    body_dict: Dict,
    on_text_delta: Optional[Callable[[str], None]] = None,
) -> Tuple[str, Dict[str, int]]:
    """
    Call invoke_model_with_response_stream; aggregate text deltas and token usage.
    Returns (full_text, {"input_tokens": int, "output_tokens": int}).
    """
    body = json.dumps(body_dict)
    response = bedrock_client.invoke_model_with_response_stream(
        modelId=model_id,
        body=body,
        contentType="application/json",
        accept="application/json",
    )
    stream = response.get("body")
    if stream is None:
        return "", {"input_tokens": 0, "output_tokens": 0}

    text_parts: list = []
    input_tokens = 0
    output_tokens = 0

    for event in stream:
        if isinstance(event, dict):
            chunk = event.get("chunk")
        else:
            chunk = getattr(event, "chunk", None)
        if chunk is None:
            continue
        raw = chunk.get("bytes") if isinstance(chunk, dict) else getattr(chunk, "bytes", None)
        if raw is None:
            continue
        payload = json.loads(raw.decode("utf-8"))
        et = payload.get("type")

        if et == "content_block_delta":
            delta = payload.get("delta") or {}
            if delta.get("type") == "text_delta":
                piece = delta.get("text", "") or ""
                text_parts.append(piece)
                if on_text_delta and piece:
                    on_text_delta(piece)
        elif et == "message_start":
            msg = payload.get("message") or {}
            usage = msg.get("usage") or {}
            input_tokens = usage.get("input_tokens", input_tokens)
        elif et == "message_delta":
            usage = payload.get("usage") or {}
            if "output_tokens" in usage:
                output_tokens = usage["output_tokens"]
        elif et == "message_stop":
            # Some responses attach final metrics on message_stop
            usage = payload.get("usage") or {}
            if "input_tokens" in usage:
                input_tokens = usage["input_tokens"]
            if "output_tokens" in usage:
                output_tokens = usage["output_tokens"]

    return "".join(text_parts), {
        "input_tokens": int(input_tokens or 0),
        "output_tokens": int(output_tokens or 0),
    }


__all__ = [
    "invoke_anthropic_bedrock_stream",
    "resolve_llm_stream_callback",
    "register_llm_stream_queue",
    "unregister_llm_stream_queue",
]
