"""
G-Eval Evaluator Module
Reference-based evaluation using AWS Bedrock Claude Sonnet 4.5.
"""

import json
import boto3
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime

from geoscience_agent.config import config
from geoscience_agent.models.bedrock_stream import invoke_anthropic_bedrock_stream


class GEvalEvaluator:
    """
    G-Eval implementation using Claude Sonnet 4.5 (eval model).
    Evaluates deterministic answers against a gold standard reference answer.
    """
    
    def __init__(self, model_id: Optional[str] = None):
        self.model_id = model_id or config.BEDROCK_EVAL_MODEL_ID
        self.bedrock = boto3.client('bedrock-runtime', region_name=config.AWS_REGION, verify=False)
        self.eval_prompt_with_reference = self._load_eval_prompt()
    
    def _load_eval_prompt(self) -> str:
        """Load evaluation prompt from config path or prompts folder."""
        path = getattr(config, "EVAL_PROMPT_WITH_REFERENCE_FILE", None)
        if path and Path(path).exists():
            return Path(path).read_text(encoding="utf-8").strip()
        prompts_dir = Path(__file__).resolve().parent.parent / "prompts"
        return (prompts_dir / "eval_prompt_with_reference.txt").read_text(encoding="utf-8").strip()
    
    def evaluate_turn_with_reference(
        self,
        reference_answer: str,
        question: str,
        generated_answer: Dict
    ) -> Dict:
        """
        Evaluate a generated answer against a gold standard reference answer.
        
        Args:
            reference_answer: The gold standard answer from the JSON (serialised str)
            question: User query
            generated_answer: System response dict with summary, key_insights, data_table
        
        Returns:
            Evaluation scores dict with 5 metrics + overall score
        """
        formatted_answer = json.dumps(generated_answer, indent=2)
        
        eval_prompt = self.eval_prompt_with_reference.format(
            reference_answer=reference_answer,
            question=question,
            generated_answer=formatted_answer
        )
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 2048,
            "temperature": 0.0,
            "top_k": 1,
            "messages": [
                {
                    "role": "user",
                    "content": eval_prompt
                }
            ]
        })
        
        try:
            body_dict = json.loads(body)
            eval_text, usage_dict = invoke_anthropic_bedrock_stream(
                self.bedrock, self.model_id, body_dict
            )
            if not eval_text:
                eval_text = "{}"

            eval_scores = self._parse_evaluation_response(eval_text)

            eval_scores["evaluation_metadata"] = {
                "evaluator_model": self.model_id,
                "evaluation_type": "reference_based",
                "timestamp": datetime.now().isoformat(),
                "usage": {
                    "input_tokens": usage_dict.get("input_tokens", 0),
                    "output_tokens": usage_dict.get("output_tokens", 0),
                },
            }
            
            return eval_scores
            
        except Exception as e:
            print(f"Error during reference-based evaluation: {str(e)}")
            return {
                "coherence": 3.0,
                "consistency": 3.0,
                "fluency": 3.0,
                "relevance": 3.0,
                "groundedness": 3.0,
                "overall_score": 3.0,
                "reasoning": {
                    "error": f"Reference-based evaluation failed: {str(e)}"
                },
                "evaluation_metadata": {
                    "evaluator_model": self.model_id,
                    "evaluation_type": "reference_based",
                    "timestamp": datetime.now().isoformat(),
                    "error": str(e)
                }
            }
    
    def _parse_evaluation_response(self, eval_text: str) -> Dict:
        """Parse evaluation response and extract scores"""
        try:
            # Try to extract JSON from response
            if "```json" in eval_text:
                json_start = eval_text.find("```json") + 7
                json_end = eval_text.find("```", json_start)
                json_text = eval_text[json_start:json_end].strip()
            elif "```" in eval_text:
                json_start = eval_text.find("```") + 3
                json_end = eval_text.find("```", json_start)
                json_text = eval_text[json_start:json_end].strip()
            else:
                json_text = eval_text.strip()
            
            scores = json.loads(json_text)
            
            # Ensure all required fields are present
            required_fields = ["coherence", "consistency", "fluency", "relevance", "groundedness"]
            for field in required_fields:
                if field not in scores:
                    scores[field] = 3.0
            
            # Calculate overall score if not present
            if "overall_score" not in scores:
                scores["overall_score"] = sum(
                    scores.get(f, 3.0) for f in required_fields
                ) / 5.0
            
            # Ensure reasoning is present
            if "reasoning" not in scores:
                scores["reasoning"] = {}
            
            return scores
            
        except Exception as e:
            print(f"Error parsing evaluation response: {str(e)}")
            print(f"Raw response: {eval_text}")
            return {
                "coherence": 3.0,
                "consistency": 3.0,
                "fluency": 3.0,
                "relevance": 3.0,
                "groundedness": 3.0,
                "overall_score": 3.0,
                "reasoning": {
                    "parse_error": str(e)
                }
            }


__all__ = ['GEvalEvaluator']