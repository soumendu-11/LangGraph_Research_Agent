"""
Layer Toggle Resolver
Deterministic resolver that maps natural-language layer references to canonical
layer IDs using a predefined layer dictionary, then computes binary on/off
actions by comparing against the front-end's currently active layers.
"""

import json
import re
from pathlib import Path
from typing import Dict, List, Optional

from geoscience_agent.config import config


class LayerToggleResolver:
    """Resolve natural-language layer toggle commands against a layer dictionary."""

    def __init__(self, dictionary_path: Optional[str] = None):
        if dictionary_path is None:
            dictionary_path = config.LAYER_DICTIONARY_FILE
        self._dict_path = Path(dictionary_path)
        self._layers, self._categories = self._load_dictionary()
        self._alias_index = self._build_alias_index()

    # ------------------------------------------------------------------
    # Dictionary loading
    # ------------------------------------------------------------------

    def _load_dictionary(self):
        if not self._dict_path.exists():
            raise FileNotFoundError(
                f"Layer dictionary not found at {self._dict_path}"
            )
        with self._dict_path.open("r", encoding="utf-8") as f:
            data = json.load(f)
        layers = {entry["layer_id"]: entry for entry in data.get("layers", [])}
        categories = data.get("categories", {})
        return layers, categories

    def _build_alias_index(self) -> Dict[str, str]:
        """Map every lowercase alias → layer_id for O(1) lookup."""
        index: Dict[str, str] = {}
        for layer_id, entry in self._layers.items():
            index[layer_id.lower()] = layer_id
            index[entry["display_name"].lower()] = layer_id
            for alias in entry.get("aliases", []):
                index[alias.lower()] = layer_id
        return index

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def resolve(
        self,
        user_request: str,
        active_layers: List[str],
        requested_layers: Optional[List[str]] = None,
        action_hint: Optional[str] = None,
    ) -> Dict:
        """
        Parse a layer-toggle command and compute per-layer on/off actions.

        Args:
            user_request: Raw NL command from the user.
            active_layers: Layer IDs currently ON in the front end.
            requested_layers: Pre-extracted layer names (from intent router).
            action_hint: Pre-extracted action text (from intent router).

        Returns:
            Dict with keys:
                layer_actions     – list of {layer_id, display_name, action}
                matched_layer_ids – list of resolved layer_id strings
                confirmation_message – human-friendly summary
                error             – None or error code string
        """
        action = self._detect_action(user_request, action_hint)
        matched_ids = self._match_layers(user_request, requested_layers)

        if not matched_ids:
            return {
                "layer_actions": [],
                "matched_layer_ids": [],
                "confirmation_message": (
                    "Sorry I cannot fulfil your request as no matching layers "
                    "found. Please try again."
                ),
                "error": "no_matching_layers",
            }

        layer_actions = self._compute_actions(matched_ids, active_layers, action)
        message = self._build_confirmation(layer_actions)

        return {
            "layer_actions": layer_actions,
            "matched_layer_ids": [la["layer_id"] for la in layer_actions],
            "confirmation_message": message,
            "error": None,
        }

    # ------------------------------------------------------------------
    # Action detection
    # ------------------------------------------------------------------

    _TURN_OFF_PATTERNS = [
        r"\bturn\s+off\b", r"\bhide\b", r"\bdisable\b", r"\bremove\b",
        r"\bswitch\s+off\b", r"\bdeactivate\b",
    ]
    _TURN_ON_PATTERNS = [
        r"\bturn\s+on\b", r"\bshow\b", r"\benable\b", r"\badd\b",
        r"\bswitch\s+on\b", r"\bactivate\b", r"\bdisplay\b",
    ]
    _TOGGLE_PATTERN = re.compile(r"\btoggle\b", re.IGNORECASE)

    def _detect_action(self, text: str, hint: Optional[str] = None) -> str:
        """Return 'on', 'off', or 'toggle'."""
        combined = f"{text} {hint or ''}".lower()

        off_score = sum(
            1 for p in self._TURN_OFF_PATTERNS if re.search(p, combined)
        )
        on_score = sum(
            1 for p in self._TURN_ON_PATTERNS if re.search(p, combined)
        )

        if self._TOGGLE_PATTERN.search(combined):
            return "toggle"
        if off_score > on_score:
            return "off"
        if on_score > off_score:
            return "on"
        if off_score == on_score and off_score > 0:
            return "toggle"
        return "on"

    # ------------------------------------------------------------------
    # Layer matching
    # ------------------------------------------------------------------

    def _match_layers(
        self,
        text: str,
        requested_layers: Optional[List[str]] = None,
    ) -> List[str]:
        """Return deduplicated list of matched layer_ids."""
        matched: List[str] = []
        seen: set = set()

        candidates = list(requested_layers or [])
        candidates.append(text)

        lowered_text = " ".join(candidates).lower()

        # Category matching (e.g. "geology layers", "all assets")
        for cat_name, cat_layer_ids in self._categories.items():
            cat_patterns = [
                rf"\b{re.escape(cat_name)}\s+layers?\b",
                rf"\ball\s+{re.escape(cat_name)}\b",
                rf"\b{re.escape(cat_name)}\b",
            ]
            if any(re.search(p, lowered_text) for p in cat_patterns[:2]):
                for lid in cat_layer_ids:
                    if lid not in seen:
                        matched.append(lid)
                        seen.add(lid)

        # Exact alias matching (longest-first to avoid partial matches)
        sorted_aliases = sorted(self._alias_index.keys(), key=len, reverse=True)
        for alias in sorted_aliases:
            if re.search(rf"\b{re.escape(alias)}\b", lowered_text):
                lid = self._alias_index[alias]
                if lid not in seen:
                    matched.append(lid)
                    seen.add(lid)

        # "all layers" / "everything"
        if re.search(r"\ball\s+layers?\b|\beverything\b", lowered_text):
            for lid in self._layers:
                if lid not in seen:
                    matched.append(lid)
                    seen.add(lid)

        return matched

    # ------------------------------------------------------------------
    # Action computation
    # ------------------------------------------------------------------

    def _compute_actions(
        self,
        matched_ids: List[str],
        active_layers: List[str],
        action: str,
    ) -> List[Dict]:
        active_set = set(lid.lower() for lid in active_layers)
        result = []
        for lid in matched_ids:
            entry = self._layers.get(lid, {})
            if action == "on":
                final_action = "on"
            elif action == "off":
                final_action = "off"
            else:
                final_action = "off" if lid.lower() in active_set else "on"
            result.append({
                "layer_id": lid,
                "display_name": entry.get("display_name", lid),
                "action": final_action,
            })
        return result

    # ------------------------------------------------------------------
    # Confirmation message
    # ------------------------------------------------------------------

    def _build_confirmation(self, layer_actions: List[Dict]) -> str:
        turned_on = [la["display_name"] for la in layer_actions if la["action"] == "on"]
        turned_off = [la["display_name"] for la in layer_actions if la["action"] == "off"]
        parts = []
        if turned_on:
            names = ", ".join(turned_on)
            parts.append(f"turned on {names}")
        if turned_off:
            names = ", ".join(turned_off)
            parts.append(f"turned off {names}")
        if not parts:
            return "No layer changes were needed."
        return f"Done! I've {' and '.join(parts)}."

    # ------------------------------------------------------------------
    # Utility
    # ------------------------------------------------------------------

    def get_all_layer_ids(self) -> List[str]:
        return list(self._layers.keys())

    def get_layer_display_names(self) -> Dict[str, str]:
        return {lid: e["display_name"] for lid, e in self._layers.items()}
