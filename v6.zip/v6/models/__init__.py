"""
Models Package - LLM and Bedrock Interactions

All tasks use Sonnet 4.5.
- configs: Model configurations (workflow + eval)
- intent_router: Bedrock-based intent classification (Sonnet 4.5)
- evaluator: G-Eval reference-based scoring (Sonnet 4.5)
- guardrail: Content moderation and policy validation (Sonnet 4.5)
- layer_toggle: Deterministic map-layer toggle resolver
"""

from .configs import DEFAULT_MODEL, EVAL_CONFIG, SONNET_45_CONFIG
from .evaluator import GEvalEvaluator
from .guardrail import ContentGuardrail
from .intent_router import BedrockIntentRouter
from .layer_toggle import LayerToggleResolver

__all__ = [
    'DEFAULT_MODEL',
    'EVAL_CONFIG',
    'SONNET_45_CONFIG',
    'GEvalEvaluator',
    'ContentGuardrail',
    'BedrockIntentRouter',
    'LayerToggleResolver',
]
