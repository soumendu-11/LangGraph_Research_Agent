"""
Bedrock-based Intent Router for Discovery Workflow
Replaces Snowflake Cortex with AWS Bedrock for intent classification
Includes Cortex Analyst API integration
"""
import json
import re
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
import boto3
from botocore.config import Config as BotoConfig
import httpx

from geoscience_agent.config import config
from geoscience_agent.models.bedrock_stream import invoke_anthropic_bedrock_stream


class BedrockIntentRouter:
    """Intent router using AWS Bedrock for LLM inference"""
    
    def __init__(self, registry_path: Optional[str] = None):
        """
        Initialize the intent router with route registry
        
        Args:
            registry_path: Path to route_registry.json (defaults to config.ROUTE_REGISTRY_FILE)
        """
        if registry_path is None:
            registry_path = config.ROUTE_REGISTRY_FILE
        
        self.registry_path = Path(registry_path)
        self.registry = self._load_registry()
        
        # Initialize Bedrock client
        session = boto3.Session()
        boto_config = BotoConfig(
            connect_timeout=10,
            read_timeout=60,
            retries={'max_attempts': 2}
        )
        self.bedrock_client = session.client(
            'bedrock-runtime',
            region_name=config.AWS_REGION,
            config=boto_config
        )
        
        # Workflow model (Sonnet 4.5) for deterministic intent routing
        self.model_id = config.BEDROCK_WORKFLOW_MODEL_ID
    
    def _load_registry(self) -> dict:
        """Load route registry from JSON file"""
        if not self.registry_path.exists():
            raise FileNotFoundError(f"route_registry.json not found at {self.registry_path}")
        
        with self.registry_path.open('r', encoding='utf-8') as f:
            return json.load(f)

    def _load_intent_prompt(self) -> str:
        """Load intent router prompt from prompts folder"""
        prompt_path = Path(config.INTENT_ROUTER_PROMPT_FILE)
        if not prompt_path.exists():
            raise FileNotFoundError(f"Intent router prompt not found at {prompt_path}")
        return prompt_path.read_text(encoding="utf-8").strip()
    
    def _extract_json(self, text: str) -> dict:
        """Extract JSON from LLM response text"""
        if not text:
            return {}
        
        try:
            return json.loads(text)
        except Exception:
            # Try to find JSON block in text
            match = re.search(r'\{.*\}', text, re.DOTALL)
            if match:
                try:
                    return json.loads(match.group(0))
                except Exception:
                    return {}
        return {}
    
    def _find_route(self, routes: List[Dict[str, Any]], name: Optional[str] = None, intent: Optional[str] = None) -> Optional[dict]:
        """Find a route by name or intent"""
        if name:
            for route in routes:
                if route.get("name") == name:
                    return route
        if intent:
            for route in routes:
                if route.get("intent") == intent:
                    return route
        return None
    
    def _apply_path_params(self, path: str, params: dict) -> Tuple[str, dict]:
        """
        Apply path parameters to route path
        
        Args:
            path: Route path with {param} placeholders
            params: Parameters dict
        
        Returns:
            Tuple of (resolved_path, remaining_params)
        """
        remaining = dict(params)
        
        def replace_match(match):
            key = match.group(1)
            if key not in remaining:
                raise KeyError(f"Missing path parameter: {key}")
            value = remaining.pop(key)
            return str(value)
        
        new_path = re.sub(r'\{([^}]+)\}', replace_match, path)
        return new_path, remaining
    
    def _missing_path_params(self, path: str, params: dict) -> List[str]:
        """Check for missing path parameters"""
        keys = re.findall(r'\{([^}]+)\}', path)
        return [key for key in keys if key not in params]
    
    def _build_action_payload(self, base_url: str, route: dict, params: dict) -> dict:
        """Build action payload for route execution"""
        method = (route.get("method") or "GET").upper()
        path = route.get("path") or ""
        resolved_path, remaining = self._apply_path_params(path, params)
        
        return {
            "endpoint": {
                "base_url": base_url,
                "path": resolved_path,
                "method": method,
            },
            "params": remaining,
        }
    
    def _build_map_params(
        self, 
        workflow_key: str, 
        country_name: Optional[str], 
        map_route: dict, 
        inference_params: dict
    ) -> dict:
        """Build parameters for map update requests"""
        params = {"workflow": workflow_key}
        
        if country_name:
            params["country_name"] = country_name
        
        for key in (map_route.get("optional_parameters") or []):
            if key in inference_params:
                params[key] = inference_params[key]
        
        return params
    
    async def fetch_dashboard_response(self, base_url: str, route: dict, params: dict) -> dict:
        """
        Fetch dashboard data from API
        
        Args:
            base_url: Base URL for API
            route: Route configuration
            params: Parameters dict
        
        Returns:
            Dict with response data or error
        """
        method = (route.get("method") or "GET").upper()
        path = route.get("path") or ""
        
        try:
            path, remaining = self._apply_path_params(path, params)
        except KeyError as e:
            return {"error": str(e)}
        
        async with httpx.AsyncClient() as client:
            try:
                if method == "POST":
                    response = await client.post(
                        f"{base_url}{path}", 
                        json=remaining, 
                        timeout=60.0
                    )
                else:
                    response = await client.get(
                        f"{base_url}{path}", 
                        params=remaining, 
                        timeout=60.0
                    )
                
                response.raise_for_status()
                return response.json()
            
            except httpx.HTTPStatusError as e:
                return {
                    "error": f"HTTP {e.response.status_code}",
                    "detail": e.response.text
                }
            except Exception as e:
                return {
                    "error": "Request failed",
                    "detail": str(e)
                }
    
    async def fetch_map_update(self, base_url: str, map_route: dict, params: dict) -> dict:
        """
        Fetch map layer updates
        
        Args:
            base_url: Base URL for API
            map_route: Map route configuration
            params: Map parameters
        
        Returns:
            Dict with map data or error
        """
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(
                    f"{base_url}{map_route['path']}", 
                    params=params, 
                    timeout=60.0
                )
                response.raise_for_status()
                return response.json()
            
            except httpx.HTTPStatusError as e:
                return {
                    "error": f"HTTP {e.response.status_code}",
                    "detail": e.response.text
                }
            except Exception as e:
                return {
                    "error": "Request failed",
                    "detail": str(e)
                }
    
    def _call_bedrock(
        self,
        prompt: str,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> str:
        """Call AWS Bedrock for LLM inference"""
        try:
            # Prepare request body for Claude
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 1000,
                "temperature": 0.0,
                "top_k": 1,
                "messages": [
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
            
            print(f"  Calling Bedrock with model: {self.model_id}")

            text, usage_dict = invoke_anthropic_bedrock_stream(
                self.bedrock_client,
                self.model_id,
                request_body,
                on_text_delta=on_text_delta,
            )

            self._last_usage = {
                "input_tokens": usage_dict.get("input_tokens", 0),
                "output_tokens": usage_dict.get("output_tokens", 0),
            }

            if text:
                print(f"  ✓ Bedrock returned {len(text)} characters")
                return text

            print(f"  ⚠️ Bedrock response has no content")
            return ""
            
        except Exception as e:
            print(f"⚠️ Bedrock intent router error: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
            self._last_usage = {"input_tokens": 0, "output_tokens": 0}
            return ""
    
    def _heuristic_dashboard_route(self, prompt: str, routes: List[Dict[str, Any]]) -> Optional[dict]:
        """
        Heuristic-based dashboard route matching for quick resolution
        Looks for entity IDs or names in the prompt
        """
        if not prompt:
            return None
        
        lowered = prompt.lower()
        
        # Find dashboard routes
        dashboard_routes = [
            r for r in routes
            if r.get("intent") == "dashboard_load" or r.get("response_type") == "dashboard_load"
        ]
        
        if not dashboard_routes:
            return None
        
        for route in dashboard_routes:
            required_params = route.get("required_parameters", [])
            optional_params = route.get("optional_parameters", [])
            params = list(required_params) + list(optional_params)
            
            for param in params:
                if not isinstance(param, str):
                    continue
                
                # Match entity_id pattern (e.g., "field 12345")
                if param.endswith("_id"):
                    keyword = param[:-3].replace("_", " ")
                    match = re.search(rf"\b{re.escape(keyword)}\s*(\d+)\b", lowered)
                    if match:
                        parameters = {param: int(match.group(1))}
                        dashboard_name = route.get("dashboard_name")
                        if dashboard_name:
                            parameters["workflow_dashboard_name"] = dashboard_name
                        
                        return {
                            "intent": "dashboard_load",
                            "confidence": 0.95,
                            "parameters": parameters,
                            "route_name": route.get("name"),
                            "route_reason": f"Prompt requests a {keyword} summary with explicit {param}."
                        }
                
                # Match entity_name pattern
                if param.endswith("_name"):
                    keyword = param[:-5].replace("_", " ")
                    # Try quoted strings first
                    quoted = re.search(rf"\b{re.escape(keyword)}\s+name\s+['\"]([^'\"]+)['\"]", lowered)
                    if quoted:
                        parameters = {param: quoted.group(1)}
                        dashboard_name = route.get("dashboard_name")
                        if dashboard_name:
                            parameters["workflow_dashboard_name"] = dashboard_name
                        
                        return {
                            "intent": "dashboard_load",
                            "confidence": 0.9,
                            "parameters": parameters,
                            "route_name": route.get("name"),
                            "route_reason": f"Prompt requests a {keyword} summary with explicit {param}."
                        }
        
        return None
    
    def classify(
        self,
        prompt: str,
        workflow: str = "GEOSCIENCE",
        country_name: Optional[str] = None,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> dict:
        """
        Classify user intent using Bedrock LLM or heuristics
        
        Args:
            prompt: User's query/request
            workflow: Workflow name (default: GEOSCIENCE)
            country_name: Optional country context
        
        Returns:
            Dict with: intent, confidence, parameters, route_name, route_reason
        """
        workflows = self.registry.get("workflows", {})
        workflow_key = workflow.strip().upper()
        
        if workflow_key not in workflows:
            return {
                "intent": "analytical_question",
                "confidence": 0.5,
                "parameters": {"question": prompt},
                "route_name": None,
                "route_reason": f"Unknown workflow: {workflow_key}"
            }
        
        workflow_registry = workflows[workflow_key]
        routes = workflow_registry.get("routes", [])
        semantic_views = workflow_registry.get("semantic_views", [])
        
        # Try heuristic matching first (faster)
        heuristic_result = self._heuristic_dashboard_route(prompt, routes)
        if heuristic_result:
            print(f"✓ Intent resolved via heuristics: {heuristic_result['intent']}")
            return heuristic_result

        # Load system prompt from prompts folder
        system_prompt = self._load_intent_prompt()
        
        user_prompt_data = {
            "prompt": prompt,
            "workflow": workflow_key,
            "country_name": country_name,
            "registry": {
                "response_contract": self.registry.get("response_contract", {}),
                "semantic_views": semantic_views,
                "routes": routes,
            }
        }
        
        full_prompt = (
            f"{system_prompt}\n\n"
            f"Input JSON:\n{json.dumps(user_prompt_data, indent=2)}\n\n"
            f"Respond with ONLY valid JSON, no additional text."
        )
        
        # Call Bedrock for classification
        print(f"🤖 Calling Bedrock for intent classification...")
        completion_text = self._call_bedrock(full_prompt, on_text_delta=on_text_delta)
        print(f"  Raw Bedrock response: {completion_text[:200] if completion_text else '(empty)'}")
        
        if not completion_text:
            # Fallback to analytical_question
            print(f"  ⚠️ Empty Bedrock response, using fallback")
            return {
                "intent": "analytical_question",
                "confidence": 0.6,
                "parameters": {
                    "question": prompt,
                    "semantic_view": semantic_views[0]["name"] if semantic_views else None
                },
                "route_name": None,
                "route_reason": "LLM call failed, defaulting to analytical_question"
            }
        
        # Parse LLM response
        inference = self._extract_json(completion_text)
        print(f"  Parsed JSON: {inference}")
        
        if not inference or "intent" not in inference:
            # Fallback
            print(f"  ⚠️ Failed to parse JSON from Bedrock response, using fallback")
            return {
                "intent": "analytical_question",
                "confidence": 0.6,
                "parameters": {
                    "question": prompt,
                    "semantic_view": semantic_views[0]["name"] if semantic_views else None
                },
                "route_name": None,
                "route_reason": "Failed to parse LLM response, defaulting to analytical_question"
            }
        
        print(f"✓ Intent classified: {inference.get('intent')} (confidence: {inference.get('confidence', 0)})")
        
        inference["usage"] = getattr(self, "_last_usage", {"input_tokens": 0, "output_tokens": 0})
        return inference
    
    def resolve_analyst_inputs(
        self, 
        body_prompt: str, 
        intent_inference: dict, 
        workflow: str = "GEOSCIENCE"
    ) -> Tuple[str, Optional[str], Optional[list]]:
        """
        Resolve inputs for Cortex Analyst API call
        
        Args:
            body_prompt: Original user prompt
            intent_inference: Result from classify() method
            workflow: Workflow name
        
        Returns:
            Tuple of (question, semantic_view, messages)
        """
        workflows = self.registry.get("workflows", {})
        workflow_key = workflow.strip().upper()
        workflow_registry = workflows.get(workflow_key, {})
        
        # Extract question from inference or use original prompt
        question = None
        if isinstance(intent_inference, dict):
            question = intent_inference.get("parameters", {}).get("question")
        
        if not question:
            question = body_prompt
        
        # Extract semantic_view from inference or use first available
        semantic_view = None
        if isinstance(intent_inference, dict):
            semantic_view = intent_inference.get("parameters", {}).get("semantic_view")
        
        if not semantic_view:
            semantic_views = workflow_registry.get("semantic_views", [])
            if semantic_views:
                semantic_view = semantic_views[0].get("name")
        
        # Extract messages from inference (for multi-turn conversations)
        inferred_messages = None
        if isinstance(intent_inference, dict):
            inferred_messages = intent_inference.get("parameters", {}).get("messages")
        
        if not isinstance(inferred_messages, list) or not inferred_messages:
            inferred_messages = None
        
        return question, semantic_view, inferred_messages
    
    async def fetch_analyst_response(
        self, 
        question: str, 
        semantic_view: str,
        messages: Optional[list] = None,
        base_url: Optional[str] = None
    ) -> dict:
        """
        Call Cortex Analyst API asynchronously
        
        Args:
            question: User's question
            semantic_view: Semantic model name
            messages: Optional conversation history
            base_url: Optional base URL override
        
        Returns:
            Dict with Cortex Analyst response
        """
        if base_url is None:
            base_url = self.registry.get("base_url_env", os.getenv("CORTEX_API_URL", ""))
            if not base_url.endswith("/"):
                base_url = base_url.rstrip("/")
        
        # Build payload for Cortex Analyst
        payload = {
            "question": question,
            "semantic_model_name": semantic_view
        }
        
        if messages:
            payload["messages"] = messages
        
        # Call Cortex Analyst API
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    url=f"{base_url}/titan-data-products/ask-analyst",
                    json=payload,
                    timeout=60.0
                )
                response.raise_for_status()
                return response.json()
            
            except httpx.HTTPStatusError as e:
                return {
                    "error": f"HTTP {e.response.status_code}",
                    "detail": e.response.text,
                    "question": question
                }
            except Exception as e:
                return {
                    "error": "Request failed",
                    "detail": str(e),
                    "question": question
                }
