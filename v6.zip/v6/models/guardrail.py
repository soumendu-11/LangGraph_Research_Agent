"""
Content Guardrail Module
Uses Claude Sonnet 4.5 (workflow model) to analyse user questions
and block inappropriate content.
"""

import json
import boto3
from typing import Callable, Dict, List, Optional

from geoscience_agent.config import config
from geoscience_agent.models.bedrock_stream import invoke_anthropic_bedrock_stream


class ContentGuardrail:
    """
    LLM-based content guardrail using the workflow model (Sonnet 4.5).
    Analyzes user questions before processing to block inappropriate content.
    Loads prompt from prompts/guardrail_prompt.txt.
    """
    
    def __init__(self, model_id: Optional[str] = None):
        self.model_id = model_id or config.BEDROCK_WORKFLOW_MODEL_ID
        self.bedrock = boto3.client('bedrock-runtime', region_name=config.AWS_REGION, verify=False)
        self.guardrail_prompt = self._load_prompt()
    
    @staticmethod
    def _load_prompt() -> str:
        """Load guardrail prompt from prompts/ folder."""
        with open(config.GUARDRAIL_PROMPT_FILE, 'r', encoding='utf-8') as f:
            return f.read()
    
    def check_question(
        self,
        question: str,
        conversation_history: Optional[List] = None,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> Dict:
        """
        Check if a question is allowed.

        Args:
            question: User's question to check
            conversation_history: List of prior Q&A turns (used to detect follow-up without context)

        Returns:
            Dict with is_allowed, category, reason, suggested_response
        """
        print(f"\n{'='*60}")
        print("🛡️  SONNET GUARDRAIL CHECK")
        print(f"{'='*60}")
        print(f"Question: {question}")
        conversation_turns = len(conversation_history) if conversation_history else 0
        print(f"Conversation turns: {conversation_turns}")

        formatted_prompt = self.guardrail_prompt.format(
            question=question,
            conversation_turns=conversation_turns,
        )
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 512,
            "temperature": 0.0,
            "top_k": 1,
            "messages": [
                {"role": "user", "content": formatted_prompt}
            ]
        })
        
        try:
            body_dict = json.loads(body)
            result_text, usage_dict = invoke_anthropic_bedrock_stream(
                self.bedrock, self.model_id, body_dict, on_text_delta=on_text_delta
            )
            if not result_text:
                result_text = "{}"

            result = self._parse_guardrail_response(result_text)

            result["usage"] = {
                "input_tokens": usage_dict.get("input_tokens", 0),
                "output_tokens": usage_dict.get("output_tokens", 0),
            }
            
            if result["is_allowed"]:
                print(f"✅ ALLOWED - Category: {result['category']}")
            else:
                print(f"🚫 BLOCKED - Category: {result['category']}")
                print(f"   Reason: {result['reason']}")
            
            return result
            
        except Exception as e:
            print(f"⚠️  Guardrail check failed: {str(e)}")
            # Fail open (allow) if guardrail has an error
            return {
                "is_allowed": True,
                "category": "error",
                "reason": f"Guardrail check failed: {str(e)}",
                "suggested_response": None,
                "usage": {"input_tokens": 0, "output_tokens": 0},
            }
    
    def _parse_guardrail_response(self, response_text: str) -> Dict:
        """Parse guardrail response"""
        try:
            # Extract JSON
            clean = response_text.strip()
            if "```json" in clean:
                clean = clean.split("```json")[1].split("```")[0].strip()
            elif "```" in clean:
                clean = clean.split("```")[1].split("```")[0].strip()
            
            result = json.loads(clean)
            
            # Ensure required fields
            return {
                "is_allowed": result.get("is_allowed", True),
                "category": result.get("category", "unknown"),
                "reason": result.get("reason", "No reason provided"),
                "suggested_response": result.get("suggested_response", 
                    "I apologize, but I can only answer questions about oil & gas discoveries and technical petroleum engineering topics.")
            }
            
        except Exception as e:
            print(f"Warning: Failed to parse guardrail response: {str(e)}")
            # Fail open on parse error
            return {
                "is_allowed": True,
                "category": "parse_error",
                "reason": f"Parse error: {str(e)}",
                "suggested_response": None
            }


__all__ = ['ContentGuardrail']