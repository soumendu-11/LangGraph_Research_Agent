"""
AWS Bedrock Model Configurations

All tasks use Sonnet 4.5 — guardrail, intent routing, summarization, multiturn, G-Eval.

Model IDs are centralized in geoscience_agent.config.
This file exposes handy config dicts for backward compatibility and MLflow logging.
"""

from geoscience_agent.config import config

# Eval config — Sonnet 4.5 for G-Eval reference-based scoring
EVAL_CONFIG = {
    "model_id": config.BEDROCK_EVAL_MODEL_ID,
    "max_tokens": 4096,
    "temperature": 0.0,
    "top_k": 1,
    "top_p": 0.999,
    "anthropic_version": "bedrock-2023-05-31",
    "use_cases": [
        "g_eval_scoring",
        "response_evaluation",
    ],
    "cost_per_1k_tokens": {
        "input": 0.003,
        "output": 0.015
    }
}

# Workflow config — Sonnet 4.5 for all core workflow tasks
SONNET_45_CONFIG = {
    "model_id": config.BEDROCK_WORKFLOW_MODEL_ID,
    "max_tokens": 4096,
    "temperature": 0.0,
    "top_k": 1,
    "top_p": 0.999,
    "anthropic_version": "bedrock-2023-05-31",
    "use_cases": [
        "guardrail",
        "intent_routing",
        "summarization",
        "multiturn",
    ],
    "cost_per_1k_tokens": {
        "input": 0.003,
        "output": 0.015
    }
}

DEFAULT_MODEL = config.BEDROCK_WORKFLOW_MODEL_ID

__all__ = ['EVAL_CONFIG', 'SONNET_45_CONFIG', 'DEFAULT_MODEL']