"""
Multi-turn Processor Module
Handles id=1 conversational queries with deterministic responses from JSON
and reference-based G-Eval evaluation (LLM call for verification only)
"""

import json
from datetime import datetime
from typing import Dict, Optional

from geoscience_agent.config import config
from geoscience_agent.models import GEvalEvaluator


class MultiTurnProcessor:
    """
    Process multi-turn conversational queries (id=1 in JSON).
    - Deterministic: Return pre-written answer from JSON (no LLM generation)
    - G-Eval: Reference-based LLM call to evaluate the deterministic answer
    """
    
    def __init__(self, model_id: Optional[str] = None):
        self.model_id = model_id or config.BEDROCK_WORKFLOW_MODEL_ID
        self.evaluator = GEvalEvaluator()
    
    def process_deterministic(self, state: Dict) -> Dict:
        """
        Process query using deterministic response from JSON + G-Eval evaluation.
        
        Steps:
        1. Find the best matching Q&A entry from JSON (cosine similarity)
        2. Return the pre-written answer (NO LLM call)
        3. Evaluate the answer using G-Eval (LLM call for verification)
        
        Args:
            state: Current workflow state
        
        Returns:
            Updated state with deterministic response and G-Eval scores
        """
        print(f"\n{'='*60}")
        print("MULTI-TURN PROCESSOR (Deterministic + G-Eval)")
        print(f"{'='*60}")
        
        request = state.get("current_request", "")
        qa_data = state.get("qa_data", [])
        
        print(f"Request: {request}")
        print(f"Turn number: {state.get('turn_number', 1)}")
        print(f"Available data rows: {len(qa_data)}")
        
        # Check if we have analyst guidance instead of data
        if state.get("status") == "analyst_guidance":
            analyst_message = state.get("analyst_message", "")
            suggestions = state.get("analyst_suggestions", [])
            
            print(f"Cortex Analyst provided guidance (no SQL generated)")
            
            response = {
                "summary": analyst_message,
                "key_insights": [
                    {
                        "insight": "Query Clarification Needed",
                        "description": "Cortex Analyst couldn't generate SQL for this query and provided suggestions"
                    }
                ],
                "data_table": [],
                "suggestions": suggestions
            }
            
            return {
                **state,
                "current_response": response,
                "response_summary": analyst_message,
                "key_insights": response["key_insights"],
                "data_table": [],
                "evaluation_scores": None,
                "response_metadata": {
                    "source": "cortex_analyst_guidance",
                    "handler": "multiturn_handler",
                    "has_suggestions": len(suggestions) > 0
                },
                "status": "multiturn_processed_guidance",
                "timestamp": datetime.now().isoformat()
            }
        
        if not qa_data:
            # Check if we have detailed error information
            error_category = state.get("error_category", "unknown")
            error_type = state.get("error_type", "unknown")
            error_msg = state.get("error", "No data available from Cortex Analyst API")
            suggestion = state.get("error_suggestion", "")
            
            # Create user-friendly error message based on error type
            if error_category == "auth":
                user_message = f"🔐 Authentication Error: {suggestion if suggestion else 'Your AWS credentials may have expired. Please refresh them and try again.'}"
                insight_desc = "AWS credentials expired or invalid. Run 'aws sso login' to refresh."
            elif error_category == "network":
                user_message = f"🌐 Network Error: {suggestion if suggestion else 'Could not connect to the Cortex Analyst API. Please check your network connection.'}"
                insight_desc = "Network connectivity issue. Check VPN or internet connection."
            elif error_category == "api":
                user_message = f"⚠️ API Error: {suggestion if suggestion else 'The Cortex Analyst API encountered an error. Please try again.'}"
                insight_desc = f"API returned an error. {suggestion}"
            else:
                user_message = f"❌ Error: {suggestion if suggestion else 'Could not retrieve data from the Cortex Analyst API. Please try again or contact support.'}"
                insight_desc = error_msg
            
            print(f"ERROR: {error_category}/{error_type} - {error_msg}")
            
            return {
                **state,
                "status": "error",
                "error": error_msg,
                "error_type": error_type,
                "error_category": error_category,
                "current_response": {
                    "summary": user_message,
                    "key_insights": [
                        {
                            "insight": f"Error: {error_type}",
                            "description": insight_desc
                        }
                    ],
                    "data_table": [],
                    "error_details": {
                        "type": error_type,
                        "category": error_category,
                        "suggestion": suggestion
                    }
                },
                "response_summary": user_message
            }
        
        # Format Cortex Analyst API results into response structure
        generated_sql = state.get("generated_sql", "")
        
        # Create concise summary (SQL is in generated_sql field)
        row_count = len(qa_data)
        summary_parts = [f"Retrieved {row_count} field(s) from Cortex Analyst"]
        
        # Note if hitting API row limit
        if row_count == 100:
            summary_parts.append("(showing maximum 100 rows)")
        
        # Extract column names if available
        if qa_data and len(qa_data) > 0:
            first_row = qa_data[0]
            if isinstance(first_row, dict):
                column_names = list(first_row.keys())
                summary_parts.append(f"with columns: {', '.join(column_names)}")
        
        summary = " ".join(summary_parts)
        
        # Get the actual semantic model used from state
        semantic_model_used = state.get("semantic_model_name", "Unknown")
        if not semantic_model_used or semantic_model_used == "Unknown":
            # Try to get from intent_classification parameters
            intent_classification = state.get("intent_classification", {})
            if isinstance(intent_classification, dict):
                parameters = intent_classification.get("parameters", {})
                semantic_model_used = parameters.get("semantic_view", "Unknown")
        
        # Build response from API results
        response = {
            "summary": summary,
            "key_insights": [
                {
                    "insight": "Cortex Analyst Query Executed",
                    "description": f"Generated SQL query and retrieved {len(qa_data)} records"
                },
                {
                    "insight": "Data Source",
                    "description": f"Semantic Model: {semantic_model_used}"
                }
            ],
            "data_table": qa_data,  # Raw API results as data table
            "generated_sql": generated_sql  # Include SQL in response
        }
        
        print(f"\nFORMATTED CORTEX ANALYST RESPONSE")
        print(f"   Summary: {response['summary'][:150]}...")
        print(f"   Data rows: {len(response.get('data_table', []))}")
        
        # Build gold standard reference for G-Eval
        gold_response = {
            "summary": response["summary"],
            "key_insights": response["key_insights"],
            "data_table": response["data_table"]
        }
        gold_answer = json.dumps(gold_response, indent=2)
        
        # Skip G-Eval for now - just return the formatted response
        # TODO: Implement G-Eval for Cortex Analyst results if needed
        print(f"\nSkipping G-Eval (not applicable for direct API results)")
        
        return {
            **state,
            "current_response": response,
            "response_summary": response.get("summary", ""),
            "key_insights": response.get("key_insights", []),
            "data_table": response.get("data_table", []),
            "evaluation_scores": None,  # Skip evaluation for API results
            "response_metadata": {
                "source": "cortex_analyst_api",
                "handler": "multiturn_handler",
                "rows_returned": len(qa_data),
                "sql_generated": bool(generated_sql)
            },
            "status": "multiturn_processed_api",
            "timestamp": datetime.now().isoformat()
        }


__all__ = ['MultiTurnProcessor']