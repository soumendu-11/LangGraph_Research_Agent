"""
Follow-up Suggestion Generator
Generates 2 follow-up questions from the last Q&A pair using Bedrock LLM.
"""

import json
from pathlib import Path
from typing import List

import boto3

from geoscience_agent.config import config
from geoscience_agent.models.bedrock_stream import invoke_anthropic_bedrock_stream

_bedrock_client = boto3.client(
    "bedrock-runtime", region_name=config.AWS_REGION, verify=False
)
_followup_prompt_template = Path(
    config.FOLLOWUP_SUGGESTIONS_PROMPT_FILE
).read_text(encoding="utf-8")

_DEFAULT_SUGGESTIONS = [
    "Tell me more about the key points in the previous answer",
    "How does this compare to similar cases?",
]


def generate_followup_suggestions(
    question: str,
    answer: str,
    turn: int,
    total: int,
) -> List[str]:
    """Return 2 follow-up question suggestions based on the last Q&A pair."""
    prompt = _followup_prompt_template.format(
        question=question,
        answer=answer,
        turn=turn,
        total=total,
    )
    try:
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 300,
            "temperature": 0.0,
            "top_k": 1,
            "system": "You suggest follow-up questions. Return only a JSON array of 2 strings.",
            "messages": [{"role": "user", "content": prompt}],
        })
        body_dict = json.loads(body)
        text, _ = invoke_anthropic_bedrock_stream(
            _bedrock_client,
            config.BEDROCK_WORKFLOW_MODEL_ID,
            body_dict,
        )
        if not text:
            text = "[]"
        suggestions = json.loads(text)
        if isinstance(suggestions, list) and len(suggestions) >= 2:
            return [str(s) for s in suggestions[:2]]
    except Exception as e:
        print(f"  Follow-up generation failed: {e}")
    return list(_DEFAULT_SUGGESTIONS)
