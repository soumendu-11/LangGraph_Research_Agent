"""
Summarization Processor Module
Handles summary/stats queries using context from sample JSON data files.
Implements a prompt-based summarization agent with a single LLM call.
Uses opp_screening_prompt.md as the domain system prompt.
Context sent to the LLM: generated_sql + per-column stats + top 10 records.
Generates a Vega-Lite visualization from the top 10 records in the stats.
"""

import json
import os
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

import boto3

from geoscience_agent.config import config
from geoscience_agent.models.bedrock_stream import (
    invoke_anthropic_bedrock_stream,
    resolve_llm_stream_callback,
)


class SummarizationProcessor:
    """
    Process summary/stats queries using sample JSON data.
    - Uses opp_screening_prompt.md as the domain system prompt
    - Single LLM call: prompt-based statistical summarization
    - Context: generated_sql + stats + top 10 records
    - Generates Vega-Lite chart from stats.top_records
    """

    _ANSWER_PROMPT = (
        "You are a data analyst. Use the following CONTEXT as your ONLY data source. "
        "Answer the question directly.\n\n"
        "CONTEXT:\n{context}\n\n"
        "{history_block}"
        "QUESTION:\n{request}\n\n"
        "CRITICAL RULES:\n"
        "1. Answer the question directly. Do NOT start with 'Executive Summary' or "
        "'The SQL query retrieves' — just answer.\n"
        "2. Do NOT fabricate any information not in the CONTEXT.\n"
        "3. NEVER output raw JSON data. Present data as readable narrative.\n"
        "4. Do NOT dump or echo back the source data.\n"
        "5. Do NOT recommend charts or visualizations.\n"
        "6. If continuing a conversation, answer in the context of the prior conversation.\n\n"
        "Use Markdown formatting. Use exact numbers from the statistics."
    )

    def __init__(self, model_id: Optional[str] = None):
        self.model_id = model_id or config.BEDROCK_WORKFLOW_MODEL_ID
        self.bedrock = boto3.client(
            'bedrock-runtime',
            region_name=config.AWS_REGION,
            verify=False,
        )
        self.domain_prompt = self._load_domain_prompt()
        self._cortex_chunk_summary = self._load_prompt(
            "CORTEX_CHUNK_SUMMARY_FILE", "cortex_chunk_summary.txt"
        )
        self._no_data_retrieval_chunk_summary = self._load_prompt(
            "NO_DATA_RETRIEVAL_CHUNK_SUMMARY_FILE", "no_data_retrieval_chunk_summary.txt"
        )

    @staticmethod
    def _load_domain_prompt() -> str:
        path = getattr(config, "OPP_SCREENING_PROMPT_FILE", None)
        if path and os.path.exists(path):
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        prompts_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "prompts",
        )
        with open(os.path.join(prompts_dir, "opp_screening_prompt.md"), "r", encoding="utf-8") as f:
            return f.read()

    def _load_prompt(self, config_key: str, fallback_name: str) -> str:
        """Load prompt from config path or prompts folder."""
        path = getattr(config, config_key, None)
        if path and os.path.exists(path):
            return open(path, "r", encoding="utf-8").read().strip()
        prompts_dir = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "prompts",
        )
        with open(os.path.join(prompts_dir, fallback_name), "r", encoding="utf-8") as f:
            return f.read().strip()

    @staticmethod
    def _generate_vega_lite_spec(
        top_records: List[Dict],
        columns: List[str],
    ) -> Optional[Dict[str, Any]]:
        """
        Generate a Vega-Lite bar chart spec from the top records in stats.
        """
        if not top_records or not columns:
            return None

        numeric_cols = [
            c for c in columns
            if c in top_records[0] and isinstance(top_records[0].get(c), (int, float))
        ]
        categorical_cols = [
            c for c in columns
            if c in top_records[0] and c not in numeric_cols
        ]

        if not numeric_cols or not categorical_cols:
            return None

        x_col = categorical_cols[0]
        y_col = numeric_cols[0]
        title = f"{y_col.replace('_', ' ').title()} by {x_col.replace('_', ' ').title()}"

        values = [
            {col: rec.get(col) for col in columns if col in rec}
            for rec in top_records
        ]

        return {
            "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
            "title": title,
            "width": 700,
            "height": 400,
            "data": {"values": values},
            "mark": {"type": "bar", "cornerRadiusEnd": 4, "tooltip": True},
            "encoding": {
                "x": {
                    "field": x_col,
                    "type": "nominal",
                    "sort": "-y",
                    "axis": {"labelAngle": -45, "labelLimit": 150},
                },
                "y": {
                    "field": y_col,
                    "type": "quantitative",
                    "title": y_col.replace("_", " ").title(),
                },
                "color": {
                    "field": y_col,
                    "type": "quantitative",
                    "scale": {"scheme": "tealblues"},
                    "legend": None,
                },
            },
        }

    def process(self, state: Dict) -> Dict:
        """
        Run prompt-based summarization using generated_sql + stats as context.
        Supports multi-turn: includes conversation history so the LLM can
        answer follow-up questions ("tell me more", "summarize") in context.
        """
        print(f"\n{'='*60}")
        print("SUMMARIZATION PROCESSOR (Prompt-Based)")
        print(f"{'='*60}")

        self._llm_stream_cb = resolve_llm_stream_callback(
            state.get("metadata") or {}, "summarization"
        )

        request = state.get("current_request", "")
        context = state.get("summarization_context", "")
        summarization_data = state.get("summarization_data", {})

        top_records = summarization_data.get("top_records", [])
        columns = summarization_data.get("columns", [])
        generated_sql = summarization_data.get("generated_sql", "")
        has_more = summarization_data.get("has_more", False)
        computed_stats = summarization_data.get("stats", {})
        record_count = len(top_records) if top_records else 10

        conversation_history = state.get("conversation_history", [])
        turn_number = state.get("turn_number", 1)
        running_summary = state.get("running_summary", "")

        print(f"Question : {request}")
        print(f"Context  : {context[:200]}...")
        print(f"Top records: {record_count}")
        print(f"Turn number: {turn_number}")
        print(f"Conversation history turns: {len(conversation_history)}")
        print(f"Running summary: {'yes' if running_summary else 'none'} "
              f"({len(running_summary)} chars)")

        # Determine which turns fall in the current chunk (since last summary).
        # Summaries are generated after turns 3, 6, 9, ...
        # So the last summary covers turns up to the most recent multiple of 3
        # that is strictly less than turn_number.
        last_summarized_turn = ((turn_number - 1) // self.SUMMARY_INTERVAL) * self.SUMMARY_INTERVAL
        recent_history = conversation_history[last_summarized_turn:]

        history_block = ""
        if running_summary or recent_history:
            parts = []
            if running_summary:
                parts.append(
                    f"SUMMARY OF EARLIER CONVERSATION (turns 1–{last_summarized_turn}):\n"
                    f"{running_summary}"
                )
                print(f"  Sending running summary (turns 1–{last_summarized_turn}) "
                      f"+ {len(recent_history)} recent full turns")
            else:
                print(f"  Sending {len(recent_history)} full turns (no summary yet)")

            if recent_history:
                recent_lines = []
                for turn in recent_history:
                    q = turn.get("question", "")
                    a = turn.get("answer", "")
                    if isinstance(a, dict):
                        a = a.get("summary", str(a))
                    recent_lines.append(f"User: {q}")
                    recent_lines.append(f"Assistant: {a}")
                parts.append(
                    f"RECENT CONVERSATION (turns {last_summarized_turn + 1}–"
                    f"{len(conversation_history)}):\n"
                    + "\n".join(recent_lines)
                )

            history_block = "\n\n" + "\n\n".join(parts) + "\n"

        print(f"\n--- Answer generation (LLM call, turn {turn_number}) ---")

        summarization_prompt = self._ANSWER_PROMPT.format(
            context=context,
            history_block=history_block,
            request=request,
        )

        system_prompt = state.get("domain_prompt_override") or self.domain_prompt
        if state.get("domain_prompt_override"):
            print("  Using domain prompt override: opp_screening_prompt.md")

        summary_answer, summarization_usage = self._llm_call(
            system=system_prompt,
            user=summarization_prompt,
        )
        print(f"Summarization answer length: {len(summary_answer)} chars")

        total_input = summarization_usage.get("input_tokens", 0)
        total_output = summarization_usage.get("output_tokens", 0)

        print(f"\n--- Generating Vega-Lite Visualization ({record_count} records) ---")
        vega_lite_spec = self._generate_vega_lite_spec(top_records, columns)

        if vega_lite_spec:
            print(f"Vega-Lite spec generated (bar chart, "
                  f"data points: {len(vega_lite_spec.get('data', {}).get('values', []))})")
        else:
            print("No Vega-Lite spec generated")

        analysis_block = {
            "sql": generated_sql,
            "columns": columns,
            "stats": computed_stats,
            "top_records": top_records,
            "has_more": has_more,
            "correlation_id": summarization_data.get("correlation_id", ""),
        }

        response = {
            "summary": summary_answer,
            "key_insights": [
                {"insight": "Prompt-Based Summary", "description": summary_answer}
            ],
            "data_table": top_records,
            "vega_lite_spec": vega_lite_spec,
            "analysis": analysis_block,
        }

        existing_turns = state.get("summarization_turns", [])
        summarization_turns = existing_turns + [
            {
                "turn": turn_number,
                "label": "Summary" if turn_number == 1 else f"Follow-up (turn {turn_number})",
                "question": request,
                "answer": summary_answer,
                "timestamp": datetime.now().isoformat(),
            }
        ]

        # Generate chunk summary every SUMMARY_INTERVAL turns (3, 6, 9).
        # Turn 4: summary of 1–3. Turn 7: + summary of 4–6. Turn 10: + summary of 7–9.
        new_running_summary = running_summary

        if turn_number % self.SUMMARY_INTERVAL == 0:
            turn_start = last_summarized_turn + 1
            turn_end = turn_number
            chunk_turns = conversation_history[last_summarized_turn:] + [
                {"question": request, "answer": summary_answer}
            ]

            print(f"\n{'='*60}")
            print(f"CONCISE SUMMARY (turns {turn_start}–{turn_end}) — will be used as context for turn {turn_number + 1}+")
            print(f"{'='*60}")

            chunk_summary, run_summary_usage = self._generate_chunk_summary(
                chunk_turns,
                turn_start,
                turn_end,
                route="no_data_retrieval",
                on_text_delta=self._llm_stream_cb,
            )
            new_running_summary = (
                (running_summary + "\n\n" + chunk_summary) if running_summary else chunk_summary
            )
            total_input += run_summary_usage.get("input_tokens", 0)
            total_output += run_summary_usage.get("output_tokens", 0)
            print(f"Generated: {len(chunk_summary)} chars (chunk {turn_start}–{turn_end})")
            print(f"\n{chunk_summary}\n")
        else:
            print(f"\n--- Summary generation skipped (turn {turn_number}, "
                  f"next summary at turn "
                  f"{((turn_number // self.SUMMARY_INTERVAL) + 1) * self.SUMMARY_INTERVAL}) ---")

        print(f"\nSummarization Agent completed — turn {turn_number} (prompt-based) + "
              f"top {record_count} table + Vega-Lite chart")
        print(f"  Stats: {list(computed_stats.keys())}")
        print(f"  Top records: {len(top_records)}")
        print(f"  Has more: {has_more}")
        if new_running_summary:
            print(f"  Running summary: {len(new_running_summary)} chars")

        summarization_token_usage = {
            "input_tokens": total_input,
            "output_tokens": total_output,
        }
        existing_usage = state.get("token_usage") or {}
        merged_usage = {**existing_usage, "summarization": summarization_token_usage}

        return {
            **state,
            "current_response": response,
            "response_summary": summary_answer,
            "key_insights": response["key_insights"],
            "data_table": top_records,
            "vega_lite_spec": vega_lite_spec,
            "evaluation_scores": None,
            "summarization_turns": summarization_turns,
            "running_summary": new_running_summary,
            "token_usage": merged_usage,
            "response_metadata": {
                "is_deterministic": False,
                "handler": "summarization_handler",
                "model_id": self.model_id,
                "turns": turn_number,
                "matched_question": summarization_data.get("prompt", request),
                "has_visualization": vega_lite_spec is not None,
                "has_more": has_more,
                "top_records_count": len(top_records),
                "stats_columns": list(computed_stats.keys()),
            },
            "status": "summarization_processed",
            "timestamp": datetime.now().isoformat(),
        }

    SUMMARY_INTERVAL = 3

    def _generate_chunk_summary(
        self,
        chunk_turns: List[Dict],
        turn_start: int,
        turn_end: int,
        route: str = "cortex",
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> tuple:
        """
        Generate a concise summary of a single 3-turn chunk.
        Used by cortex and no_data_retrieval routes after every 3 turns.
        Returns (summary_text, usage_dict).
        """
        chunk_lines = []
        for t in chunk_turns:
            q = t.get("question", "")
            a = t.get("answer", "")
            if isinstance(a, dict):
                a = a.get("summary", str(a))
            chunk_lines.append(f"Q: {q}")
            chunk_lines.append(f"A: {a}")
        chunk_text = "\n".join(chunk_lines)

        template = (
            self._cortex_chunk_summary
            if route == "cortex"
            else self._no_data_retrieval_chunk_summary
        )
        summary_prompt = template.format(
            turn_start=turn_start,
            turn_end=turn_end,
            chunk_text=chunk_text,
        )
        text, usage = self._llm_call(
            system="You are a precise summarizer. Output only the summary.",
            user=summary_prompt,
            on_text_delta=on_text_delta,
        )
        return text, usage

    def generate_running_summary(
        self,
        conversation_history: List[Dict],
        turn_number: int,
        running_summary: str,
        current_question: str,
        current_answer: str,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> str:
        """
        Generate a concise summary of the current 3-turn chunk only.
        Returns the new chunk summary. Caller appends to running_summary.
        Turn 3: chunk 1–3. Turn 6: chunk 4–6. Turn 9: chunk 7–9.
        """
        last_summarized_turn = ((turn_number - 1) // self.SUMMARY_INTERVAL) * self.SUMMARY_INTERVAL
        turn_start = last_summarized_turn + 1
        turn_end = turn_number

        chunk_turns = conversation_history[last_summarized_turn:] + [
            {"question": current_question, "answer": current_answer}
        ]
        chunk_summary, _ = self._generate_chunk_summary(
            chunk_turns,
            turn_start,
            turn_end,
            route="cortex",
            on_text_delta=on_text_delta,
        )
        return chunk_summary

    def _llm_call(
        self,
        system: str,
        user: str,
        on_text_delta: Optional[Callable[[str], None]] = None,
    ) -> tuple:
        """Returns (text, usage_dict) for MLflow token tracking."""
        default_usage = {"input_tokens": 0, "output_tokens": 0}
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4096,
            "temperature": 0.0,
            "top_k": 1,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        })

        try:
            body_dict = json.loads(body)
            cb = on_text_delta if on_text_delta is not None else getattr(
                self, "_llm_stream_cb", None
            )
            text, usage_dict = invoke_anthropic_bedrock_stream(
                self.bedrock, self.model_id, body_dict, on_text_delta=cb
            )
            return text, usage_dict
        except Exception as e:
            error_msg = f"LLM call failed: {e}"
            print(f"   ERROR: {error_msg}")
            return error_msg, default_usage


__all__ = ["SummarizationProcessor"]
