"""
Processors Package - Business Logic Handlers

This package contains domain-specific processing logic:
- multiturn: Multi-turn conversation handling with G-Eval scoring
- summarization: Prompt-based statistical summarization (single LLM call)
- followup: Follow-up question suggestion generator
"""

from .multiturn import MultiTurnProcessor
from .summarization import SummarizationProcessor
from .followup import generate_followup_suggestions

__all__ = [
    'MultiTurnProcessor',
    'SummarizationProcessor',
    'generate_followup_suggestions',
]
