# api.py
"""
Geoscience LangGraph Agent API
Load .env from v3/ before any other imports so AWS credentials are available for Bedrock.
"""
from pathlib import Path

# Load .env first so AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, AWS_SESSION_TOKEN are available
from dotenv import load_dotenv
_env_path = Path(__file__).resolve().parent / ".env"
load_dotenv(_env_path, override=True)

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel, Field
from typing import Optional, AsyncGenerator, Dict, Any
import json
import asyncio
import queue as queue_module
import threading
import uuid
from datetime import datetime
import sys
import os

from geoscience_agent.config import config
from geoscience_agent.graph_builder import build_discovery_workflow, query_discoveries
from geoscience_agent.models.bedrock_stream import (
    register_llm_stream_queue,
    unregister_llm_stream_queue,
)
from geoscience_agent.integrations import cortex_analyst_retrieval
from geoscience_agent.integrations.cortex_analyst import get_tools
from geoscience_agent.models import EVAL_CONFIG, SONNET_45_CONFIG
import mlflow

def _validate_session_id(raw: Optional[str]) -> Optional[str]:
    """Return the session_id only if it is a valid UUID, otherwise None."""
    if not raw or not raw.strip():
        return None
    try:
        return str(uuid.UUID(raw.strip()))
    except (ValueError, AttributeError):
        return None


app = FastAPI(
    title="Geoscience LangGraph Agent API",
    description="Enterprise geoscience analytics powered by LangGraph, AWS Bedrock, MLflow, and DynamoDB",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request Model
class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=5000, description="User query to process")
    thread_id: str = Field(..., min_length=1, max_length=100, description="Thread ID for conversation context")
    user_id: Optional[str] = Field(None, max_length=100, description="User identifier")
    metadata: Optional[dict] = Field(None, description="Additional metadata")


# Discovery Workflow Request Model (v8_org)
class DiscoveryQueryRequest(BaseModel):
    request: str = Field(..., min_length=1, max_length=5000, description="Discovery query")
    session_id: Optional[str] = Field(
        None,
        max_length=100,
        description="Session ID for multi-turn conversations. Omit for new session; use returned session_id for follow-up turns.",
        example="cda97d89-35fb-4b90-bd9e-2033df39f765",
    )
    metadata: Optional[dict] = Field(None, description="Additional metadata for Cortex Analyst API or data API parameters")


# Discovery Response Model
class DiscoveryResponse(BaseModel):
    status: str
    session_id: str
    is_blocked: bool
    response_summary: Optional[str] = None
    current_response: Optional[Dict[Any, Any]] = None
    evaluation_scores: Optional[Dict[str, float]] = None
    guardrail_check: Optional[Dict[str, Any]] = None
    routing_path: Optional[str] = None
    timestamp: str


# Test page for browser-based API testing
_STATIC_DIR = Path(__file__).parent / "static"


@app.get("/test")
async def test_page():
    """Serve the browser test page for /discovery/query"""
    p = _STATIC_DIR / "test_api.html"
    if not p.exists():
        raise HTTPException(status_code=404, detail="test_api.html not found")
    return FileResponse(p)


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint for ECS/Fargate"""
    return {
        "status": "healthy",
        "service": "geoscience-langgraph-agent",
        "timestamp": datetime.utcnow().isoformat()
    }


# Configuration endpoint
@app.get("/config")
async def get_config():
    """
    Get current configuration settings (for debugging)
    Returns environment-aware configuration
    """
    config_summary = config.get_config_summary()
    warnings = config.validate_config()

    # Check if AWS credentials are loaded (for Bedrock) - does not expose secrets
    aws_credentials_loaded = bool(
        os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY")
    )

    return {
        "config": config_summary,
        "aws_credentials_loaded": aws_credentials_loaded,
        "warnings": warnings if warnings else None,
        "timestamp": datetime.utcnow().isoformat()
    }


# ============================================================
# DISCOVERY WORKFLOW ENDPOINTS
# Current: 9 nodes, 2 conditional routes, 3 independent intent paths
# START → initialize_session → guardrail_check (LLM)
#    → [BLOCKED] → save_session → END
#    → [ALLOWED] → intent_router (Bedrock classification)
#       → [cortex] → load_cortex_tool (Cortex API) → cortex_handler → save_session → END
#       → [no_data_retrieval] → load_no_data_retrieval_node (sample JSON) → no_data_retrieval_handler → save_session → END
#       → [dashboard_load] → map_dashboard_response → save_session → END
#       → [map_update] → map_dashboard_response → save_session → END
# ============================================================

@app.post("/discovery/dashboard")
async def discovery_dashboard(request: DiscoveryQueryRequest):
    """
    Execute discovery workflow forced to map_dashboard_response path.
    Flow: guardrail_check → intent_router → map_dashboard_response → save_session
    """
    metadata = dict(request.metadata or {})
    metadata["force_route"] = "dashboard"
    result = await asyncio.to_thread(
        query_discoveries,
        request=request.request,
        session_id=_validate_session_id(request.session_id),
        metadata=metadata,
    )
    return {
        "status": result.get("status", "unknown"),
        "session_id": result.get("session_id", ""),
        "is_blocked": result.get("is_blocked", False),
        "response_summary": result.get("response_summary"),
        "current_response": result.get("current_response"),
        "intent_route": "dashboard",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/discovery/no_data_retrieval")
async def discovery_no_data_retrieval(request: DiscoveryQueryRequest):
    """
    Execute discovery workflow forced to no_data_retrieval path.
    Flow: guardrail_check → intent_router → load_no_data_retrieval_node → no_data_retrieval_handler → save_session
    """
    metadata = dict(request.metadata or {})
    metadata["force_route"] = "no_data_retrieval"
    result = await asyncio.to_thread(
        query_discoveries,
        request=request.request,
        session_id=_validate_session_id(request.session_id),
        metadata=metadata,
    )
    return {
        "status": result.get("status", "unknown"),
        "session_id": result.get("session_id", ""),
        "is_blocked": result.get("is_blocked", False),
        "response_summary": result.get("response_summary"),
        "current_response": result.get("current_response"),
        "intent_route": "no_data_retrieval",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/discovery/cortex")
async def discovery_cortex(request: DiscoveryQueryRequest):
    """
    Execute discovery workflow forced to cortex path.
    Flow: guardrail_check → intent_router → load_cortex_tool → cortex_handler → save_session
    """
    metadata = dict(request.metadata or {})
    metadata["force_route"] = "cortex"
    result = await asyncio.to_thread(
        query_discoveries,
        request=request.request,
        session_id=_validate_session_id(request.session_id),
        metadata=metadata,
    )
    return {
        "status": result.get("status", "unknown"),
        "session_id": result.get("session_id", ""),
        "is_blocked": result.get("is_blocked", False),
        "response_summary": result.get("response_summary"),
        "current_response": result.get("current_response"),
        "evaluation_scores": result.get("evaluation_scores"),
        "intent_route": "cortex",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/discovery/layer_toggle")
async def discovery_layer_toggle(request: DiscoveryQueryRequest):
    """
    Execute discovery workflow forced to layer_toggle path.
    Flow: guardrail_check → intent_router → map_dashboard_response (layer_toggle branch) → save_session
    Expects metadata.active_layers: list of currently active layer IDs from FE.
    """
    metadata = dict(request.metadata or {})
    metadata["force_route"] = "layer_toggle"
    result = await asyncio.to_thread(
        query_discoveries,
        request=request.request,
        session_id=_validate_session_id(request.session_id),
        metadata=metadata,
    )
    current_response = result.get("current_response") or {}
    return {
        "status": result.get("status", "unknown"),
        "session_id": result.get("session_id", ""),
        "is_blocked": result.get("is_blocked", False),
        "response_summary": result.get("response_summary"),
        "layer_actions": current_response.get("layer_actions", []),
        "matched_layer_ids": current_response.get("matched_layer_ids", []),
        "intent_route": "layer_toggle",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.post("/discovery/query")
async def discovery_query(request: DiscoveryQueryRequest):
    """
    Execute discovery workflow with guardrail, intent classification, and conditional routing.
    
    Current Workflow (9 nodes, 3 independent routes):
    START → initialize_session → guardrail_check (LLM)
      → [BLOCKED] → save_session → END
      → [ALLOWED] → intent_router (Bedrock Sonnet classification)
        → [cortex] → load_cortex_tool (Cortex API) → cortex_handler → save_session → END
        → [no_data_retrieval] → load_no_data_retrieval_node (sample JSON) → no_data_retrieval_handler → save_session → END
        → [dashboard_load] → map_dashboard_response → save_session → END
        → [map_update] → map_dashboard_response → save_session → END
    
    Intents:
    - analytical_question: Complex queries requiring Cortex Analyst API + G-Eval
    - dashboard_load: Field/reservoir dashboard routing (skips Cortex)
    - map_update: Map layer updates (skips Cortex)
    
    Returns:
    - SSE stream with workflow steps, intent classification, and final response
    
    Features:
    - Streaming with Server-Sent Events (SSE)
    - Multi-turn conversation support
    - Real-time step-by-step updates
    - MLflow logging
    """
    async def event_generator() -> AsyncGenerator[str, None]:
        try:
            # START
            yield f"data: {json.dumps({'type': 'start', 'step': 'START', 'message': 'Initializing discovery workflow', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            await asyncio.sleep(0.1)
            
            # STEP 1: initialize_session
            yield f"data: {json.dumps({'type': 'step', 'step': 'initialize_session', 'message': 'Creating/resuming session', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            await asyncio.sleep(0.1)
            
            # STEP 2: guardrail_check
            yield f"data: {json.dumps({'type': 'step', 'step': 'guardrail_check', 'message': 'LLM content filtering (Sonnet 4.5)', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            await asyncio.sleep(0.1)
            
            # Clean up session_id from Swagger UI defaults
            valid_session_id = _validate_session_id(request.session_id)

            stream_queue: queue_module.Queue = queue_module.Queue()
            meta = dict(request.metadata or {})
            # Queue objects cannot be msgpack-serialized by LangGraph checkpointers.
            stream_key = register_llm_stream_queue(stream_queue)
            meta["llm_stream_queue_id"] = stream_key
            result_holder: Dict[str, Any] = {}
            exc_holder: Dict[str, BaseException] = {}

            try:
                def _run_query() -> None:
                    try:
                        result_holder["result"] = query_discoveries(
                            request=request.request,
                            session_id=valid_session_id,
                            metadata=meta,
                        )
                    except BaseException as e:
                        exc_holder["exc"] = e
                    finally:
                        stream_queue.put(None)

                worker = threading.Thread(target=_run_query, daemon=True)
                worker.start()

                while True:
                    item = await asyncio.to_thread(stream_queue.get)
                    if item is None:
                        break
                    if isinstance(item, dict) and item.get("type") == "llm_delta":
                        payload = {
                            **item,
                            "timestamp": datetime.utcnow().isoformat(),
                        }
                        yield f"data: {json.dumps(payload)}\n\n"

                worker.join(timeout=600)
                if "exc" in exc_holder:
                    raise exc_holder["exc"]
                result = result_holder["result"]
            finally:
                unregister_llm_stream_queue(stream_key)
            
            # Check if BLOCKED
            if result.get('is_blocked'):
                yield f"data: {json.dumps({'type': 'blocked', 'step': 'BLOCKED', 'category': result.get('guardrail_check', {}).get('category'), 'reason': result.get('guardrail_check', {}).get('reason'), 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                # save_session
                yield f"data: {json.dumps({'type': 'step', 'step': 'save_session', 'message': 'Saving blocked session', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                # END
                yield f"data: {json.dumps({'type': 'end', 'step': 'END', 'session_id': result.get('session_id'), 'is_blocked': True, 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            
            elif result.get('status') == 'greeting_response':
                # GREETING path (guardrail_check → greeting_response → save_session)
                yield f"data: {json.dumps({'type': 'step', 'step': 'greeting_response', 'message': 'Greeting / incomplete input', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)

                yield f"data: {json.dumps({'type': 'response', 'response': result.get('current_response'), 'response_summary': result.get('response_summary'), 'intent_route': 'greeting', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)

                yield f"data: {json.dumps({'type': 'step', 'step': 'save_session', 'message': 'Saving greeting session', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)

                yield f"data: {json.dumps({'type': 'end', 'step': 'END', 'session_id': result.get('session_id'), 'is_blocked': False, 'timestamp': datetime.utcnow().isoformat()})}\n\n"

            else:
                # ALLOWED path (intent_router → handler → save_session)
                intent_route = result.get('intent_route') or 'cortex'
                intent_classification = result.get('intent_classification') or {}
                classified_intent = intent_classification.get('intent', 'unknown')
                
                yield f"data: {json.dumps({'type': 'step', 'step': 'intent_router', 'message': 'Intent classification', 'intent': classified_intent, 'route': intent_route, 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                # Route-specific processing
                if intent_route == "dashboard":
                    yield f"data: {json.dumps({'type': 'step', 'step': 'map_dashboard_response', 'message': 'Dashboard load (skip Cortex)', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                elif intent_route == "map":
                    is_layer_toggle = result.get('status') == 'layer_toggle_complete'
                    step_msg = 'Layer toggle (skip Cortex)' if is_layer_toggle else 'Map update (skip Cortex)'
                    yield f"data: {json.dumps({'type': 'step', 'step': 'map_dashboard_response', 'message': step_msg, 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                elif intent_route == "no_data_retrieval":
                    yield f"data: {json.dumps({'type': 'step', 'step': 'load_no_data_retrieval_node', 'message': 'Loading sample data (no data retrieval)', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                    yield f"data: {json.dumps({'type': 'step', 'step': 'no_data_retrieval_handler', 'message': 'Prompt-based summary', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                else:
                    yield f"data: {json.dumps({'type': 'step', 'step': 'load_cortex_tool', 'message': 'Calling Cortex Analyst API', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                    yield f"data: {json.dumps({'type': 'step', 'step': 'cortex_handler', 'message': 'Deterministic response + G-Eval', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                
                response_data = {
                    'type': 'response',
                    'response': result.get('current_response'),
                    'response_summary': result.get('response_summary'),
                    'evaluation_scores': result.get('evaluation_scores'),
                    'intent_route': intent_route,
                    'timestamp': datetime.utcnow().isoformat()
                }
                
                if result.get('error_type'):
                    response_data['error_details'] = {
                        'error_type': result.get('error_type'),
                        'error_category': result.get('error_category'),
                        'error_suggestion': result.get('error_suggestion')
                    }
                
                yield f"data: {json.dumps(response_data)}\n\n"
                await asyncio.sleep(0.1)
                
                if result.get('evaluation_scores'):
                    yield f"data: {json.dumps({'type': 'step', 'step': 'g_eval', 'message': 'LLM verification', 'scores': result.get('evaluation_scores'), 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                    await asyncio.sleep(0.1)
                
                yield f"data: {json.dumps({'type': 'step', 'step': 'save_session', 'message': 'Persisting to DynamoDB', 'timestamp': datetime.utcnow().isoformat()})}\n\n"
                await asyncio.sleep(0.1)
                
                yield f"data: {json.dumps({'type': 'end', 'step': 'END', 'session_id': result.get('session_id'), 'is_blocked': False, 'timestamp': datetime.utcnow().isoformat()})}\n\n"
            
        except Exception as e:
            import traceback
            error_details = {
                "type": "error",
                "error": str(e),
                "error_type": type(e).__name__,
                "traceback": traceback.format_exc(),
                "timestamp": datetime.utcnow().isoformat()
            }
            yield f"data: {json.dumps(error_details)}\n\n"
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


# ============================================================
# CONVERSATION HISTORY & TOOLS ENDPOINTS
# ============================================================

# Get conversation history endpoint
@app.get("/conversations/{thread_id}")
async def get_conversation_history(thread_id: str):
    """Retrieve conversation history for a given thread."""
    try:
        # This is a placeholder - implement actual history retrieval
        return {
            "status": "success",
            "thread_id": thread_id,
            "message": "History retrieval not yet implemented. Use checkpointer.get_tuple(config)"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# List available tools endpoint
@app.get("/tools")
async def list_tools():
    """List all available geoscience agent tools"""
    tools = get_tools()
    tool_list = [
        {
            "name": tool.name,
            "description": tool.description,
        }
        for tool in tools
    ]
    
    return {
        "status": "success",
        "tools": tool_list,
        "count": len(tool_list)
    }


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "service": "Geoscience LangGraph Agent API",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "health": "/health",
            "discovery": "/discovery/query (POST - SSE streaming with state management)",
            "discovery_dashboard": "/discovery/dashboard (POST - forced map_dashboard_response path)",
            "discovery_no_data_retrieval": "/discovery/no_data_retrieval (POST - forced load_no_data_retrieval_node → no_data_retrieval_handler path)",
            "discovery_cortex": "/discovery/cortex (POST - forced load_cortex_tool → cortex_handler path)",
            "discovery_layer_toggle": "/discovery/layer_toggle (POST - forced layer_toggle path via map_dashboard_response)",
            "conversations": "/conversations/{thread_id} (GET - conversation history)",
            "tools": "/tools",
            "docs": "/docs"
        },
        "discovery_workflow": {
            "endpoint": "/discovery/query",
            "method": "POST",
            "description": "Complete discovery agent with multi-turn conversations and state persistence",
            "flow": "START → initialize_session → guardrail_check → [BLOCKED/ALLOWED] → intent_router → [cortex|no_data_retrieval|dashboard|map] → save_session → END",
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )
