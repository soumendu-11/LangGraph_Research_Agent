"""
Centralized Configuration Management
Loads environment-specific settings from environment variables with sensible defaults
"""

import hashlib
import os
from pathlib import Path
from typing import Dict, Optional

from dotenv import load_dotenv

# Load .env from v3/ so AWS credentials (AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY,
# AWS_SESSION_TOKEN) are available for Bedrock, regardless of how the app is started.
_env_path = Path(__file__).resolve().parent / ".env"
if _env_path.exists():
    load_dotenv(_env_path, override=True)
else:
    # Fallback: try parent dir (e.g. when running from app root)
    _fallback = Path(__file__).resolve().parent.parent / "v3" / ".env"
    if _fallback.exists():
        load_dotenv(_fallback, override=True)


class Config:
    """Centralized configuration for geoscience agent"""
    
    # ============================================================================
    # ENVIRONMENT
    # ============================================================================
    ENVIRONMENT = os.getenv("DEPLOYMENT_ENV", "local")  # local, production, staging
    IS_PRODUCTION = ENVIRONMENT == "production"
    IS_LOCAL = ENVIRONMENT == "local"
    
    # ============================================================================
    # AWS CONFIGURATION
    # ============================================================================
    AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
    
    # ============================================================================
    # BEDROCK MODEL CONFIGURATION
    # ============================================================================
    BEDROCK_SONNET_MODEL_ID = os.getenv(
        "BEDROCK_SONNET_MODEL_ID",
        "us.anthropic.claude-sonnet-4-20250514-v1:0"
    )
    # Workflow model — Sonnet 4.5 for guardrail, intent routing, summarization, multiturn
    BEDROCK_WORKFLOW_MODEL_ID = os.getenv("BEDROCK_WORKFLOW_MODEL_ID", BEDROCK_SONNET_MODEL_ID)
    # Eval model — Sonnet 4.5 for G-Eval reference-based comparison
    BEDROCK_EVAL_MODEL_ID = os.getenv("BEDROCK_EVAL_MODEL_ID", BEDROCK_SONNET_MODEL_ID)
    # Default model (backwards compat)
    BEDROCK_MODEL_ID = os.getenv("BEDROCK_MODEL_ID", BEDROCK_SONNET_MODEL_ID)
    
    # ============================================================================
    # CORTEX ANALYST API CONFIGURATION
    # ============================================================================
    CORTEX_API_URL = os.getenv(
        "CORTEX_API_URL",
        "https://dev-api.titan.spglobal.com/spge-titan-api-stage/titan-data-products/ask-analyst"
    )
    CORTEX_API_TIMEOUT = int(os.getenv("CORTEX_API_TIMEOUT", "60"))
    
    # ============================================================================
    # MLFLOW CONFIGURATION
    # ============================================================================
    # Use different MLflow URLs for local vs production
    if IS_LOCAL:
        MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://mlflow:5000")
    else:
        MLFLOW_TRACKING_URI = os.getenv(
            "MLFLOW_TRACKING_URI",
            "https://dev-api.titan.spglobal.com/spge-titan-api-stage/mlflow"
        )
    
    MLFLOW_EXPERIMENT_NAME = os.getenv("MLFLOW_EXPERIMENT_NAME", "Discovery_Workflow")
    MLFLOW_EXPERIMENT_NAME_NOTEBOOK = os.getenv(
        "MLFLOW_EXPERIMENT_NAME_NOTEBOOK", "Discovery_Workflow_Notebook_http"
    )

    # ============================================================================
    # DYNAMODB CONFIGURATION
    # ============================================================================
    USE_DYNAMODB = os.getenv("USE_DYNAMODB", "false").lower() == "true"
    DYNAMODB_TABLE_NAME = os.getenv(
        "DYNAMODB_TABLE_NAME",
        "spge-titan-langgraph-checkpoints" if IS_PRODUCTION else "langgraph_checkpoints"
    )
    
    # ============================================================================
    # SESSION MANAGEMENT
    # ============================================================================
    SESSIONS_DIR = os.getenv("SESSIONS_DIR", "sessions")
    
    # ============================================================================
    # FILE PATHS (relative to geoscience_agent directory)
    # ============================================================================
    # Base directory for data files
    BASE_DIR = Path(__file__).parent
    DATA_DIR = BASE_DIR / "data"
    PROMPTS_DIR = BASE_DIR / "prompts"
    
    # Specific data files
    ROUTE_REGISTRY_FILE = os.getenv(
        "ROUTE_REGISTRY_FILE",
        str(DATA_DIR / "route_registry.json")
    )
    LAYER_DICTIONARY_FILE = os.getenv(
        "LAYER_DICTIONARY_FILE",
        str(DATA_DIR / "layer_dictionary.json")
    )
    
    # Prompt files
    GUARDRAIL_PROMPT_FILE = os.getenv(
        "GUARDRAIL_PROMPT_FILE",
        str(PROMPTS_DIR / "guardrail_prompt.txt")
    )
    INTENT_ROUTER_PROMPT_FILE = os.getenv(
        "INTENT_ROUTER_PROMPT_FILE",
        str(PROMPTS_DIR / "intent_router_prompt.txt")
    )
    CORTEX_CHUNK_SUMMARY_FILE = os.getenv(
        "CORTEX_CHUNK_SUMMARY_FILE",
        str(PROMPTS_DIR / "cortex_chunk_summary.txt")
    )
    NO_DATA_RETRIEVAL_CHUNK_SUMMARY_FILE = os.getenv(
        "NO_DATA_RETRIEVAL_CHUNK_SUMMARY_FILE",
        str(PROMPTS_DIR / "no_data_retrieval_chunk_summary.txt")
    )
    EVAL_PROMPT_WITH_REFERENCE_FILE = os.getenv(
        "EVAL_PROMPT_WITH_REFERENCE_FILE",
        str(PROMPTS_DIR / "eval_prompt_with_reference.txt")
    )
    OPP_SCREENING_PROMPT_FILE = os.getenv(
        "OPP_SCREENING_PROMPT_FILE",
        str(PROMPTS_DIR / "opp_screening_prompt.md")
    )
    FOLLOWUP_SUGGESTIONS_PROMPT_FILE = os.getenv(
        "FOLLOWUP_SUGGESTIONS_PROMPT_FILE",
        str(PROMPTS_DIR / "followup_suggestions_prompt.txt")
    )

    # Prompt versioning (computed from file content hash for MLflow tracking)
    @classmethod
    def get_prompt_versions(cls) -> Dict[str, str]:
        """Compute version hashes for all prompt files for MLflow tracking."""
        versions = {}
        for name, path in [
            ("guardrail", cls.GUARDRAIL_PROMPT_FILE),
            ("intent_router", cls.INTENT_ROUTER_PROMPT_FILE),
            ("cortex_chunk_summary", cls.CORTEX_CHUNK_SUMMARY_FILE),
            ("no_data_retrieval_chunk_summary", cls.NO_DATA_RETRIEVAL_CHUNK_SUMMARY_FILE),
            ("eval_prompt_with_reference", cls.EVAL_PROMPT_WITH_REFERENCE_FILE),
            ("opp_screening", cls.OPP_SCREENING_PROMPT_FILE),
            ("followup_suggestions", cls.FOLLOWUP_SUGGESTIONS_PROMPT_FILE),
        ]:
            p = Path(path)
            if p.exists():
                content = p.read_text(encoding="utf-8")
                versions[name] = hashlib.sha256(content.encode()).hexdigest()[:12]
            else:
                versions[name] = "missing"
        return versions
    
    # ============================================================================
    # LOGGING
    # ============================================================================
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
    
    # ============================================================================
    # API CONFIGURATION
    # ============================================================================
    API_HOST = os.getenv("API_HOST", "0.0.0.0")
    API_PORT = int(os.getenv("API_PORT", "8000"))
    API_WORKERS = int(os.getenv("API_WORKERS", "1"))
    
    # ============================================================================
    # CORS CONFIGURATION
    # ============================================================================
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "*").split(",")
    
    @classmethod
    def get_config_summary(cls) -> dict:
        """Get a summary of current configuration (for debugging)"""
        return {
            "environment": cls.ENVIRONMENT,
            "aws_region": cls.AWS_REGION,
            "bedrock_model_id": cls.BEDROCK_MODEL_ID,
            "bedrock_workflow_model_id": cls.BEDROCK_WORKFLOW_MODEL_ID,
            "bedrock_eval_model_id": cls.BEDROCK_EVAL_MODEL_ID,
            "cortex_api_url": cls.CORTEX_API_URL,
            "mlflow_tracking_uri": cls.MLFLOW_TRACKING_URI,
            "use_dynamodb": cls.USE_DYNAMODB,
            "dynamodb_table_name": cls.DYNAMODB_TABLE_NAME,
            "sessions_dir": cls.SESSIONS_DIR,
            "log_level": cls.LOG_LEVEL,
        }
    
    @classmethod
    def validate_config(cls) -> list:
        """Validate configuration and return list of warnings/errors"""
        warnings = []
        
        # Check if critical files exist
        if not Path(cls.ROUTE_REGISTRY_FILE).exists():
            warnings.append(f"Route registry file not found: {cls.ROUTE_REGISTRY_FILE}")
        
        # Check environment-specific settings
        if cls.IS_PRODUCTION and not cls.USE_DYNAMODB:
            warnings.append("Production environment should use DynamoDB for checkpointing")
        
        return warnings


# Create a singleton instance for easy importing
config = Config()


# Convenience exports
__all__ = [
    'Config',
    'config',
]
