"""
Data Loader Node
Calls Cortex Analyst API to retrieve geoscience data, or loads
cortex-analyst-sample-respose.json for summarization queries.
"""

import asyncio
import json
import os
import re
from concurrent.futures import ThreadPoolExecutor

from geoscience_agent.integrations import cortex_analyst_retrieval
from geoscience_agent.state import DiscoveryState


# ==============================================================================
# Summarization data helpers
# ==============================================================================

def _normalise_summarization_data(react_data: dict) -> dict:
    """
    Normalise both Cortex Analyst JSON formats into a unified structure.
    Handles both new format (has_more) and old format (analysis.data).
    """
    generated_sql = react_data.get("generated_sql", "")

    analyst_text = ""
    analyst_content = (
        react_data.get("analyst_response", {})
        .get("message", {})
        .get("content", [])
    )
    for item in analyst_content:
        if item.get("type") == "text":
            analyst_text = item.get("text", "")
            break

    analysis = react_data.get("analysis", {})

    if analysis and analysis.get("data"):
        raw_data = analysis.get("data", [])
        columns = analysis.get("columns", [])
        dimensions = analysis.get("dimensions", [])
        metrics = analysis.get("metrics", [])
        has_more = False
    else:
        raw_data = react_data.get("results", [])
        raw_columns = react_data.get("columns", [])
        has_more = react_data.get("has_more", False)

        columns = [c.lower() for c in raw_columns]
        raw_data = [{k.lower(): v for k, v in row.items()} for row in raw_data]

        dimensions, metrics = [], []
        if raw_data and columns:
            for col in columns:
                sample = raw_data[0].get(col)
                if isinstance(sample, (int, float)):
                    metrics.append(col)
                else:
                    dimensions.append(col)

    return {
        "data": raw_data,
        "columns": columns,
        "dimensions": dimensions,
        "metrics": metrics,
        "has_more": has_more,
        "generated_sql": generated_sql,
        "analyst_text": analyst_text,
    }


def _select_data_file(request: str) -> str:
    """
    Select the appropriate sample JSON file based on the user's question.
    Checks analog keywords first (Santos Basin analogs), then prospect keywords
    (S-M-1008 prospects), then risk keywords, then defaults to contracts.
    """
    analog_keywords = [
        "analog", "analogue", "analogs", "analogues",
        "santos basin", "são paulo plateau", "sao paulo plateau",
        "fpso", "pre-salt", "presalt",
        "bumerangue", "jupiter", "berbigao", "sururu", "lapa",
        "water depth", "producing assets",
    ]
    prospect_keywords = [
        "prospect", "prospects", "s-m-1008", "sm-1008", "sm1008",
        "salamandra", "iguana", "block s-m",
        "recoverable resources", "oil-to-gas ratio",
        "opportunity screening",
    ]
    risk_keywords = [
        "risk", "anomaly", "anomalies", "outlier", "outliers",
        "expired", "disputed", "dispute", "expiry", "risk score",
        "risk factor", "risk assessment", "high risk", "low risk",
    ]
    request_lower = request.lower()
    if any(kw in request_lower for kw in analog_keywords):
        return "data/santos_basin_analogs.json"
    if any(kw in request_lower for kw in prospect_keywords):
        return "data/sm1008_prospects.json"
    if any(kw in request_lower for kw in risk_keywords):
        return "data/risk-assessment-sample-response.json"
    return "data/cortex-analyst-sample-respose.json"


def _load_summarization_json(state: DiscoveryState) -> DiscoveryState:
    """
    Load the appropriate sample JSON for no_data_retrieval queries.
    Selects risk-assessment or contract-summary data based on question keywords.
    Extracts generated_sql, per-column stats, and top records as context.
    """
    print(f"\n{'='*60}")
    print("LOAD SUMMARIZATION JSON (sample file)")
    print(f"{'='*60}")

    request = state.get("current_request", "")
    file_path = _select_data_file(request)
    print(f"  Selected data file: {file_path}")

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            react_data = json.load(f)

        prompt = react_data.get("prompt", "")
        norm = _normalise_summarization_data(react_data)

        columns = norm["columns"]
        has_more = norm["has_more"]
        generated_sql = norm["generated_sql"]
        data_rows = norm["data"]

        computed_stats = react_data.get("analysis", {}).get("stats", {})
        top_records = computed_stats.get("top_records", [])

        sql_limit_match = re.search(r'\bLIMIT\s+(\d+)', generated_sql, re.IGNORECASE)
        sql_limit = int(sql_limit_match.group(1)) if sql_limit_match else None
        record_count = sql_limit if sql_limit is not None else 10

        if record_count > len(top_records) and data_rows:
            top_records = data_rows[:record_count]
        else:
            top_records = top_records[:record_count]

        stats_block = json.dumps(computed_stats, indent=2)

        top_records_text = ""
        if top_records:
            top_records_text = f"\n\nTop {len(top_records)} Records:\n"
            for i, rec in enumerate(top_records, 1):
                parts = [f"{col}={rec.get(col)}" for col in columns if col in rec]
                top_records_text += f"  {i}. {', '.join(parts)}\n"

        has_more_note = ""
        if has_more:
            has_more_note = (
                f"\n\nNOTE: has_more={has_more}. The data is a PARTIAL result set. "
                f"Stats cover the {len(data_rows)} rows provided."
            )

        context = (
            f"Generated SQL:\n{generated_sql}\n\n"
            f"Columns: {columns}\n"
            f"Total rows: {len(data_rows)} (has_more={has_more}){has_more_note}\n\n"
            f"Statistics:\n{stats_block}"
            f"{top_records_text}"
        )

        unified_summarization_data = {
            "prompt": prompt,
            "generated_sql": generated_sql,
            "columns": columns,
            "has_more": has_more,
            "stats": computed_stats,
            "top_records": top_records,
            "correlation_id": react_data.get("correlation_id", ""),
        }

        _OPP_SCREENING_FILES = {
            "data/sm1008_prospects.json",
            "data/santos_basin_analogs.json",
        }
        domain_prompt_override = None
        if file_path in _OPP_SCREENING_FILES:
            opp_prompt_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "prompts", "opp_screening_prompt.md",
            )
            if os.path.exists(opp_prompt_path):
                with open(opp_prompt_path, "r", encoding="utf-8") as pf:
                    domain_prompt_override = pf.read()
                print(f"  Domain prompt override: opp_screening_prompt.md ({len(domain_prompt_override)} chars)")

        print(f"JSON loaded from {file_path}")
        print(f"  Query: {prompt}")
        print(f"  Columns: {columns}")
        print(f"  Has more: {has_more}")
        print(f"  Stats: {list(computed_stats.keys())}")
        print(f"  Top records: {len(top_records)}")
        print(f"  Context length: {len(context)} characters")

        result = {
            **state,
            "summarization_data": unified_summarization_data,
            "summarization_context": context,
            "status": "summarization_json_loaded",
        }
        if domain_prompt_override:
            result["domain_prompt_override"] = domain_prompt_override
        return result

    except Exception as e:
        error_msg = f"Failed to load cortex analyst JSON: {str(e)}"
        print(f"ERROR: {error_msg}")
        return {
            **state,
            "summarization_data": {},
            "summarization_context": "",
            "status": "error",
            "error": error_msg,
        }


# ==============================================================================
# Cortex Analyst data loader
# ==============================================================================

def _load_cortex_analyst(state: DiscoveryState) -> DiscoveryState:
    """Call Cortex Analyst API for discovery/analytical queries."""
    intent_classification = state.get("intent_classification", {})
    semantic_model = None
    refined_question = None

    if intent_classification and isinstance(intent_classification, dict):
        parameters = intent_classification.get("parameters", {})
        semantic_model = parameters.get("semantic_view")
        refined_question = parameters.get("question")

    query = refined_question if refined_question else state.get("current_request", "")

    if not semantic_model:
        semantic_model = state.get("semantic_model_name")

    try:
        print(f"Calling Cortex Analyst API with query: {query}")
        if semantic_model:
            print(f"  Using semantic model: {semantic_model}")
        else:
            print(f"  No semantic model specified, using tool default")

        def run_async_in_thread():
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                tool_params = {"query": query}
                if semantic_model:
                    tool_params["semantic_model_name"] = semantic_model
                return new_loop.run_until_complete(
                    cortex_analyst_retrieval.ainvoke(tool_params)
                )
            finally:
                new_loop.close()

        with ThreadPoolExecutor() as executor:
            future = executor.submit(run_async_in_thread)
            tool_response = future.result()

        response_data = json.loads(tool_response)
        status = response_data.get("status", "unknown")
        print(f"Cortex Analyst returned: {status}")

        if status == "analyst_response":
            analyst_message = response_data.get("analyst_message", "")
            suggestions = response_data.get("suggestions", [])
            print(f"  Analyst message: {analyst_message[:100]}...")
            print(f"  Suggestions provided: {len(suggestions)}")
            return {
                **state,
                "qa_data": [],
                "discoveries_data": [],
                "context": json.dumps({"analyst_message": analyst_message, "suggestions": suggestions}, indent=2),
                "full_context": json.dumps(response_data, indent=2),
                "analyst_message": analyst_message,
                "analyst_suggestions": suggestions,
                "status": "analyst_guidance",
            }

        if status == "error":
            error_msg = response_data.get("error", "Unknown error")
            error_type = response_data.get("error_type", "unknown")
            error_category = response_data.get("error_category", "unknown")
            suggestion = response_data.get("suggestion", "")
            status_code = response_data.get("status_code")
            print(f"API Error ({error_category}/{error_type}): {error_msg}")
            if suggestion:
                print(f"Suggestion: {suggestion}")
            return {
                **state,
                "qa_data": [],
                "discoveries_data": [],
                "context": "",
                "full_context": json.dumps(response_data, indent=2),
                "status": "error",
                "error": error_msg,
                "error_type": error_type,
                "error_category": error_category,
                "error_suggestion": suggestion,
                "error_status_code": status_code,
            }

        results = response_data.get("results") or []
        generated_sql = response_data.get("generated_sql", "")
        print(f"  Results returned: {len(results)} rows")
        print(f"  Generated SQL: {generated_sql[:100] if generated_sql else 'N/A'}...")

        context = json.dumps(results, indent=2) if results else "{}"
        full_json = json.dumps(response_data, indent=2)

        return {
            **state,
            "qa_data": results,
            "discoveries_data": results,
            "context": context,
            "full_context": full_json,
            "generated_sql": generated_sql,
            "status": "cortex_data_loaded",
        }

    except Exception as e:
        error_msg = f"Cortex Analyst tool error: {str(e)}"
        print(f"ERROR: {error_msg}")
        import traceback
        print(traceback.format_exc())
        return {
            **state,
            "qa_data": [],
            "discoveries_data": [],
            "context": "",
            "full_context": "",
            "status": "error",
            "error": error_msg,
        }


# ==============================================================================
# Unified node entry point (legacy - kept for backward compatibility)
# ==============================================================================

def load_json_tool_node(state: DiscoveryState) -> DiscoveryState:
    """
    Unified data-loading node (legacy).

    Routes internally based on intent_route:
      - "no_data_retrieval" -> load cortex-analyst-sample-respose.json
      - anything else   -> call Cortex Analyst API (original behaviour)
    """
    print(f"\n{'='*60}")
    print("LOAD JSON TOOL NODE")
    print(f"{'='*60}")

    intent_route = state.get("intent_route", "cortex")
    print(f"  intent_route: {intent_route}")

    if intent_route == "no_data_retrieval":
        return _load_summarization_json(state)
    else:
        return _load_cortex_analyst(state)


# ==============================================================================
# Independent route nodes (cortex vs no_data_retrieval)
# ==============================================================================

def load_cortex_tool_node(state: DiscoveryState) -> DiscoveryState:
    """
    Cortex-only data loader. Calls Cortex Analyst API.
    Used when intent_route == "cortex".
    """
    print(f"\n{'='*60}")
    print("LOAD CORTEX TOOL NODE (Cortex Analyst API)")
    print(f"{'='*60}")
    return _load_cortex_analyst(state)


def load_no_data_retrieval_node(state: DiscoveryState) -> DiscoveryState:
    """
    No data retrieval data loader. Loads sample JSON from disk.
    Used when intent_route == "no_data_retrieval".
    """
    print(f"\n{'='*60}")
    print("LOAD NO DATA RETRIEVAL NODE (Sample JSON)")
    print(f"{'='*60}")
    return _load_summarization_json(state)
