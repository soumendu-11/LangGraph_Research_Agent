"""
Greeting Response Node
Handles greetings, incomplete inputs, and short affirmations
without invoking the full processing pipeline.
"""

from datetime import datetime

from langchain_core.messages import AIMessage

from geoscience_agent.state import DiscoveryState


def greeting_response_node(state: DiscoveryState) -> DiscoveryState:
    """Return a lightweight acknowledgement for greetings/incomplete inputs.

    Short-circuits the pipeline: no intent classification, data loading,
    or summarization LLM calls are needed.
    """
    print(f"\n{'='*60}")
    print("GREETING RESPONSE NODE")
    print(f"{'='*60}")

    guardrail_check = state.get("guardrail_check", {})
    suggested = guardrail_check.get("suggested_response") or \
        "Hello! How can I help you with oil & gas discovery analysis today?"
    category = guardrail_check.get("category", "greeting_or_incomplete")

    print(f"  Category: {category}")
    print(f"  Response: {suggested}")

    greeting_response = {
        "summary": suggested,
        "key_insights": [],
        "data_table": [],
    }

    messages = list(state.get("messages", []))
    messages.append(AIMessage(content=suggested))

    return {
        **state,
        "current_response": greeting_response,
        "response_summary": suggested,
        "key_insights": greeting_response["key_insights"],
        "data_table": greeting_response["data_table"],
        "status": "greeting_response",
        "timestamp": datetime.now().isoformat(),
        "messages": messages,
    }


__all__ = ['greeting_response_node']
