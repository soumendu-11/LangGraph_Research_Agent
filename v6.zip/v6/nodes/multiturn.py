"""
Multi-turn Handler Node
Processes queries with conversation history and G-Eval scoring,
or delegates to the SummarizationProcessor for summarization queries.
"""

from langchain_core.messages import AIMessage, HumanMessage

from geoscience_agent.config import config
from geoscience_agent.models.bedrock_stream import resolve_llm_stream_callback
from geoscience_agent.models import SONNET_45_CONFIG  # workflow model config
from geoscience_agent.processors import MultiTurnProcessor, SummarizationProcessor
from geoscience_agent.state import DiscoveryState


def _handle_summarization(state: DiscoveryState) -> DiscoveryState:
    """Prompt-based summarization using context loaded by load_json_tool."""
    print(f"\n{'='*60}")
    print("MULTI-TURN HANDLER NODE -> Summarization path")
    print(f"{'='*60}")

    model_id = state.get("model_id", config.BEDROCK_WORKFLOW_MODEL_ID)
    processor = SummarizationProcessor(model_id=model_id)
    result = processor.process(state)

    messages = state.get("messages", [])
    response_summary = result.get("response_summary", "No response generated")
    messages.append(AIMessage(content=response_summary))
    print("Added AIMessage to conversation history")

    return {**result, "messages": messages}


def _handle_cortex(state: DiscoveryState) -> DiscoveryState:
    """Deterministic multi-turn response from Cortex Analyst data + G-Eval.
    After turns 3, 6, 9: generates concise running summary of Q&A pairs.
    """
    print(f"\n{'='*60}")
    print("MULTI-TURN HANDLER NODE (Deterministic + G-Eval)")
    print(f"{'='*60}")

    messages = state.get("messages", [])
    conversation_context = "\n".join([
        f"{msg.type}: {msg.content}"
        for msg in messages[:-1]
        if isinstance(msg, (HumanMessage, AIMessage))
    ])

    if conversation_context:
        print(f"Conversation context: {len(messages)-1} previous messages")

    model_id = state.get("model_id", SONNET_45_CONFIG["model_id"])
    processor = MultiTurnProcessor(model_id=model_id)

    result = processor.process_deterministic(state)

    response_summary = result.get("response_summary", "No response generated")
    turn_number = state.get("turn_number", 1)
    conversation_history = state.get("conversation_history", [])
    running_summary = state.get("running_summary", "")

    summarization_processor = SummarizationProcessor(model_id=model_id)
    if turn_number % summarization_processor.SUMMARY_INTERVAL == 0:
        last_summarized = ((turn_number - 1) // 3) * 3
        turn_start, turn_end = last_summarized + 1, turn_number
        print(f"\n--- Cortex: Generating chunk summary (turns {turn_start}–{turn_end}) ---")
        md = state.get("metadata") or {}
        stream_cb = resolve_llm_stream_callback(md, "summarization")
        chunk_summary = summarization_processor.generate_running_summary(
            conversation_history=conversation_history,
            turn_number=turn_number,
            running_summary=running_summary,
            current_question=state.get("current_request", ""),
            current_answer=response_summary,
            on_text_delta=stream_cb,
        )
        new_running_summary = (
            (running_summary + "\n\n" + chunk_summary) if running_summary else chunk_summary
        )
        print(f"Chunk summary: {len(chunk_summary)} chars. Total running summary: {len(new_running_summary)} chars")
    else:
        new_running_summary = running_summary

    messages.append(AIMessage(content=response_summary))
    print("Added AIMessage to conversation history")

    return {
        **result,
        "messages": messages,
        "response_summary": response_summary,
        "running_summary": new_running_summary,
    }


def multiturn_handler_node(state: DiscoveryState) -> DiscoveryState:
    """
    Unified handler node (legacy).

    Routes internally based on intent_route:
      - "no_data_retrieval" -> SummarizationProcessor (prompt-based, 1-turn LLM)
      - anything else   -> MultiTurnProcessor (deterministic + G-Eval)
    """
    intent_route = state.get("intent_route", "cortex")
    print(f"  multiturn_handler intent_route: {intent_route}")

    if intent_route == "no_data_retrieval":
        return _handle_summarization(state)
    else:
        return _handle_cortex(state)


def cortex_handler_node(state: DiscoveryState) -> DiscoveryState:
    """
    Cortex-only handler. MultiTurnProcessor (deterministic + G-Eval).
    Used when intent_route == "cortex".
    """
    return _handle_cortex(state)


def no_data_retrieval_handler_node(state: DiscoveryState) -> DiscoveryState:
    """
    No data retrieval handler. SummarizationProcessor (prompt-based, 1-turn LLM).
    Used when intent_route == "no_data_retrieval".
    """
    return _handle_summarization(state)
