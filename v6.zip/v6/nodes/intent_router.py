"""
Intent Router Node
Classifies user intent using Bedrock and route registry
"""
import re

from geoscience_agent.models import BedrockIntentRouter
from geoscience_agent.models.bedrock_stream import resolve_llm_stream_callback
from geoscience_agent.state import DiscoveryState


def intent_router_node(state: DiscoveryState) -> DiscoveryState:
    """
    Bedrock-based intent router using route_registry.json
    Classifies intent as: map_update, dashboard_load, or analytical_question
    Selects appropriate semantic model based on the question type
    """
    print(f"\n{'='*60}")
    print("BEDROCK INTENT ROUTER NODE")
    print(f"{'='*60}")

    request = state.get("current_request", "")
    metadata = state.get("metadata") or {}

    # Allow API endpoints to force route via metadata (e.g. /discovery/dashboard, /discovery/cortex)
    force_route = metadata.get("force_route")
    if force_route in ("dashboard", "map"):
        print(f"  Force route: {force_route} (from API endpoint)")
        params = metadata.get("dashboard_params") or {}
        return {
            **state,
            "intent_route": force_route,
            "intent_classification": {
                "intent": "dashboard_load" if force_route == "dashboard" else "map_update",
                "confidence": 1.0,
                "parameters": {
                    "workflow_dashboard_name": params.get("workflow_dashboard_name", "field_summary"),
                    "field_name": params.get("field_name", ""),
                    "question": request,
                },
                "route_name": params.get("route_name", force_route),
            },
            "semantic_model_name": "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_FIELD_SUMMARY",
            "status": "intent_classified",
        }
    if force_route == "cortex":
        print(f"  Force route: cortex (from API endpoint)")
        params = metadata.get("cortex_params") or {}
        semantic_model = params.get("semantic_view") or "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_FIELD_SUMMARY"
        return {
            **state,
            "intent_route": "cortex",
            "intent_classification": {
                "intent": "analytical_question",
                "confidence": 1.0,
                "parameters": {"question": request, "semantic_view": semantic_model},
                "route_name": "cortex",
            },
            "semantic_model_name": semantic_model,
            "status": "intent_classified",
        }
    if force_route == "no_data_retrieval":
        print(f"  Force route: no_data_retrieval (from API endpoint)")
        return {
            **state,
            "intent_route": "no_data_retrieval",
            "intent_classification": {
                "intent": "analytical_question",
                "confidence": 1.0,
                "parameters": {"question": request},
                "route_name": "no_data_retrieval",
            },
            "semantic_model_name": "TITAN_APP.CORE_SPATIAL.VW_CONTRACT_BASIN_WELL_RIG",
            "status": "intent_classified",
        }
    if force_route == "layer_toggle":
        print(f"  Force route: layer_toggle (from API endpoint)")
        return {
            **state,
            "intent_route": "map",
            "intent_classification": {
                "intent": "map_update",
                "confidence": 1.0,
                "parameters": {
                    "sub_intent": "layer_toggle",
                    "question": request,
                },
                "route_name": "layer_toggle",
            },
            "status": "intent_classified",
        }
    
    try:
        print(f"  Initializing BedrockIntentRouter...")
        router = BedrockIntentRouter()
        print(f"  ✓ Router initialized successfully")
        print(f"🤖 Classifying intent for request: {request[:100]}...")
        stream_cb = resolve_llm_stream_callback(metadata, "intent_router")

        result = router.classify(
            prompt=request,
            workflow="GEOSCIENCE",
            country_name=None,
            on_text_delta=stream_cb,
        )
        
        print(f"✓ Classification complete, parsing result...")
        
        intent = result.get("intent", "analytical_question")
        confidence = result.get("confidence", 0.0)
        parameters = result.get("parameters", {})
        route_name = result.get("route_name")
        
        print(f"\n✓ Intent Classification Result:")
        print(f"  Intent: {intent} (confidence: {confidence})")
        print(f"  Route Name: {route_name or 'N/A'}")
        print(f"  Parameters: {parameters}")
        print(f"  Full Result: {result}")
        
        # Map intent to workflow route based on LLM classification
        # dashboard_load -> dashboard (skip Cortex)
        # map_update -> map (skip Cortex)
        # no_data_retrieval -> load_no_data_retrieval_node -> no_data_retrieval_handler (summary, risk analysis, anomaly detection, general domain reasoning)
        # analytical_question -> cortex (load_cortex_tool -> cortex_handler)
        # Heuristic override: catch map/dashboard/no_data_retrieval even if LLM misclassifies
        request_lower = request.lower()

        map_keywords = [
            "show in map", "show on map", "show me the map", "display on map",
            "update map", "update it in map", "plot on map", "open map",
            "map view", "mark on map", "locate on map", "show location",
            "show me in the map",
        ]
        dashboard_keywords = [
            "show dashboard", "open dashboard", "load dashboard",
            "display dashboard", "dashboard view",
        ]
        no_data_retrieval_keywords = [
            "summarize", "summary", "statistics", "stats", "how many",
            "count by", "breakdown by", "group by", "total by",
            "contracts", "contract", "by country", "per country",
            "risk analysis", "risk factor", "risk score", "risk assessment",
            "anomaly detection", "anomalies", "outliers",
            "general reasoning", "domain reasoning",
            "expired", "disputed", "high risk", "low risk",
        ]
        layer_toggle_keywords = [
            "turn on", "turn off", "toggle layer", "show layer", "hide layer",
            "enable layer", "disable layer", "switch on", "switch off",
            "layer on", "layer off", "layers on", "layers off",
            "remove layer", "add layer",
        ]
        is_map_heuristic = any(kw in request_lower for kw in map_keywords)
        is_dashboard_heuristic = any(kw in request_lower for kw in dashboard_keywords)
        is_no_data_retrieval_heuristic = any(kw in request_lower for kw in no_data_retrieval_keywords)
        is_layer_toggle_heuristic = any(kw in request_lower for kw in layer_toggle_keywords)

        # Check if LLM already flagged this as layer_toggle via sub_intent
        is_layer_toggle_llm = parameters.get("sub_intent") == "layer_toggle"

        if is_layer_toggle_llm or is_layer_toggle_heuristic:
            workflow_route = "map"
            if "sub_intent" not in parameters:
                parameters["sub_intent"] = "layer_toggle"
            result["parameters"] = parameters
            print(f"  → Routing to: map (map_dashboard_response → layer_toggle branch)")
        elif intent == "map_update" or is_map_heuristic:
            workflow_route = "map"
            if intent != "map_update":
                print(f"  → Overriding to map (heuristic: map keywords detected)")
            print(f"  → Routing to: map (map_dashboard_response)")
        elif intent == "dashboard_load" or is_dashboard_heuristic:
            workflow_route = "dashboard"
            if intent != "dashboard_load":
                print(f"  → Overriding to dashboard (heuristic: dashboard keywords detected)")
            print(f"  → Routing to: dashboard (map_dashboard_response)")
        elif intent == "no_data_retrieval" or (intent == "analytical_question" and is_no_data_retrieval_heuristic):
            workflow_route = "no_data_retrieval"
            if intent != "no_data_retrieval":
                print(f"  → Overriding to no_data_retrieval (heuristic: summarize/contracts/stats keywords)")
            print(f"  → Routing to: no_data_retrieval (load_no_data_retrieval_node -> no_data_retrieval_handler)")
        else:
            # analytical_question or unknown -> cortex
            workflow_route = "cortex"
            print(f"  → Routing to: cortex (load_cortex_tool -> cortex_handler)")
        
        # Extract semantic model from parameters (set by LLM during classification)
        semantic_model = parameters.get("semantic_view")
        
        # If no semantic model specified, use smart defaults based on question type
        if not semantic_model:
            # Analyze question to determine if it's field-level or reservoir-level
            request_lower = request.lower()
            
            # Reservoir-specific keywords
            reservoir_keywords = [
                "reservoir", "formation", "pay zone", "porosity", "permeability",
                "thickness", "depth", "pressure", "saturation", "rock properties"
            ]
            
            # Field-level keywords
            field_keywords = [
                "field", "discovery", "basin", "operator", "company",
                "total recoverable", "reserves", "resources", "production status"
            ]
            
            # Count keyword matches
            reservoir_score = sum(1 for kw in reservoir_keywords if kw in request_lower)
            field_score = sum(1 for kw in field_keywords if kw in request_lower)
            
            # Select semantic model based on question focus
            if reservoir_score > field_score:
                semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_RESERVOIR_SUMMARY"
                print(f"  Auto-selected: Reservoir semantic model (reservoir keywords: {reservoir_score})")
            else:
                semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_FIELD_SUMMARY"
                print(f"  Auto-selected: Field semantic model (field keywords: {field_score})")
        else:
            print(f"  Using LLM-selected semantic model: {semantic_model}")
        
        intent_usage = result.get("usage", {"input_tokens": 0, "output_tokens": 0})
        existing_usage = state.get("token_usage") or {}
        merged_usage = {**existing_usage, "intent_router": intent_usage}

        final_state = {
            **state,
            "intent_route": workflow_route,
            "intent_classification": result,
            "semantic_model_name": semantic_model,
            "token_usage": merged_usage,
            "status": "intent_classified"
        }
        print(f"  DEBUG: Returning state with intent_classification = {final_state.get('intent_classification', {}).get('intent', 'MISSING')}")
        return final_state
        
    except Exception as e:
        print(f"⚠️ Intent router error: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        print(f"   Using fallback classification logic")
        
        # Analyze question for semantic model selection even in fallback
        request_lower = request.lower()
        
        # Fallback keyword detection for map/dashboard/no_data_retrieval
        map_kw = [
            "show in map", "show on map", "show me the map", "display on map",
            "update map", "update it in map", "plot on map", "open map",
            "map view", "mark on map", "show me in the map",
        ]
        dashboard_kw = [
            "show dashboard", "open dashboard", "load dashboard",
            "display dashboard", "dashboard view",
        ]
        dashboard_patterns = [
            r"show\s+(?:me\s+)?(?:the\s+)?details?\s+(?:of|for)\s+(?:field|reservoir)",
            r"load\s+(?:field|reservoir)\s+(?:summary|dashboard)",
            r"(?:field|reservoir)\s+summary\s+for",
            r"details?\s+(?:on|about)\s+(?:field|reservoir)"
        ]
        no_data_retrieval_keywords = [
            "summarize", "summary", "statistics", "stats", "how many",
            "count by", "breakdown by", "group by", "total by",
            "contracts", "contract", "by country", "per country",
            "risk analysis", "risk factor", "risk score", "risk assessment",
            "anomaly detection", "anomalies", "outliers",
            "general reasoning", "domain reasoning",
            "expired", "disputed", "high risk", "low risk",
        ]

        is_map = any(kw in request_lower for kw in map_kw)
        is_dashboard = (
            any(kw in request_lower for kw in dashboard_kw)
            or any(re.search(p, request_lower) for p in dashboard_patterns)
        )
        layer_toggle_kw = [
            "turn on", "turn off", "toggle layer", "show layer", "hide layer",
            "enable layer", "disable layer", "switch on", "switch off",
            "layer on", "layer off", "remove layer", "add layer",
        ]
        is_layer_toggle = any(kw in request_lower for kw in layer_toggle_kw)

        # Reservoir-specific keywords
        reservoir_keywords = [
            "reservoir", "formation", "pay zone", "porosity", "permeability",
            "thickness", "depth", "pressure", "saturation", "rock properties"
        ]
        # Field-level keywords
        field_keywords = [
            "field", "discovery", "basin", "operator", "company"
        ]
        reservoir_score = sum(1 for kw in reservoir_keywords if kw in request_lower)
        field_score = sum(1 for kw in field_keywords if kw in request_lower)

        if is_layer_toggle:
            intent = "map_update"
            workflow_route = "map"
            print(f"   Detected layer_toggle intent via keyword matching")
        elif is_map:
            intent = "map_update"
            workflow_route = "map"
            print(f"   Detected map_update intent via keyword matching")
        elif is_dashboard:
            intent = "dashboard_load"
            workflow_route = "dashboard"
            print(f"   Detected dashboard_load intent via keyword matching")
        elif any(kw in request_lower for kw in no_data_retrieval_keywords):
            intent = "no_data_retrieval"
            workflow_route = "no_data_retrieval"
            print(f"   Detected no_data_retrieval intent via keyword matching")
        else:
            intent = "analytical_question"
            workflow_route = "cortex"
            print(f"   Defaulting to analytical_question -> cortex")
        
        # Select semantic model based on question focus
        if reservoir_score > field_score:
            semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_RESERVOIR_SUMMARY"
            print(f"   Using reservoir semantic model (reservoir keywords: {reservoir_score}, field keywords: {field_score})")
        else:
            semantic_model = "TITAN_APP.TDP_GEOSCIENCE.SV_INTL_FIELD_SUMMARY"
            print(f"   Using field semantic model (reservoir keywords: {reservoir_score}, field keywords: {field_score})")
        
        # Return fallback result
        fallback_params = {"question": request, "semantic_view": semantic_model}
        if is_layer_toggle:
            fallback_params["sub_intent"] = "layer_toggle"
        return {
            **state,
            "intent_route": workflow_route,
            "intent_classification": {
                "intent": intent,
                "confidence": 0.5,
                "parameters": fallback_params,
                "route_name": "layer_toggle" if is_layer_toggle else None,
                "route_reason": f"Fallback due to error: {str(e)}"
            },
            "semantic_model_name": semantic_model,
            "status": "intent_classified"
        }
