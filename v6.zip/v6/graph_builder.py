"""
LangGraph Workflow Builder
Orchestrates the geoscience agent workflow by wiring nodes together
"""

import json
import os
import tempfile
import time
import uuid
from contextlib import nullcontext
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

import mlflow
from langgraph.checkpoint.memory import MemorySaver
from langgraph.graph import END, START, StateGraph

from geoscience_agent.config import config
from geoscience_agent.models import SONNET_45_CONFIG
from geoscience_agent.nodes import (
    greeting_response_node,
    guardrail_check_node,
    initialize_session_node,
    intent_router_node,
    load_cortex_tool_node,
    load_no_data_retrieval_node,
    cortex_handler_node,
    no_data_retrieval_handler_node,
    save_session_node,
)
from geoscience_agent.state import DiscoveryState
from geoscience_agent.storage import DynamoDBSaver, SessionManager

# Setup State Persistence
# Use DynamoDB in production, MemorySaver for local dev
if config.USE_DYNAMODB:
    checkpointer = DynamoDBSaver(table_name=config.DYNAMODB_TABLE_NAME)
    print(f"✓ Using DynamoDB checkpointer (table: {config.DYNAMODB_TABLE_NAME})")
else:
    checkpointer = MemorySaver()
    print("✓ Using MemorySaver (local development)")


# ==============================================================================
# ROUTING FUNCTIONS
# ==============================================================================

_GREETING_TOKENS = frozenset({
    "hi", "hello", "hey", "howdy", "greetings",
    "good morning", "good afternoon", "good evening",
    "thanks", "thank you", "ok", "okay", "yes", "no",
    "sure", "got it", "bye", "goodbye",
})


def _is_greeting_heuristic(text: str) -> bool:
    """Deterministic check so simple greetings never slip past a flaky LLM category."""
    normalized = text.strip().lower().rstrip("!?.,:;")
    return normalized in _GREETING_TOKENS


def route_after_guardrail(state: DiscoveryState) -> str:
    """
    Route after guardrail check based on whether request is blocked.

    Uses BOTH the LLM guardrail category AND a deterministic greeting
    heuristic so common greetings are never misrouted due to LLM
    non-determinism.

    Returns:
        'blocked' if question is inappropriate (goes to save_session -> END)
        'greeting' if greeting/incomplete input (goes to greeting_response -> save_session -> END)
        'allowed' if allowed to proceed (goes to intent_router)
    """
    is_blocked = state.get("is_blocked", False)
    guardrail_check = state.get("guardrail_check", {})
    category = guardrail_check.get("category", "")
    current_request = state.get("current_request", "")

    if _is_greeting_heuristic(current_request):
        if is_blocked or category not in ("greeting_or_incomplete", ""):
            print(f"\n  Heuristic override: '{current_request}' is a greeting "
                  f"(LLM said category={category}, is_blocked={is_blocked})")
        print(f"\nRouting to: greeting_response (greeting/incomplete)")
        return "greeting"
    elif is_blocked:
        print(f"\nRouting to: save_session (blocked)")
        return "blocked"
    elif category == "greeting_or_incomplete":
        print(f"\nRouting to: greeting_response (greeting/incomplete)")
        return "greeting"
    else:
        print(f"\nRouting to: intent_router (allowed)")
        return "allowed"


def route_after_intent(state: DiscoveryState) -> str:
    """
    Route after intent classification based on the classified intent.

    Three independent routes:
        - cortex: analytical_question -> load_cortex_tool -> cortex_handler (Cortex API)
        - no_data_retrieval: summary/stats -> load_no_data_retrieval_node -> no_data_retrieval_handler (sample JSON)
        - dashboard: dashboard_load -> map_dashboard_response (skip Cortex)
        - map: map_update -> map_dashboard_response (skip Cortex)
    """
    intent_route = state.get("intent_route", "cortex")
    print(f"  Routing decision: {intent_route}")
    return intent_route


def dashboard_response_node(state: DiscoveryState) -> DiscoveryState:
    """
    Handle dashboard_load, map_update, and layer_toggle intents without
    calling Cortex Analyst.  Returns a structured response for map,
    dashboard, or layer-toggle routing.
    """
    print(f"\n{'='*60}")
    print("MAP / DASHBOARD RESPONSE NODE")
    print(f"{'='*60}")
    
    intent_classification = state.get("intent_classification", {})
    print(f"  Intent classification: {intent_classification}")
    
    parameters = intent_classification.get("parameters", {}) if intent_classification else {}
    sub_intent = parameters.get("sub_intent")

    # ── LAYER TOGGLE branch ─────────────────────────────────────────
    if sub_intent == "layer_toggle":
        print(f"  Sub-intent: layer_toggle")
        from geoscience_agent.models.layer_toggle import LayerToggleResolver

        metadata = state.get("metadata") or {}
        active_layers = metadata.get("active_layers", [])
        requested_layers = parameters.get("requested_layers")
        action_hint = parameters.get("layer_action")

        resolver = LayerToggleResolver()
        result = resolver.resolve(
            user_request=state.get("current_request", ""),
            active_layers=active_layers,
            requested_layers=requested_layers,
            action_hint=action_hint,
        )

        print(f"  Layer toggle result: {result}")

        response = {
            "summary": result["confirmation_message"],
            "response_type": "layer_toggle",
            "layer_actions": result["layer_actions"],
            "matched_layer_ids": result["matched_layer_ids"],
            "key_insights": [],
            "data_table": [],
        }

        return {
            **state,
            "current_response": response,
            "response_summary": result["confirmation_message"],
            "layer_toggle_result": result["layer_actions"],
            "layer_toggle_message": result["confirmation_message"],
            "status": "layer_toggle_complete",
            "error": result.get("error"),
        }

    # ── EXISTING dashboard / map branch ─────────────────────────────
    dashboard_name = parameters.get("workflow_dashboard_name", "unknown")
    field_name = parameters.get("field_name", "")
    route_name = intent_classification.get("route_name", "unknown") if intent_classification else "unknown"
    
    print(f"  Dashboard: {dashboard_name}")
    print(f"  Field Name: {field_name}")
    print(f"  Route: {route_name}")
    
    if field_name:
        response_summary = f"📊 Loading {dashboard_name} dashboard for field: {field_name}"
    else:
        response_summary = f"📊 Loading {dashboard_name} dashboard"
    
    response = {
        "summary": response_summary,
        "key_insights": [
            {
                "insight": "Dashboard Routing",
                "description": f"Frontend should display the {dashboard_name} dashboard"
            },
            {
                "insight": "Route Information",
                "description": f"Route: {route_name}"
            }
        ],
        "data_table": [],
        "dashboard_name": dashboard_name,
        "field_name": field_name,
        "route_name": route_name
    }
    
    return {
        **state,
        "current_response": response,
        "response_summary": response_summary,
        "status": "dashboard_routed"
    }


# ==============================================================================
# WORKFLOW BUILDER
# ==============================================================================

def build_discovery_workflow(model_id: Optional[str] = None):
    """
    Build and compile the geoscience agent workflow with Cortex Analyst integration.

    Workflow structure (10 nodes, 2 conditional routes, 3 independent intent paths):
        START
          |
        initialize_session
          |
        guardrail_check (LLM call)
          |
        [GUARDRAIL ROUTING]
          |-> BLOCKED -> save_session -> END
          |-> GREETING -> greeting_response -> save_session -> END
          |-> ALLOWED -> intent_router (Bedrock classification)
                           |
                        [INTENT ROUTING - 3 independent routes]
                           |-> cortex: load_cortex_tool -> cortex_handler -> save_session -> END
                           |-> no_data_retrieval: load_no_data_retrieval_node -> no_data_retrieval_handler -> save_session -> END
                           |-> dashboard: map_dashboard_response -> save_session -> END
                           |-> map: map_dashboard_response -> save_session -> END

    Args:
        model_id: Model to use (default: Sonnet 4.5)

    Returns:
        Compiled LangGraph workflow
    """
    print(f"\n{'='*60}")
    print("BUILDING GEOSCIENCE AGENT WORKFLOW")
    print(f"{'='*60}")

    workflow = StateGraph(DiscoveryState)

    # Add all nodes (10 total)
    workflow.add_node("initialize_session", initialize_session_node)
    workflow.add_node("guardrail_check", guardrail_check_node)
    workflow.add_node("greeting_response", greeting_response_node)
    workflow.add_node("intent_router", intent_router_node)
    workflow.add_node("load_cortex_tool", load_cortex_tool_node)
    workflow.add_node("load_no_data_retrieval_node", load_no_data_retrieval_node)
    workflow.add_node("cortex_handler", cortex_handler_node)
    workflow.add_node("no_data_retrieval_handler", no_data_retrieval_handler_node)
    workflow.add_node("map_dashboard_response", dashboard_response_node)
    workflow.add_node("save_session", save_session_node)

    # Define workflow edges
    workflow.add_edge(START, "initialize_session")
    workflow.add_edge("initialize_session", "guardrail_check")

    # Conditional routing after guardrail check
    workflow.add_conditional_edges(
        "guardrail_check",
        route_after_guardrail,
        {
            "blocked": "save_session",
            "greeting": "greeting_response",
            "allowed": "intent_router",
        },
    )

    # Greeting path: greeting_response -> save_session
    workflow.add_edge("greeting_response", "save_session")

    # Conditional routing after intent - 3 independent routes
    workflow.add_conditional_edges(
        "intent_router",
        route_after_intent,
        {
            "cortex": "load_cortex_tool",
            "no_data_retrieval": "load_no_data_retrieval_node",
            "dashboard": "map_dashboard_response",
            "map": "map_dashboard_response",
        },
    )

    # Cortex path: load_cortex_tool -> cortex_handler -> save_session
    workflow.add_edge("load_cortex_tool", "cortex_handler")
    workflow.add_edge("cortex_handler", "save_session")

    # No data retrieval path: load_no_data_retrieval_node -> no_data_retrieval_handler -> save_session
    workflow.add_edge("load_no_data_retrieval_node", "no_data_retrieval_handler")
    workflow.add_edge("no_data_retrieval_handler", "save_session")

    # Dashboard/map path
    workflow.add_edge("map_dashboard_response", "save_session")

    # Final step
    workflow.add_edge("save_session", END)

    # Compile with checkpointer for state persistence
    app = workflow.compile(checkpointer=checkpointer)

    persistence_backend = "DynamoDB" if config.USE_DYNAMODB else "MemorySaver (local)"
    print("Workflow compiled successfully")
    print(f"  Nodes: 10 (initialize_session, guardrail_check, greeting_response, intent_router,")
    print(f"              load_cortex_tool, load_no_data_retrieval_node, cortex_handler, no_data_retrieval_handler,")
    print(f"              map_dashboard_response, save_session)")
    print(f"  Conditional routes: 2 (guardrail, intent)")
    print(f"  State Persistence: {persistence_backend}")
    print(f"  Guardrail: Sonnet 4.5-based content moderation")
    print(f"  Greeting: lightweight response for greetings/incomplete inputs (no LLM)")
    print(f"  Intent Router: Bedrock Sonnet + route_registry.json")
    print(f"  Route 1 - Cortex: load_cortex_tool (Cortex API) -> cortex_handler")
    print(f"  Route 2 - No data retrieval: load_no_data_retrieval_node (sample JSON) -> no_data_retrieval_handler")
    print(f"  Route 3 - Dashboard/Map: map_dashboard_response (dashboard | map)")

    return app


# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

_MLFLOW_PARAM_VALUE_MAX = 5900
_MLFLOW_TAG_VALUE_MAX = 4900


def _answer_to_plain_text(answer_raw) -> str:
    if answer_raw is None:
        return ""
    if isinstance(answer_raw, dict):
        return str(answer_raw.get("summary", answer_raw))
    return str(answer_raw)


def _truncate_for_mlflow(value: str, max_len: int) -> str:
    if not value:
        return ""
    if len(value) <= max_len:
        return value
    return value[: max_len - 15] + "\n...[truncated]"


def _log_mlflow_conversation_qa_overview(conv_history) -> None:
    """Surface Q&A in MLflow Overview: per-turn params + cumulative conversation_overview tag."""
    if not conv_history:
        return
    n = len(conv_history)
    last = conv_history[-1]
    q = last.get("question", "") or ""
    a = _answer_to_plain_text(last.get("answer", ""))
    try:
        mlflow.log_param(
            f"turn_{n:02d}_question",
            _truncate_for_mlflow(q, _MLFLOW_PARAM_VALUE_MAX),
        )
        mlflow.log_param(
            f"turn_{n:02d}_answer",
            _truncate_for_mlflow(a, _MLFLOW_PARAM_VALUE_MAX),
        )
    except Exception:
        pass

    lines = []
    for i, turn in enumerate(conv_history, 1):
        tq = turn.get("question", "") or ""
        ta = _answer_to_plain_text(turn.get("answer", ""))
        lines.append(f"=== Turn {i} ===")
        lines.append(f"Q: {tq}")
        lines.append(f"A: {ta}")
        lines.append("")
    overview_full = "\n".join(lines).strip()
    try:
        chunk_size = _MLFLOW_TAG_VALUE_MAX
        chunks = [
            overview_full[i : i + chunk_size]
            for i in range(0, len(overview_full), chunk_size)
        ] or [""]
        for idx, ch in enumerate(chunks):
            key = "conversation_overview" if idx == 0 else f"conversation_overview_{idx + 1}"
            mlflow.set_tag(key, ch)
        mlflow.set_tag("conversation_overview_parts", str(len(chunks)))
        mlflow.set_tag("conversation_turns_logged", str(n))
    except Exception:
        pass


def query_discoveries(
    request: str,
    session_id: Optional[str] = None,
    metadata: Optional[Dict] = None,
    experiment_name: Optional[str] = None,
    notebook_run: bool = False,
) -> Dict:
    """
    Convenience function to query discoveries with the geoscience agent

    Both notebook and FastAPI modes produce an identical MLflow artifact layout:
        response/{session_id}/turn_01.json, turn_02.json, ...
        response/{session_id}/conversation_history.json
        response/{session_id}/summary_1-3.json, summary_1-6.json, summary_1-9.json  (cumulative, every 3 turns)
        response/{session_id}/plots/chart_turn_01.html
        prompts/*.txt  (logged once on turn 1)

    Args:
        request: The discovery query/request
        session_id: Existing session ID or None for new session
        metadata: Optional metadata for Cortex Analyst/data API parameters
        experiment_name: Optional MLflow experiment name (default: config.MLFLOW_EXPERIMENT_NAME).
            Use config.MLFLOW_EXPERIMENT_NAME_NOTEBOOK for notebook runs.
        notebook_run: When True, skip creating a new MLflow run (caller manages the run).
            When False (FastAPI), one MLflow run per session is created and resumed
            on subsequent turns (looked up by session_id tag).

    Returns:
        Dict containing the final state with response
    """
    # Resolve tracking URI at call time so notebook overrides take effect.
    tracking_uri = os.environ.get("MLFLOW_TRACKING_URI", config.MLFLOW_TRACKING_URI)
    mlflow.set_tracking_uri(tracking_uri)

    exp_name = experiment_name or config.MLFLOW_EXPERIMENT_NAME
    mlflow.set_experiment(exp_name)
    experiment = mlflow.get_experiment_by_name(exp_name)

    if not notebook_run:
        # FastAPI mode: single MLflow run per session (identical layout to notebook)
        client = mlflow.tracking.MlflowClient()
        experiment_id = experiment.experiment_id if experiment else "0"

        # For existing sessions, find and resume the session's MLflow run
        existing_run_id = None
        if session_id:
            existing_runs = client.search_runs(
                experiment_ids=[experiment_id],
                filter_string=f"tags.session_id = '{session_id}'",
                max_results=1,
                order_by=["start_time DESC"],
            )
            if existing_runs:
                existing_run_id = existing_runs[0].info.run_id

        if existing_run_id:
            run_name = existing_runs[0].info.run_name or "resumed"
            run_context = mlflow.start_run(run_id=existing_run_id)
        else:
            total_runs = 0
            page_token = None
            while True:
                page = client.search_runs(
                    experiment_ids=[experiment_id],
                    max_results=1000,
                    page_token=page_token,
                )
                total_runs += len(page)
                page_token = page.token if hasattr(page, "token") else None
                if not page_token:
                    break
            run_number = total_runs + 1
            run_name = f"run_{run_number:04d}"
            run_context = mlflow.start_run(run_name=run_name)
    else:
        # Notebook mode: caller owns the MLflow run, just log into it
        run_name = "notebook"
        run_context = nullcontext()

    with run_context:
        start_time = time.time()
        
        # Build workflow
        workflow = build_discovery_workflow()
        
        # Determine turn number
        if session_id:
            sm = SessionManager()
            session = sm.load_session(session_id)
            turn_number = len(session.get("conversation_history", [])) + 1 if session else 1
        else:
            turn_number = 1

        # Prompt versions for artifact (prompt used to answer)
        prompt_versions = config.get_prompt_versions()
        
        # Generate unique thread_id for new sessions
        if session_id:
            thread_id = session_id
        else:
            thread_id = str(uuid.uuid4())
            session_id = thread_id
        
        # Configure checkpointer with thread_id
        checkpoint_config = {"configurable": {"thread_id": thread_id}}
        
        # Check if this is a continuation (checkpointer has existing state)
        existing_state = workflow.get_state(checkpoint_config)
        
        if existing_state and existing_state.values:
            # Continuing existing conversation - pass new data + persist running_summary.
            # Explicitly reset per-turn fields so stale checkpoint values never leak
            # into the new execution (e.g. previous current_response or intent_route).
            print(f"Continuing conversation with thread_id: {thread_id}")
            existing = existing_state.values
            initial_state = {
                "session_id": session_id,
                "thread_id": thread_id,
                "current_request": request,
                "metadata": metadata,
                "turn_number": turn_number,
                "prompt_versions": prompt_versions,
                "token_usage": existing.get("token_usage") or {},
                "running_summary": existing.get("running_summary") or "",
                "current_response": None,
                "intent_route": None,
                "intent_classification": None,
                "guardrail_check": None,
                "is_blocked": False,
                "status": "initialized",
                "error": None,
            }
        else:
            # New conversation - initialize full state
            print(f"Starting new conversation with thread_id: {thread_id}")
            initial_state = {
                "session_id": session_id,
                "thread_id": thread_id,
                "current_request": request,
                "metadata": metadata,
                "turn_number": turn_number,
                "model_id": SONNET_45_CONFIG["model_id"],
                "conversation_history": [],
                "messages": [],
                "is_blocked": False,
                "status": "initialized",
                "error": None,
                "timestamp": datetime.now().isoformat(),
                "prompt_versions": prompt_versions,
                "token_usage": {},
            }
        
        # Execute workflow with checkpointer
        result = workflow.invoke(initial_state, config=checkpoint_config)
        
        # Calculate execution time
        execution_time = time.time() - start_time
        final_session_id = result.get("session_id") or session_id or "new_session"

        # current_response may be nested; top-level data_table/vega_lite_spec used by some nodes
        current_response = result.get("current_response") or {}
        current_response = dict(current_response)
        if not current_response.get("data_table") and result.get("data_table"):
            current_response["data_table"] = result.get("data_table")
        if not current_response.get("vega_lite_spec") and result.get("vega_lite_spec"):
            current_response["vega_lite_spec"] = result.get("vega_lite_spec")
        if not current_response.get("summary") and result.get("response_summary"):
            current_response["summary"] = result.get("response_summary")
        if not current_response.get("key_insights") and result.get("key_insights"):
            current_response["key_insights"] = result.get("key_insights")
        is_blocked = result.get("is_blocked", False)
        data_table_rows = len(current_response.get("data_table", []))
        key_insights_count = len(current_response.get("key_insights", []))

        # Token usage
        token_usage = dict(result.get("token_usage") or {})
        total_input = 0
        total_output = 0
        for component in ("guardrail", "intent_router", "summarization"):
            usage = token_usage.get(component, {})
            if isinstance(usage, dict):
                inp = usage.get("input_tokens", 0)
                out = usage.get("output_tokens", 0)
            else:
                inp, out = 0, 0
            total_input += inp
            total_output += out

        base_dir = Path(config.BASE_DIR) if hasattr(config, "BASE_DIR") else Path(__file__).resolve().parent

        if notebook_run:
            # ── Notebook mode: single MLflow run, session-id-organized artifacts ──
            step = turn_number
            mlflow.log_metric("execution_time_seconds", execution_time, step=step)
            mlflow.log_metric("blocked", 1 if is_blocked else 0, step=step)
            mlflow.log_metric("data_table_rows", data_table_rows, step=step)
            mlflow.log_metric("key_insights_count", key_insights_count, step=step)
            for comp in ("guardrail", "intent_router", "summarization"):
                u = token_usage.get(comp, {})
                mlflow.log_metric(f"tokens_{comp}_input", u.get("input_tokens", 0) if isinstance(u, dict) else 0, step=step)
                mlflow.log_metric(f"tokens_{comp}_output", u.get("output_tokens", 0) if isinstance(u, dict) else 0, step=step)
            mlflow.log_metric("tokens_total_input", total_input, step=step)
            mlflow.log_metric("tokens_total_output", total_output, step=step)
            mlflow.log_metric("tokens_total", total_input + total_output, step=step)

            _log_mlflow_conversation_qa_overview(result.get("conversation_history", []))

            try:
                with tempfile.TemporaryDirectory() as tmpdir:
                    root = Path(tmpdir)

                    # Prompts: log once on the first turn (identical across turns)
                    # Dynamically scan the prompts folder so every file is captured
                    if turn_number == 1:
                        prompts_dir = root / "prompts"
                        prompts_dir.mkdir()
                        local_prompts_dir = base_dir / "prompts"
                        if local_prompts_dir.is_dir():
                            for prompt_file in sorted(local_prompts_dir.iterdir()):
                                if prompt_file.is_file() and prompt_file.name != "geoscience_domain_prompt.md":
                                    content = prompt_file.read_text(encoding="utf-8")
                                    (prompts_dir / prompt_file.name).write_text(content, encoding="utf-8")

                    # Response: organized under response/{session_id}/
                    session_dir = root / "response" / final_session_id
                    session_dir.mkdir(parents=True)

                    # Per-turn QnA log
                    conv_history = result.get("conversation_history", [])
                    running_summary = result.get("running_summary", "")
                    data_table = current_response.get("data_table", [])
                    now_ts = datetime.now().isoformat()
                    turn_data = {
                        "session_id": final_session_id,
                        "turn_number": turn_number,
                        "timestamp": now_ts,
                        "question": request,
                        "summary": current_response.get("summary"),
                        "key_insights": current_response.get("key_insights"),
                        "data_table": data_table,
                        "data_table_row_count": len(data_table),
                        "analysis": current_response.get("analysis"),
                    }
                    (session_dir / f"turn_{turn_number:02d}.json").write_text(
                        json.dumps(turn_data, indent=2), encoding="utf-8"
                    )

                    # Summary snapshot after every 3 turns (summary_1-3.json, summary_1-6.json, summary_1-9.json)
                    # Filename reflects cumulative span: summary_1-6 = cumulative summary of turns 1-6
                    if running_summary and turn_number % 3 == 0:
                        chunk_end = turn_number
                        (session_dir / f"summary_1-{chunk_end}.json").write_text(
                            json.dumps(
                                {
                                    "session_id": final_session_id,
                                    "summary_for_turns": f"1-{chunk_end}",
                                    "generated_at_turn": turn_number,
                                    "timestamp": now_ts,
                                    "running_summary": running_summary,
                                },
                                indent=2,
                            ),
                            encoding="utf-8",
                        )

                    # Conversation history: ordered entries interleaving turns and summaries
                    # turn_01, turn_02, turn_03, summary_1-3, turn_04, ..., summary_1-9, turn_10
                    #
                    # Each summary entry gets the running_summary AS IT WAS at that
                    # checkpoint — NOT the final accumulated value.
                    # Chunks are joined with "\n\n", so we split to reconstruct snapshots.
                    num_checkpoints = turn_number // 3
                    progressive_summaries = []
                    if running_summary and num_checkpoints > 0:
                        parts = running_summary.split("\n\n")
                        if len(parts) == num_checkpoints:
                            progressive_summaries = [
                                "\n\n".join(parts[: i + 1]) for i in range(num_checkpoints)
                            ]
                        else:
                            progressive_summaries = [running_summary] * num_checkpoints

                    entries = []
                    summary_idx = 0
                    for idx, hist_turn in enumerate(conv_history, 1):
                        answer_raw = hist_turn.get("answer", "")
                        answer_text = (
                            answer_raw.get("summary", str(answer_raw))
                            if isinstance(answer_raw, dict) else str(answer_raw)
                        )
                        entries.append({
                            "type": "turn",
                            "file": f"turn_{idx:02d}.json",
                            "turn_number": idx,
                            "timestamp": hist_turn.get("timestamp", ""),
                            "question": hist_turn.get("question", ""),
                            "answer": answer_text,
                        })
                        if idx % 3 == 0 and summary_idx < len(progressive_summaries):
                            entries.append({
                                "type": "summary",
                                "file": f"summary_1-{idx}.json",
                                "summary_for_turns": f"1-{idx}",
                                "generated_at_turn": idx,
                                "timestamp": hist_turn.get("timestamp", ""),
                                "session_id": final_session_id,
                                "running_summary": progressive_summaries[summary_idx],
                            })
                            summary_idx += 1

                    (session_dir / "conversation_history.json").write_text(
                        json.dumps(
                            {
                                "session_id": final_session_id,
                                "timestamp": now_ts,
                                "total_entries": len(entries),
                                "entries": entries,
                                "running_summary": running_summary or None,
                            },
                            indent=2,
                        ),
                        encoding="utf-8",
                    )

                    # Plots: only when THIS turn is the first to produce a vega_lite_spec.
                    # The summarization processor regenerates the same chart every turn from
                    # the same data, so we check whether the prior state already had one.
                    prior_had_vega = (
                        existing_state and existing_state.values
                        and existing_state.values.get("vega_lite_spec")
                    )
                    turn_vega_spec = current_response.get("vega_lite_spec")
                    if turn_vega_spec and not prior_had_vega:
                        plots_dir = session_dir / "plots"
                        plots_dir.mkdir(exist_ok=True)
                        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <script src="https://cdn.jsdelivr.net/npm/vega@5"></script>
    <script src="https://cdn.jsdelivr.net/npm/vega-lite@5"></script>
    <script src="https://cdn.jsdelivr.net/npm/vega-embed@6"></script>
</head>
<body>
    <div id="vis"></div>
    <script>
        vegaEmbed("#vis", {json.dumps(turn_vega_spec)});
    </script>
</body>
</html>"""
                        (plots_dir / f"chart_turn_{turn_number:02d}.html").write_text(
                            html_content, encoding="utf-8"
                        )

                    mlflow.log_artifacts(tmpdir)
            except Exception as e:
                print(f"⚠️ MLflow artifact logging failed: {e}")

            print(f"✓ MLflow turn {turn_number} logged: session_id={final_session_id}, "
                  f"execution_time={execution_time:.2f}s, blocked={is_blocked}, tokens={total_input + total_output}")

        else:
            # ── FastAPI mode: single MLflow run per session, identical to notebook layout ──
            mlflow.set_tag("session_id", final_session_id)
            if turn_number == 1:
                mlflow.log_param("session_id", final_session_id)
            step = turn_number
            mlflow.log_metric("execution_time_seconds", execution_time, step=step)
            mlflow.log_metric("blocked", 1 if is_blocked else 0, step=step)
            mlflow.log_metric("data_table_rows", data_table_rows, step=step)
            mlflow.log_metric("key_insights_count", key_insights_count, step=step)
            for comp in ("guardrail", "intent_router", "summarization"):
                u = token_usage.get(comp, {})
                mlflow.log_metric(f"tokens_{comp}_input", u.get("input_tokens", 0) if isinstance(u, dict) else 0, step=step)
                mlflow.log_metric(f"tokens_{comp}_output", u.get("output_tokens", 0) if isinstance(u, dict) else 0, step=step)
            mlflow.log_metric("tokens_total_input", total_input, step=step)
            mlflow.log_metric("tokens_total_output", total_output, step=step)
            mlflow.log_metric("tokens_total", total_input + total_output, step=step)

            _log_mlflow_conversation_qa_overview(result.get("conversation_history", []))

            try:
                with tempfile.TemporaryDirectory() as tmpdir:
                    root = Path(tmpdir)

                    # Prompts: always log so they appear in every FastAPI run
                    # Dynamically scan the prompts folder so every file is captured
                    prompts_dir = root / "prompts"
                    prompts_dir.mkdir()
                    local_prompts_dir = base_dir / "prompts"
                    if local_prompts_dir.is_dir():
                        for prompt_file in sorted(local_prompts_dir.iterdir()):
                            if prompt_file.is_file() and prompt_file.name != "geoscience_domain_prompt.md":
                                content = prompt_file.read_text(encoding="utf-8")
                                (prompts_dir / prompt_file.name).write_text(content, encoding="utf-8")

                    # Response: organized under response/{session_id}/
                    session_dir = root / "response" / final_session_id
                    session_dir.mkdir(parents=True)

                    # Per-turn QnA log
                    conv_history = result.get("conversation_history", [])
                    running_summary = result.get("running_summary", "")
                    data_table = current_response.get("data_table", [])
                    now_ts = datetime.now().isoformat()
                    turn_data = {
                        "session_id": final_session_id,
                        "turn_number": turn_number,
                        "timestamp": now_ts,
                        "question": request,
                        "summary": current_response.get("summary"),
                        "key_insights": current_response.get("key_insights"),
                        "data_table": data_table,
                        "data_table_row_count": len(data_table),
                        "analysis": current_response.get("analysis"),
                    }
                    (session_dir / f"turn_{turn_number:02d}.json").write_text(
                        json.dumps(turn_data, indent=2), encoding="utf-8"
                    )

                    # Summary snapshot after every 3 turns (summary_1-3.json, summary_1-6.json, summary_1-9.json)
                    # Filename reflects cumulative span: summary_1-6 = cumulative summary of turns 1-6
                    if running_summary and turn_number % 3 == 0:
                        chunk_end = turn_number
                        (session_dir / f"summary_1-{chunk_end}.json").write_text(
                            json.dumps(
                                {
                                    "session_id": final_session_id,
                                    "summary_for_turns": f"1-{chunk_end}",
                                    "generated_at_turn": turn_number,
                                    "timestamp": now_ts,
                                    "running_summary": running_summary,
                                },
                                indent=2,
                            ),
                            encoding="utf-8",
                        )

                    # Conversation history: ordered entries interleaving turns and summaries
                    num_checkpoints = turn_number // 3
                    progressive_summaries = []
                    if running_summary and num_checkpoints > 0:
                        parts = running_summary.split("\n\n")
                        if len(parts) == num_checkpoints:
                            progressive_summaries = [
                                "\n\n".join(parts[: i + 1]) for i in range(num_checkpoints)
                            ]
                        else:
                            progressive_summaries = [running_summary] * num_checkpoints

                    entries = []
                    summary_idx = 0
                    for idx, hist_turn in enumerate(conv_history, 1):
                        answer_raw = hist_turn.get("answer", "")
                        answer_text = (
                            answer_raw.get("summary", str(answer_raw))
                            if isinstance(answer_raw, dict) else str(answer_raw)
                        )
                        entries.append({
                            "type": "turn",
                            "file": f"turn_{idx:02d}.json",
                            "turn_number": idx,
                            "timestamp": hist_turn.get("timestamp", ""),
                            "question": hist_turn.get("question", ""),
                            "answer": answer_text,
                        })
                        if idx % 3 == 0 and summary_idx < len(progressive_summaries):
                            entries.append({
                                "type": "summary",
                                "file": f"summary_1-{idx}.json",
                                "summary_for_turns": f"1-{idx}",
                                "generated_at_turn": idx,
                                "timestamp": hist_turn.get("timestamp", ""),
                                "session_id": final_session_id,
                                "running_summary": progressive_summaries[summary_idx],
                            })
                            summary_idx += 1

                    (session_dir / "conversation_history.json").write_text(
                        json.dumps(
                            {
                                "session_id": final_session_id,
                                "timestamp": now_ts,
                                "total_entries": len(entries),
                                "entries": entries,
                                "running_summary": running_summary or None,
                            },
                            indent=2,
                        ),
                        encoding="utf-8",
                    )

                    # Plots: only when THIS turn first produces a vega_lite_spec
                    prior_had_vega = (
                        existing_state and existing_state.values
                        and existing_state.values.get("vega_lite_spec")
                    )
                    turn_vega_spec = current_response.get("vega_lite_spec")
                    if turn_vega_spec and not prior_had_vega:
                        plots_dir = session_dir / "plots"
                        plots_dir.mkdir(exist_ok=True)
                        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <script src="https://cdn.jsdelivr.net/npm/vega@5"></script>
    <script src="https://cdn.jsdelivr.net/npm/vega-lite@5"></script>
    <script src="https://cdn.jsdelivr.net/npm/vega-embed@6"></script>
</head>
<body>
    <div id="vis"></div>
    <script>
        vegaEmbed("#vis", {json.dumps(turn_vega_spec)});
    </script>
</body>
</html>"""
                        (plots_dir / f"chart_turn_{turn_number:02d}.html").write_text(
                            html_content, encoding="utf-8"
                        )

                    mlflow.log_artifacts(tmpdir)
            except Exception as e:
                print(f"⚠️ MLflow artifact logging failed: {e}")

            print(f"✓ MLflow turn {turn_number} logged (run={run_name}): session_id={final_session_id}, "
                  f"execution_time={execution_time:.2f}s, blocked={is_blocked}, tokens={total_input + total_output}")
        
        return result


__all__ = ['build_discovery_workflow', 'query_discoveries']
