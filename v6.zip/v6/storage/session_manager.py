"""
Session Management for Multi-turn QA
Handles session creation, loading, and persistence
"""

import json
import uuid
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
from geoscience_agent.config import config

class SessionManager:
    """Manages conversation sessions for multi-turn QA"""
    
    def __init__(self, sessions_dir: Optional[str] = None):
        """
        Initialize session manager.
        
        Args:
            sessions_dir: Directory to store session files (defaults to config.SESSIONS_DIR)
        """
        self.sessions_dir = Path(sessions_dir or config.SESSIONS_DIR)
        self.sessions_dir.mkdir(parents=True, exist_ok=True)
    
    def create_session(
        self,
        context_file: str = "data/geo.json",
        session_id: Optional[str] = None,
    ) -> Dict:
        """
        Create a new session.

        Args:
            context_file: Path to the context JSON file
            session_id: Optional session ID (uses new UUID if not provided)

        Returns:
            New session dictionary
        """
        session_id = session_id or str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        session = {
            "session_id": session_id,
            "created_at": timestamp,
            "last_updated": timestamp,
            "context_file": context_file,
            "conversation_history": [],
            "running_summary": "",
        }
        
        self._save_session(session)
        return session
    
    def load_session(self, session_id: str) -> Optional[Dict]:
        """
        Load an existing session.
        
        Args:
            session_id: Session ID to load
            
        Returns:
            Session dictionary or None if not found
        """
        session_file = self.sessions_dir / f"{session_id}.json"
        
        if not session_file.exists():
            return None
        
        with open(session_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def save_session(self, session: Dict):
        """
        Save session to disk.
        
        Args:
            session: Session dictionary to save
        """
        session["last_updated"] = datetime.now().isoformat()
        self._save_session(session)
    
    def _save_session(self, session: Dict):
        """Internal method to save session"""
        session_file = self.sessions_dir / f"{session['session_id']}.json"
        
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session, f, indent=2)
    
    def add_turn(
        self,
        session: Dict,
        question: str,
        answer: str,
        metadata: Optional[Dict] = None
    ) -> Dict:
        """
        Add a conversation turn to the session.
        
        Args:
            session: Session dictionary
            question: User question
            answer: System answer
            metadata: Optional metadata about the turn
            
        Returns:
            Updated session
        """
        turn_number = len(session["conversation_history"]) + 1
        
        turn = {
            "turn": turn_number,
            "question": question,
            "answer": answer,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        
        session["conversation_history"].append(turn)
        self.save_session(session)
        
        return session
    
    def get_conversation_history(self, session: Dict) -> List[Dict]:
        """
        Get conversation history from session.
        
        Args:
            session: Session dictionary
            
        Returns:
            List of conversation turns
        """
        return session.get("conversation_history", [])
    
    def format_history_for_prompt(self, session: Dict) -> str:
        """
        Format conversation history for inclusion in prompt.
        
        Args:
            session: Session dictionary
            
        Returns:
            Formatted conversation history string
        """
        history = self.get_conversation_history(session)
        
        if not history:
            return "No previous conversation."
        
        formatted_lines = []
        for turn in history:
            formatted_lines.append(f"Turn {turn['turn']}:")
            formatted_lines.append(f"Q: {turn['question']}")
            formatted_lines.append(f"A: {turn['answer']}")
            formatted_lines.append("")
        
        return "\n".join(formatted_lines)
    
    def list_sessions(self) -> List[Dict]:
        """
        List all sessions.
        
        Returns:
            List of session metadata
        """
        sessions = []
        
        for session_file in self.sessions_dir.glob("*.json"):
            try:
                with open(session_file, 'r', encoding='utf-8') as f:
                    session = json.load(f)
                    sessions.append({
                        "session_id": session["session_id"],
                        "created_at": session["created_at"],
                        "last_updated": session["last_updated"],
                        "num_turns": len(session["conversation_history"])
                    })
            except Exception as e:
                print(f"Error loading session {session_file}: {e}")
        
        return sorted(sessions, key=lambda x: x["last_updated"], reverse=True)
    
    def delete_session(self, session_id: str) -> bool:
        """
        Delete a session.
        
        Args:
            session_id: Session ID to delete
            
        Returns:
            True if deleted, False if not found
        """
        session_file = self.sessions_dir / f"{session_id}.json"
        
        if session_file.exists():
            session_file.unlink()
            return True
        
        return False


__all__ = ['SessionManager']