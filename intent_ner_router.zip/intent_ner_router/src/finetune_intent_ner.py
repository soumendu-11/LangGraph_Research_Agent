"""
Joint Intent Classification + NER Fine-Tuning with LoRA
Base model: distilbert-base-uncased
LoRA params: r=4, lora_alpha=32, lora_dropout=0.01, target_modules=['q_lin']
Training: lr=1e-3, batch_size=8, epochs=3, weight_decay=0.01
"""

import json
import os
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_recall_fscore_support,
)
from transformers import (
    AutoTokenizer,
    AutoModel,
    DataCollatorWithPadding,
    Trainer,
    TrainingArguments,
)
from peft import LoraConfig, get_peft_model, TaskType

# ──────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────
MODEL_CHECKPOINT = "distilbert-base-uncased"
DATA_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR = PROJECT_ROOT / "models" / "joint_intent_ner_lora"
MAX_LENGTH = 128

INTENT_CLASSES = [
    "field_info",
    "reservoir_info",
    "basin_map",
    "field_map",
    "ask_analyst",
    "map_viewport",
    "out_of_scope",
]
INTENT2ID = {label: i for i, label in enumerate(INTENT_CLASSES)}
ID2INTENT = {i: label for label, i in INTENT2ID.items()}

NER_TAGS = [
    "O",
    "B-FIELD_ID", "I-FIELD_ID",
    "B-FIELD_NAME", "I-FIELD_NAME",
    "B-RESERVOIR_ID", "I-RESERVOIR_ID",
    "B-RESERVOIR_NAME", "I-RESERVOIR_NAME",
    "B-COUNTRY_NAME", "I-COUNTRY_NAME",
    "B-BASIN_NAME", "I-BASIN_NAME",
    "B-BASIN_TYPE", "I-BASIN_TYPE",
    "B-LAYER_TYPE", "I-LAYER_TYPE",
    "B-QUESTION", "I-QUESTION",
    "B-BBOX", "I-BBOX",
]
TAG2ID = {tag: i for i, tag in enumerate(NER_TAGS)}
ID2TAG = {i: tag for tag, i in TAG2ID.items()}
NUM_NER_LABELS = len(NER_TAGS)
NUM_INTENT_LABELS = len(INTENT_CLASSES)


# ──────────────────────────────────────────────
# Dataset
# ──────────────────────────────────────────────
class JointIntentNERDataset(Dataset):
    """Dataset that produces intent labels + token-level NER labels."""

    def __init__(self, jsonl_path: str, tokenizer, max_length: int = MAX_LENGTH):
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.samples = []

        with open(jsonl_path) as f:
            for line in f:
                self.samples.append(json.loads(line))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        sample = self.samples[idx]
        utterance = sample["utterance"]
        intent_id = INTENT2ID[sample["intent"]]

        # Word-level tokens and BIO tags from generation
        words = sample.get("tokens", utterance.split())
        word_tags = sample.get("bio_tags", ["O"] * len(words))

        # Tokenize with word alignment
        encoding = self.tokenizer(
            words,
            is_split_into_words=True,
            max_length=self.max_length,
            padding="max_length",
            truncation=True,
            return_tensors="pt",
        )

        # Align NER labels to subword tokens
        word_ids = encoding.word_ids(batch_index=0)
        aligned_labels = []
        previous_word_id = None

        for word_id in word_ids:
            if word_id is None:
                aligned_labels.append(-100)  # special tokens
            elif word_id != previous_word_id:
                tag = word_tags[word_id] if word_id < len(word_tags) else "O"
                aligned_labels.append(TAG2ID.get(tag, 0))
            else:
                # Subword continuation: use I- tag if B- was the head
                tag = word_tags[word_id] if word_id < len(word_tags) else "O"
                if tag.startswith("B-"):
                    aligned_labels.append(TAG2ID.get("I-" + tag[2:], 0))
                else:
                    aligned_labels.append(TAG2ID.get(tag, 0))
            previous_word_id = word_id

        return {
            "input_ids": encoding["input_ids"].squeeze(0),
            "attention_mask": encoding["attention_mask"].squeeze(0),
            "intent_labels": torch.tensor(intent_id, dtype=torch.long),
            "ner_labels": torch.tensor(aligned_labels, dtype=torch.long),
        }


# ──────────────────────────────────────────────
# Model: Joint Intent + NER on top of DistilBERT
# ──────────────────────────────────────────────
class JointIntentNERModel(nn.Module):
    """
    Shared DistilBERT encoder with two heads:
    - Intent classification head (CLS token)
    - NER token classification head (all tokens)
    """

    def __init__(self, model_checkpoint, num_intent_labels, num_ner_labels):
        super().__init__()
        self.encoder = AutoModel.from_pretrained(model_checkpoint)
        hidden_size = self.encoder.config.hidden_size

        self.intent_head = nn.Linear(hidden_size, num_intent_labels)
        self.ner_head = nn.Linear(hidden_size, num_ner_labels)

        self.intent_loss_fn = nn.CrossEntropyLoss()
        self.ner_loss_fn = nn.CrossEntropyLoss(ignore_index=-100)

    def forward(self, input_ids, attention_mask, intent_labels=None, ner_labels=None):
        outputs = self.encoder(input_ids=input_ids, attention_mask=attention_mask)
        sequence_output = outputs.last_hidden_state  # (batch, seq_len, hidden)
        cls_output = sequence_output[:, 0, :]  # (batch, hidden)

        intent_logits = self.intent_head(cls_output)  # (batch, num_intents)
        ner_logits = self.ner_head(sequence_output)  # (batch, seq_len, num_ner)

        loss = None
        if intent_labels is not None and ner_labels is not None:
            intent_loss = self.intent_loss_fn(intent_logits, intent_labels)
            ner_loss = self.ner_loss_fn(
                ner_logits.view(-1, ner_logits.size(-1)),
                ner_labels.view(-1),
            )
            loss = intent_loss + ner_loss

        return {
            "loss": loss,
            "intent_logits": intent_logits,
            "ner_logits": ner_logits,
        }


# ──────────────────────────────────────────────
# Custom Trainer to handle joint outputs
# ──────────────────────────────────────────────
class JointTrainer(Trainer):
    def compute_loss(self, model, inputs, return_outputs=False, **kwargs):
        outputs = model(
            input_ids=inputs["input_ids"],
            attention_mask=inputs["attention_mask"],
            intent_labels=inputs["intent_labels"],
            ner_labels=inputs["ner_labels"],
        )
        loss = outputs["loss"]
        return (loss, outputs) if return_outputs else loss

    def prediction_step(self, model, inputs, prediction_loss_only, ignore_keys=None):
        inputs = self._prepare_inputs(inputs)
        with torch.no_grad():
            outputs = model(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                intent_labels=inputs["intent_labels"],
                ner_labels=inputs["ner_labels"],
            )

        loss = outputs["loss"]
        intent_logits = outputs["intent_logits"]
        ner_logits = outputs["ner_logits"]

        # Pack intent and ner logits together for compute_metrics
        # Intent: (batch, num_intents), NER: (batch, seq_len, num_ner)
        # We store intent labels and ner labels separately
        intent_labels = inputs["intent_labels"]
        ner_labels = inputs["ner_labels"]

        return (
            loss,
            (intent_logits, ner_logits),
            (intent_labels, ner_labels),
        )


# ──────────────────────────────────────────────
# Data collator for joint model
# ──────────────────────────────────────────────
class JointDataCollator:
    def __call__(self, features):
        batch = {
            "input_ids": torch.stack([f["input_ids"] for f in features]),
            "attention_mask": torch.stack([f["attention_mask"] for f in features]),
            "intent_labels": torch.stack([f["intent_labels"] for f in features]),
            "ner_labels": torch.stack([f["ner_labels"] for f in features]),
        }
        return batch


# ──────────────────────────────────────────────
# Metrics
# ──────────────────────────────────────────────
def compute_metrics(eval_pred):
    (intent_logits, ner_logits), (intent_labels, ner_labels) = eval_pred

    # Intent metrics
    intent_preds = np.argmax(intent_logits, axis=-1)
    intent_acc = accuracy_score(intent_labels, intent_preds)
    intent_prec, intent_rec, intent_f1, _ = precision_recall_fscore_support(
        intent_labels, intent_preds, average="weighted", zero_division=0
    )

    # NER metrics (ignore -100 padding)
    ner_preds = np.argmax(ner_logits, axis=-1)  # (batch, seq_len)
    ner_preds_flat = ner_preds.flatten()
    ner_labels_flat = ner_labels.flatten()

    mask = ner_labels_flat != -100
    ner_preds_filtered = ner_preds_flat[mask]
    ner_labels_filtered = ner_labels_flat[mask]

    ner_acc = accuracy_score(ner_labels_filtered, ner_preds_filtered)
    ner_prec, ner_rec, ner_f1, _ = precision_recall_fscore_support(
        ner_labels_filtered, ner_preds_filtered, average="weighted", zero_division=0
    )

    return {
        "intent_accuracy": intent_acc,
        "intent_f1": intent_f1,
        "intent_precision": intent_prec,
        "intent_recall": intent_rec,
        "ner_accuracy": ner_acc,
        "ner_f1": ner_f1,
        "ner_precision": ner_prec,
        "ner_recall": ner_rec,
    }


# ──────────────────────────────────────────────
# Main
# ──────────────────────────────────────────────
def run_finetuning():
    """Full fine-tuning pipeline. Returns trainer and training history."""
    start_time = time.time()

    # Tokenizer
    tokenizer = AutoTokenizer.from_pretrained(MODEL_CHECKPOINT)

    # Datasets
    train_dataset = JointIntentNERDataset(DATA_DIR / "train.jsonl", tokenizer)
    val_dataset = JointIntentNERDataset(DATA_DIR / "val.jsonl", tokenizer)

    print(f"Train samples: {len(train_dataset)}")
    print(f"Val samples  : {len(val_dataset)}")

    # Model
    model = JointIntentNERModel(MODEL_CHECKPOINT, NUM_INTENT_LABELS, NUM_NER_LABELS)

    # LoRA — same config as code_v1.ipynb
    peft_config = LoraConfig(
        task_type=TaskType.FEATURE_EXTRACTION,
        r=4,
        lora_alpha=32,
        lora_dropout=0.01,
        target_modules=["q_lin"],
    )
    model.encoder = get_peft_model(model.encoder, peft_config)
    model.encoder.print_trainable_parameters()

    # Training args — same as code_v1.ipynb
    training_args = TrainingArguments(
        output_dir=str(OUTPUT_DIR),
        learning_rate=1e-3,
        per_device_train_batch_size=8,
        per_device_eval_batch_size=8,
        num_train_epochs=3,
        weight_decay=0.01,
        do_train=True,
        do_eval=True,
        eval_strategy="epoch",
        logging_dir=str(OUTPUT_DIR / "logs"),
        logging_steps=10,
        save_steps=500,
        save_strategy="steps",
        load_best_model_at_end=False,
        report_to="none",
    )

    # Trainer
    trainer = JointTrainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        data_collator=JointDataCollator(),
        compute_metrics=compute_metrics,
    )

    # Train
    train_result = trainer.train()

    # Evaluate
    eval_result = trainer.evaluate()

    # Predict on val set for confusion matrix / classification report
    predictions = trainer.predict(val_dataset)
    intent_logits, ner_logits = predictions.predictions
    intent_labels, ner_labels = predictions.label_ids

    intent_preds = np.argmax(intent_logits, axis=-1)

    # Intent classification report
    intent_report = classification_report(
        intent_labels, intent_preds,
        target_names=INTENT_CLASSES,
        zero_division=0,
    )

    # Intent confusion matrix
    intent_cm = confusion_matrix(intent_labels, intent_preds)

    # NER classification report (filtered)
    ner_preds_all = np.argmax(ner_logits, axis=-1).flatten()
    ner_labels_all = ner_labels.flatten()
    mask = ner_labels_all != -100
    ner_preds_filtered = ner_preds_all[mask]
    ner_labels_filtered = ner_labels_all[mask]

    # Only report on tags that appear in the data
    present_tags = sorted(set(ner_labels_filtered.tolist()) | set(ner_preds_filtered.tolist()))
    present_tag_names = [ID2TAG[t] for t in present_tags]

    ner_report = classification_report(
        ner_labels_filtered, ner_preds_filtered,
        labels=present_tags,
        target_names=present_tag_names,
        zero_division=0,
    )

    elapsed = time.time() - start_time
    print(f"\nTraining time: {elapsed:.2f} seconds")
    print(f"\n{'='*60}")
    print("INTENT CLASSIFICATION REPORT")
    print(f"{'='*60}")
    print(intent_report)
    print(f"\n{'='*60}")
    print("NER CLASSIFICATION REPORT")
    print(f"{'='*60}")
    print(ner_report)

    # Save model
    save_model_for_inference(model, tokenizer, OUTPUT_DIR)
    print(f"\nModel saved to: {OUTPUT_DIR}")

    return {
        "trainer": trainer,
        "train_result": train_result,
        "eval_result": eval_result,
        "intent_preds": intent_preds,
        "intent_labels": intent_labels,
        "intent_cm": intent_cm,
        "intent_report": intent_report,
        "ner_preds_filtered": ner_preds_filtered,
        "ner_labels_filtered": ner_labels_filtered,
        "ner_report": ner_report,
        "elapsed": elapsed,
    }


def save_model_for_inference(model, tokenizer, output_dir: Path):
    """
    Save the full model (LoRA adapter + classification heads + config)
    in a single directory that can be loaded for inference.

    Saved structure:
        output_dir/
        ├── lora_adapter/       # LoRA adapter weights (PEFT)
        ├── intent_head.pt      # Intent classification head
        ├── ner_head.pt         # NER token classification head
        ├── tokenizer/          # Tokenizer files
        └── config.json         # Label mappings and model metadata
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 1. Save LoRA adapter
    adapter_dir = output_dir / "lora_adapter"
    model.encoder.save_pretrained(str(adapter_dir))

    # 2. Save classification heads
    torch.save(model.intent_head.state_dict(), str(output_dir / "intent_head.pt"))
    torch.save(model.ner_head.state_dict(), str(output_dir / "ner_head.pt"))

    # 3. Save tokenizer
    tokenizer.save_pretrained(str(output_dir / "tokenizer"))

    # 4. Save label mappings and metadata for reproducible loading
    config = {
        "model_checkpoint": MODEL_CHECKPOINT,
        "max_length": MAX_LENGTH,
        "intent2id": INTENT2ID,
        "id2intent": {str(k): v for k, v in ID2INTENT.items()},
        "tag2id": TAG2ID,
        "id2tag": {str(k): v for k, v in ID2TAG.items()},
        "num_intent_labels": NUM_INTENT_LABELS,
        "num_ner_labels": NUM_NER_LABELS,
    }
    with open(output_dir / "config.json", "w") as f:
        json.dump(config, f, indent=2)

    print(f"Adapter + heads + tokenizer + config saved to: {output_dir}")


def load_model_for_inference(model_dir: str):
    """
    Load the saved model for inference.

    Args:
        model_dir: Path to the saved model directory.

    Returns:
        model: JointIntentNERModel with LoRA adapter merged.
        tokenizer: AutoTokenizer ready for encoding.
        config: Dict with label mappings.
    """
    from peft import PeftModel

    model_dir = Path(model_dir)

    # 1. Load config
    with open(model_dir / "config.json") as f:
        config = json.load(f)

    id2intent = {int(k): v for k, v in config["id2intent"].items()}
    id2tag = {int(k): v for k, v in config["id2tag"].items()}

    # 2. Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(str(model_dir / "tokenizer"))

    # 3. Build base model and load LoRA adapter
    model = JointIntentNERModel(
        config["model_checkpoint"],
        config["num_intent_labels"],
        config["num_ner_labels"],
    )
    model.encoder = PeftModel.from_pretrained(
        model.encoder, str(model_dir / "lora_adapter")
    )
    # Merge LoRA weights into base model for faster inference
    model.encoder = model.encoder.merge_and_unload()

    # 4. Load classification heads
    model.intent_head.load_state_dict(
        torch.load(str(model_dir / "intent_head.pt"), map_location="cpu")
    )
    model.ner_head.load_state_dict(
        torch.load(str(model_dir / "ner_head.pt"), map_location="cpu")
    )

    model.eval()
    print(f"Model loaded from: {model_dir} (LoRA merged)")

    return model, tokenizer, config


def predict(utterance: str, model, tokenizer, config, device="cpu"):
    """
    Run inference on a single utterance.

    Args:
        utterance: Input text (will be lowercased).
        model: Loaded JointIntentNERModel.
        tokenizer: Loaded tokenizer.
        config: Config dict with label mappings.
        device: "cpu" or "cuda".

    Returns:
        dict with predicted intent, confidence, and NER entities.
    """
    id2intent = {int(k): v for k, v in config["id2intent"].items()}
    id2tag = {int(k): v for k, v in config["id2tag"].items()}
    max_length = config["max_length"]

    utterance = utterance.lower().strip()
    words = utterance.split()

    encoding = tokenizer(
        words,
        is_split_into_words=True,
        max_length=max_length,
        padding="max_length",
        truncation=True,
        return_tensors="pt",
    )

    model = model.to(device)
    input_ids = encoding["input_ids"].to(device)
    attention_mask = encoding["attention_mask"].to(device)

    with torch.no_grad():
        outputs = model(input_ids=input_ids, attention_mask=attention_mask)

    # Intent prediction
    intent_probs = torch.softmax(outputs["intent_logits"], dim=-1).cpu().numpy()[0]
    intent_id = int(np.argmax(intent_probs))
    intent_label = id2intent[intent_id]
    intent_confidence = float(intent_probs[intent_id])

    # NER prediction
    ner_logits = outputs["ner_logits"].cpu().numpy()[0]  # (seq_len, num_tags)
    ner_preds = np.argmax(ner_logits, axis=-1)

    # Map subword predictions back to words
    word_ids = encoding.word_ids(batch_index=0)
    entities = []
    current_entity = None

    for idx, word_id in enumerate(word_ids):
        if word_id is None:
            continue

        tag = id2tag.get(int(ner_preds[idx]), "O")

        if tag.startswith("B-"):
            if current_entity:
                entities.append(current_entity)
            current_entity = {
                "entity": tag[2:],
                "value": words[word_id],
                "word_indices": [word_id],
            }
        elif tag.startswith("I-") and current_entity and tag[2:] == current_entity["entity"]:
            if word_id not in current_entity["word_indices"]:
                current_entity["word_indices"].append(word_id)
                current_entity["value"] += " " + words[word_id]
        else:
            if current_entity:
                entities.append(current_entity)
                current_entity = None

    if current_entity:
        entities.append(current_entity)

    # Clean up output
    for ent in entities:
        del ent["word_indices"]

    return {
        "utterance": utterance,
        "intent": intent_label,
        "intent_confidence": round(intent_confidence, 4),
        "entities": entities,
    }


if __name__ == "__main__":
    run_finetuning()
