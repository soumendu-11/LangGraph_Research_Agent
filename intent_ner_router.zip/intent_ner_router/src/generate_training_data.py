"""
Synthetic Training Data Generator for Joint Intent Classification + NER
Uses GPT-4o via OpenAI API to generate 300 samples per 7 intent classes.
Output: JSONL files ready for BERT-base-uncased + LoRA fine-tuning.
"""

import json
import os
import random
import time
from pathlib import Path

from dotenv import load_dotenv
from openai import AzureOpenAI
from tqdm import tqdm

# ──────────────────────────────────────────────
# Config
# ──────────────────────────────────────────────
PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(PROJECT_ROOT / ".env")

client = AzureOpenAI(
    api_key=os.getenv("AZURE_API_KEY"),
    azure_endpoint=os.getenv("AZURE_ENDPOINT"),
    api_version=os.getenv("API_VERSION"),
)

MODEL = os.getenv("DEPLOYMENT_NAME", "gpt-4o")
SAMPLES_PER_BATCH = 50
BATCHES_PER_CLASS = 6  # 6 x 50 = 300 per class
TEMPERATURE = 0.9
MAX_TOKENS = 16000
OUTPUT_DIR = PROJECT_ROOT / "data"
OUTPUT_DIR.mkdir(exist_ok=True)

INTENT_CLASSES = [
    "field_info",
    "reservoir_info",
    "basin_map",
    "field_map",
    "ask_analyst",
    "map_viewport",
    "out_of_scope",
]

# ──────────────────────────────────────────────
# Prompts
# ──────────────────────────────────────────────
SYSTEM_PROMPT = (
    "You are a synthetic-data generator for an oil & gas geoscience platform. "
    "Output ONLY a valid JSON array. No markdown, no explanation. "
    "All utterances must be lowercase and under 40 words."
)

USER_PROMPT_TEMPLATE = """Generate {batch_size} diverse lowercase utterances for intent: {intent_class}. Batch {batch_number}/{total_batches}.

INTENTS:
1. field_info — field dashboards, field queries, field discovery. e.g. "show summary for ghawar", "which fields produce most in oman?"
2. reservoir_info — reservoir dashboards, reservoir queries. e.g. "reservoir summary for rev-1", "compare reservoir performance"
3. basin_map — basin layers on map. e.g. "show main basins in norway", "display sub basins"
4. field_map — field/reservoir layers on map. e.g. "map fields in saudi arabia", "show reservoirs on map for uae"
5. ask_analyst — generic analytical questions, not field/reservoir specific. e.g. "analyze production trends", "what is the overall decline rate?"
6. map_viewport — general map/viewport operations. e.g. "zoom into persian gulf", "load layers for current view"
7. out_of_scope — unrelated to platform. e.g. "hello", "what's the weather?", "book a meeting"

ENTITIES (tag with character offsets):
FIELD_ID (fie-001), FIELD_NAME (ghawar, burgan, zakum), RESERVOIR_ID (res-101), RESERVOIR_NAME (rev-1, ghawar-north), COUNTRY_NAME (oman, uae, saudi arabia), BASIN_NAME (rub al khali, zagros), BASIN_TYPE (main/sub), LAYER_TYPE (field/reservoir), QUESTION (analytical span), BBOX (coordinates)

RULES:
- out_of_scope: always empty entities
- ask_analyst: entire utterance is often QUESTION entity
- ~15% utterances per class can be entity-free
- ~10% should have typos/abbreviations
- Mix short (3-6 words) and long (10-20 words)
- Vary vocabulary, formality, phrasing across samples

BATCH FOCUS:
1=short commands, 2=conversational, 3=questions, 4=typos/slang, 5=multi-entity, 6=edge cases

DOMAIN NAMES:
Countries: oman, uae, saudi arabia, qatar, kuwait, india, norway, brazil, nigeria, iraq, iran, malaysia, australia, angola, egypt, libya, uk, canada, mexico, indonesia, guyana, kazakhstan, azerbaijan
Fields: ghawar, burgan, zakum, dukhan, sabriyah, ratawi, manifa, safaniyah, abqaiq, shaybah, khurais, rumailah, majnoon, kirkuk, troll, ekofisk, johan sverdrup, gullfaks, buzios, lula, marlim
Reservoirs: rev-1, rev-2, ghawar-north, ghawar-south, main-reservoir, arab-d, khuff, mishrif, zubair, burgan-sand, shuaiba
Basins: rub al khali, zagros, ghadames, sirte, niger delta, santos, campos, north sea, barents, permian

OUTPUT FORMAT (JSON array):
[{{"utterance":"show field summary for ghawar in oman","intent":"{intent_class}","entities":[{{"entity":"FIELD_NAME","value":"ghawar","start":24,"end":30}},{{"entity":"COUNTRY_NAME","value":"oman","start":34,"end":38}}]}}]

utterance[start:end] MUST equal value. Double-check offsets. Output ONLY the JSON array."""


# ──────────────────────────────────────────────
# API call
# ──────────────────────────────────────────────
def generate_batch(intent_class: str, batch_number: int) -> list[dict]:
    """Call GPT-4o to generate one batch of training samples."""
    prompt = USER_PROMPT_TEMPLATE.format(
        batch_size=SAMPLES_PER_BATCH,
        intent_class=intent_class,
        batch_number=batch_number,
        total_batches=BATCHES_PER_CLASS,
    )

    response = client.chat.completions.create(
        model=MODEL,
        temperature=TEMPERATURE,
        max_tokens=MAX_TOKENS,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt},
        ],
    )

    text = response.choices[0].message.content.strip()

    # Strip markdown code fences if present
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        if text.endswith("```"):
            text = text[: text.rfind("```")]
        text = text.strip()

    return json.loads(text)


# ──────────────────────────────────────────────
# Validation & fixing
# ──────────────────────────────────────────────
def validate_sample(sample: dict) -> bool:
    """Check if all entity span offsets match the utterance text."""
    utterance = sample.get("utterance", "")
    for ent in sample.get("entities", []):
        if utterance[ent["start"]: ent["end"]] != ent["value"]:
            return False
    return True


def fix_span_offsets(sample: dict) -> dict:
    """Try to fix misaligned entity spans by finding value in utterance."""
    utterance = sample["utterance"]
    for ent in sample.get("entities", []):
        if utterance[ent["start"]: ent["end"]] != ent["value"]:
            idx = utterance.find(ent["value"])
            if idx != -1:
                ent["start"] = idx
                ent["end"] = idx + len(ent["value"])
            else:
                ent["start"] = -1
                ent["end"] = -1
    sample["entities"] = [e for e in sample["entities"] if e["start"] != -1]
    return sample


def convert_to_bio_tags(sample: dict) -> dict:
    """Convert span annotations to BIO token-level tags."""
    utterance = sample["utterance"]
    tokens = utterance.split()
    tags = ["O"] * len(tokens)

    # Map character offsets to token indices
    char_to_token = {}
    pos = 0
    for i, token in enumerate(tokens):
        for j in range(len(token)):
            char_to_token[pos + j] = i
        pos += len(token) + 1

    for ent in sample.get("entities", []):
        start_tok = char_to_token.get(ent["start"])
        end_tok = char_to_token.get(ent["end"] - 1)
        if start_tok is not None and end_tok is not None:
            tags[start_tok] = f"B-{ent['entity']}"
            for t in range(start_tok + 1, end_tok + 1):
                tags[t] = f"I-{ent['entity']}"

    sample["tokens"] = tokens
    sample["bio_tags"] = tags
    return sample


# ──────────────────────────────────────────────
# Main generation pipeline
# ──────────────────────────────────────────────
def run_generation():
    """Generate all training data with progress tracking."""
    all_samples = []
    stats = {cls: {"total": 0, "valid": 0, "fixed": 0, "dropped": 0} for cls in INTENT_CLASSES}

    total_batches = len(INTENT_CLASSES) * BATCHES_PER_CLASS
    pbar = tqdm(total=total_batches, desc="Overall Progress", unit="batch")

    for intent_class in INTENT_CLASSES:
        class_samples = []
        class_pbar = tqdm(
            range(1, BATCHES_PER_CLASS + 1),
            desc=f"  {intent_class:20s}",
            unit="batch",
            leave=False,
        )

        for batch_num in class_pbar:
            try:
                samples = generate_batch(intent_class, batch_num)

                for sample in samples:
                    stats[intent_class]["total"] += 1

                    if not validate_sample(sample):
                        sample = fix_span_offsets(sample)
                        stats[intent_class]["fixed"] += 1

                    if validate_sample(sample):
                        sample = convert_to_bio_tags(sample)
                        class_samples.append(sample)
                        stats[intent_class]["valid"] += 1
                    else:
                        stats[intent_class]["dropped"] += 1

                class_pbar.set_postfix(valid=stats[intent_class]["valid"])

            except json.JSONDecodeError as e:
                class_pbar.set_postfix(error=f"JSON parse: {e}")
            except Exception as e:
                class_pbar.set_postfix(error=str(e)[:40])

            # Rate limiting
            time.sleep(1)
            pbar.update(1)

        class_pbar.close()

        # Deduplicate within class
        seen = set()
        deduped = []
        for s in class_samples:
            if s["utterance"] not in seen:
                seen.add(s["utterance"])
                deduped.append(s)

        all_samples.extend(deduped)
        tqdm.write(f"  ✓ {intent_class}: {len(deduped)} unique samples")

    pbar.close()

    # Shuffle
    random.shuffle(all_samples)

    # Write full dataset
    full_path = OUTPUT_DIR / "full_dataset.jsonl"
    with open(full_path, "w") as f:
        for s in all_samples:
            f.write(json.dumps(s) + "\n")

    # Train / val split (85/15 stratified)
    by_intent = {}
    for s in all_samples:
        by_intent.setdefault(s["intent"], []).append(s)

    train, val = [], []
    for intent, samples in by_intent.items():
        split_idx = int(len(samples) * 0.85)
        train.extend(samples[:split_idx])
        val.extend(samples[split_idx:])

    random.shuffle(train)
    random.shuffle(val)

    train_path = OUTPUT_DIR / "train.jsonl"
    val_path = OUTPUT_DIR / "val.jsonl"

    with open(train_path, "w") as f:
        for s in train:
            f.write(json.dumps(s) + "\n")

    with open(val_path, "w") as f:
        for s in val:
            f.write(json.dumps(s) + "\n")

    # Print summary
    print("\n" + "=" * 60)
    print("GENERATION COMPLETE")
    print("=" * 60)
    print(f"Total samples : {len(all_samples)}")
    print(f"Train split   : {len(train)} → {train_path}")
    print(f"Val split     : {len(val)} → {val_path}")
    print(f"Full dataset  : {full_path}")
    print("\nPer-class stats:")
    print(f"  {'Class':20s} {'Total':>6} {'Valid':>6} {'Fixed':>6} {'Dropped':>8}")
    print(f"  {'-'*20} {'-'*6} {'-'*6} {'-'*6} {'-'*8}")
    for cls, s in stats.items():
        print(f"  {cls:20s} {s['total']:6d} {s['valid']:6d} {s['fixed']:6d} {s['dropped']:8d}")

    return all_samples, stats


if __name__ == "__main__":
    run_generation()
