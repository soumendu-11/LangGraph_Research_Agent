# Synthetic Data Generation Prompt — Joint Intent + NER

## Config

- **Model:** Claude Sonnet 4.5 | `temperature: 0.9` | `max_tokens: 16000`
- **Batching:** 50 per batch x 6 batches x 7 classes = 2,100 samples
- **Parameters:** `{intent_class}`, `{batch_size}`, `{batch_number}`, `{total_batches}`

---

## System Prompt

```
You are a synthetic-data generator for an oil & gas geoscience platform. Output ONLY a valid JSON array. No markdown, no explanation. All utterances must be lowercase and under 40 words.
```

---

## User Prompt

```
Generate {batch_size} diverse lowercase utterances for intent: {intent_class}. Batch {batch_number}/{total_batches}.

INTENTS:
1. field_info — field dashboards, field queries, field discovery. e.g. "show summary for ghawar", "which fields produce most in oman?"
2. reservoir_info — reservoir dashboards, reservoir queries. e.g. "reservoir summary for rev-1", "compare reservoir performance"
3. basin_map — basin layers on map. e.g. "show main basins in norway", "display sub basins"
4. field_map — field/reservoir layers on map. e.g. "map fields in saudi arabia", "show reservoirs on map for uae"
5. ask_analyst — generic analytical questions, not field/reservoir specific. e.g. "analyze production trends", "what is the overall decline rate?"
6. map_viewport — general map/viewport operations. e.g. "zoom into persian gulf", "load layers for current view"
7. out_of_scope — unrelated to platform. e.g. "hello", "what's the weather?", "book a meeting"

ENTITIES (tag with character offsets):
FIELD_ID (fie-001), FIELD_NAME (ghawar, burgan, zakum), RESERVOIR_ID (res-101), RESERVOIR_NAME (rev-1, ghawar-north), COUNTRY_NAME (oman, uae, saudi arabia), BASIN_NAME (rub al khali, zagros), BASIN_TYPE (main/sub), LAYER_TYPE (field/reservoir), QUESTION (analytical span), BBOX (coordinates)

RULES:
- out_of_scope: always empty entities
- ask_analyst: entire utterance is often QUESTION entity
- ~15% utterances per class can be entity-free
- ~10% should have typos/abbreviations
- Mix short (3-6 words) and long (10-20 words)
- Vary vocabulary, formality, phrasing across samples

BATCH FOCUS:
1=short commands, 2=conversational, 3=questions, 4=typos/slang, 5=multi-entity, 6=edge cases

DOMAIN NAMES:
Countries: oman, uae, saudi arabia, qatar, kuwait, india, norway, brazil, nigeria, iraq, iran, malaysia, australia, angola, egypt, libya, uk, canada, mexico, indonesia, guyana, kazakhstan, azerbaijan
Fields: ghawar, burgan, zakum, dukhan, sabriyah, ratawi, manifa, safaniyah, abqaiq, shaybah, khurais, rumailah, majnoon, kirkuk, troll, ekofisk, johan sverdrup, gullfaks, buzios, lula, marlim
Reservoirs: rev-1, rev-2, ghawar-north, ghawar-south, main-reservoir, arab-d, khuff, mishrif, zubair, burgan-sand, shuaiba
Basins: rub al khali, zagros, ghadames, sirte, niger delta, santos, campos, north sea, barents, permian

OUTPUT FORMAT (JSON array):
[{{"utterance":"show field summary for ghawar in oman","intent":"{intent_class}","entities":[{{"entity":"FIELD_NAME","value":"ghawar","start":24,"end":30}},{{"entity":"COUNTRY_NAME","value":"oman","start":34,"end":38}}]}}]

utterance[start:end] MUST equal value. Double-check offsets. Output ONLY the JSON array.
```

---

## Post-Processing

1. Validate `utterance[start:end] == value` for all entities
2. Fix misaligned spans by searching `value` in `utterance`
3. Deduplicate utterances per class
4. Convert spans to BIO tags per token
5. 85/15 stratified train/val split
