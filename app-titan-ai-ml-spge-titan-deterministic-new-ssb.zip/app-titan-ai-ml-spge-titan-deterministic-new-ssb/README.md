# Geoscience Discovery Agent

Geoscience discovery query system with deterministic Q&A responses powered by LangGraph and AWS Bedrock.

## Quick Start

**1. Authenticate with AWS:**

**2. Run locally with Docker:**

```bash
./setup-docker.sh
```

Or manually:

```bash
cd geoscience_agent
docker compose up -d
```

- API: `http://localhost:3000`
- MLflow: `http://localhost:5000`
- Docs: `http://localhost:3000/docs`

## Features

- **Deterministic Responses**: Pre-written answers from JSON matched by embedding similarity
- **Guardrail Protection**: content filtering (optional, use `skip_guardrail: true`)
- **Streaming SSE**: Real-time response events for chat-like UX
- **State Management**: In-memory by default, DynamoDB optional (set `USE_DYNAMODB=true`)
- **Performance**: Classifier pre-initialized at startup, evaluation disabled by default

## Project Structure

```
geoscience_agent/
├── api.py                      # FastAPI endpoints
├── graph.py                    # LangGraph workflow
├── core/
│   ├── multiturn_processor.py  # Query matching & response handler
│   ├── query_classifier.py     # Embedding-based classifier
│   ├── haiku_guardrail.py      # Content filtering
│   └── haiku_evaluator.py      # G-Eval (disabled by default)
├── models/
│   └── bedrock_models.py       # AWS Bedrock model configs
└── data/
    └── cera_week_qna.json      # Q&A knowledge base
```

## Configuration

Environment variables (`.env.dev`):

```env
USE_DYNAMODB=false              # Enable DynamoDB state persistence
ENABLE_EVALUATION=false         # Enable G-Eval scoring
AWS_REGION=us-east-1
```


