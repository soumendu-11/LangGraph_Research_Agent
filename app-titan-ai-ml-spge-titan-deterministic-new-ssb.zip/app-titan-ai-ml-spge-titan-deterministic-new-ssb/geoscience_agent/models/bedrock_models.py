"""
AWS Bedrock Model Configurations
Haiku and Sonnet model settings for LangGraph workflow
"""

# Haiku Configuration - Fast, cost-effective model
HAIKU_CONFIG = {
    "model_id": "anthropic.claude-3-haiku-20240307-v1:0",
    "max_tokens": 4096,
    "temperature": 0.0,
    "top_k": 1,
    "top_p": 0.999,
    "anthropic_version": "bedrock-2023-05-31",
    "use_cases": [
        "query_generation",
        "response_evaluation",
        "g_eval_scoring"
    ],
    "cost_per_1k_tokens": {
        "input": 0.00025,
        "output": 0.00125
    }
}

# Sonnet 4.5 Configuration - High capability model
SONNET_45_CONFIG = {
    "model_id": "us.anthropic.claude-sonnet-4-20250514-v1:0",
    "max_tokens": 4096,
    "temperature": 0.0,
    "top_k": 1,
    "top_p": 0.999,
    "anthropic_version": "bedrock-2023-05-31",
    "use_cases": [
        "complex_reasoning",
        "detailed_analysis"
    ],
    "cost_per_1k_tokens": {
        "input": 0.003,
        "output": 0.015
    }
}

# Default model for workflow
DEFAULT_MODEL = HAIKU_CONFIG["model_id"]

__all__ = ['HAIKU_CONFIG', 'SONNET_45_CONFIG', 'DEFAULT_MODEL']