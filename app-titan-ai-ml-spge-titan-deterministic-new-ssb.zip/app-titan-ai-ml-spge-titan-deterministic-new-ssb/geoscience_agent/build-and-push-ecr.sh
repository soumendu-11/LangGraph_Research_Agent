#!/bin/bash

# Build and push Docker image to AWS ECR for ECS deployment

set -e

# Configuration
AWS_REGION="${AWS_REGION:-us-east-1}"
AWS_ACCOUNT_ID="${AWS_ACCOUNT_ID:-$(aws sts get-caller-identity --query Account --output text)}"
ECR_REPOSITORY="${ECR_REPOSITORY:-spge-titan-dev-geoscience-agent}"
IMAGE_TAG="${IMAGE_TAG:-latest}"

echo "=========================================="
echo "Build and Push to ECR"
echo "=========================================="
echo ""
echo "Configuration:"
echo "  AWS Region:     $AWS_REGION"
echo "  AWS Account:    $AWS_ACCOUNT_ID"
echo "  ECR Repository: $ECR_REPOSITORY"
echo "  Image Tag:      $IMAGE_TAG"
echo ""

# Login to ECR
echo "🔐 Logging in to ECR..."
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com


# Build image from project root
echo "🐳 Building Docker image..."
cd ..
docker build --platform linux/amd64 -t $ECR_REPOSITORY:$IMAGE_TAG -f geoscience_agent/Dockerfile .

# Tag image for ECR
ECR_IMAGE="$AWS_ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_REPOSITORY:$IMAGE_TAG"
echo "🏷️  Tagging image as: $ECR_IMAGE"
docker tag $ECR_REPOSITORY:$IMAGE_TAG $ECR_IMAGE

# Push to ECR
echo "🚀 Pushing image to ECR..."
docker push $ECR_IMAGE

echo ""
echo "=========================================="
echo "✅ Successfully pushed to ECR!"
echo "=========================================="
echo ""
echo "Image URI: $ECR_IMAGE"
echo ""
echo "To deploy to ECS, update your task definition with this image URI."
echo ""
