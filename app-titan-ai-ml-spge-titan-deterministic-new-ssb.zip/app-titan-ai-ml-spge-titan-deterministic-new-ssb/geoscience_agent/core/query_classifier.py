"""
Query Classification Module
Classifies incoming queries using cosine similarity against precomputed
Titan embeddings of questions and similar_questions from cera_week_qna.json.
Used for matching user queries to the closest Q&A entry.
"""

import json
import boto3
import numpy as np
from typing import Dict, List


class EmbeddingQueryClassifier:
    """
    Classifies queries by cosine similarity against precomputed embeddings.
    Loads questions from JSON on initialization, then matches user queries
    to the closest Q&A entry by embedding similarity.
    """
    
    def __init__(
        self,
        json_path: str = "geoscience_agent/data/cera_week_qna.json",
        embedding_model_id: str = "amazon.titan-embed-text-v2:0"
    ):
        """
        Initialize by loading Q&A data and precomputing embeddings.
        
        Args:
            json_path: Path to Q&A JSON file
            embedding_model_id: Bedrock embedding model ID
        """
        self.json_path = json_path
        self.embedding_model_id = embedding_model_id
        self.bedrock = boto3.client('bedrock-runtime', region_name='us-east-1', verify=False)
        
        # Load Q&A data from JSON
        print(f"Initializing EmbeddingQueryClassifier...")
        print(f"   Embedding model: {embedding_model_id}")
        print(f"   Loading Q&A data from: {json_path}")
        
        self.qa_data = self._load_json(json_path)
        
        print(f"   Entries loaded: {len(self.qa_data)}")
        
        # Build embedding index from all question + similar_questions
        # Each item: {"text": str, "embedding": list, "id": int, "entry": dict, "source": str}
        self.embedding_index = []
        
        total_texts = 0
        for entry in self.qa_data:
            entry_id = entry.get("id")
            
            # Main question
            main_q = entry.get("question", "")
            if main_q:
                total_texts += 1
            
            # Similar questions
            similar = entry.get("similar_questions", [])
            total_texts += len(similar)
        
        print(f"   Precomputing embeddings for {total_texts} texts (questions + similar_questions)...")
        
        for entry in self.qa_data:
            entry_id = entry.get("id")
            
            # Embed main question
            main_q = entry.get("question", "")
            if main_q:
                emb = self._get_embedding(main_q)
                self.embedding_index.append({
                    "text": main_q,
                    "embedding": emb,
                    "id": entry_id,
                    "entry": entry,
                    "source": "question"
                })
            
            # Embed each similar_question
            for sq in entry.get("similar_questions", []):
                emb = self._get_embedding(sq)
                self.embedding_index.append({
                    "text": sq,
                    "embedding": emb,
                    "id": entry_id,
                    "entry": entry,
                    "source": "similar_question"
                })
        
        print(f"   Embedding index built: {len(self.embedding_index)} vectors")
        print(f"   Initialization complete")
    
    def _load_json(self, filepath: str) -> List[Dict]:
        """Load Q&A data from JSON file"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            if isinstance(data, list):
                return data
            return []
        except Exception as e:
            print(f"   Error loading {filepath}: {str(e)}")
            return []
    
    def classify(self, request: str) -> Dict:
        """
        Classify a user query against the precomputed embedding index.
        First tries exact/fuzzy string matching, then falls back to embeddings.
        
        Args:
            request: User query string
        
        Returns:
            Dict with: matched_id, matched_question, matched_entry,
                       similarity_score, routing_path
        """
        # Try exact and case-insensitive matching first
        request_lower = request.lower().strip().rstrip('.').rstrip('?')
        
        for item in self.embedding_index:
            item_text_lower = item["text"].lower().strip().rstrip('.').rstrip('?')
            
            # Exact match (case-insensitive, ignoring trailing punctuation)
            if request_lower == item_text_lower:
                return {
                    "matched_id": item["id"],
                    "matched_question": item["text"],
                    "matched_entry": item["entry"],
                    "similarity_score": 1.0,
                    "routing_path": "multiturn_handler",
                    "match_type": "exact"
                }
            
            # Fuzzy match (contains or very similar)
            # Check if query contains the indexed text or vice versa
            if len(request_lower) > 20 and len(item_text_lower) > 20:
                if request_lower in item_text_lower or item_text_lower in request_lower:
                    return {
                        "matched_id": item["id"],
                        "matched_question": item["text"],
                        "matched_entry": item["entry"],
                        "similarity_score": 0.95,
                        "routing_path": "multiturn_handler",
                        "match_type": "fuzzy"
                    }
        
        # Fall back to embedding-based matching
        query_embedding = self._get_embedding(request)
        
        best_score = -1.0
        best_item = None
        
        for item in self.embedding_index:
            sim = self._cosine_similarity(query_embedding, item["embedding"])
            if sim > best_score:
                best_score = sim
                best_item = item
        
        if best_item is None:
            return {
                "matched_id": None,
                "matched_question": None,
                "matched_entry": None,
                "similarity_score": 0.0,
                "routing_path": "multiturn_handler"
            }
        
        return {
            "matched_id": best_item["id"],
            "matched_question": best_item["text"],
            "matched_entry": best_item["entry"],
            "similarity_score": best_score,
            "routing_path": "multiturn_handler"
        }
    
    def classify_from_json(self, request: str, qa_data: List[Dict] = None) -> Dict:
        """
        Classify query using the precomputed embedding index.
        The qa_data parameter is accepted for API compatibility but
        the precomputed index (built at init from JSON) is used.
        
        Args:
            request: User query string
            qa_data: Ignored (uses precomputed index from init)
        
        Returns:
            Dict with matched_id, matched_question, similarity_score,
            routing_path, matched_entry
        """
        print(f"\n   Classifying query against {len(self.embedding_index)} precomputed embeddings...")
        
        result = self.classify(request)
        
        print(f"   Best match: id={result['matched_id']}, score={result['similarity_score']:.4f}")
        print(f"   Matched question: {result['matched_question']}")
        print(f"   Routing to: {result['routing_path']}")
        
        return result
    
    def find_best_match_by_id(self, request: str, target_id: int) -> Dict:
        """
        Find the best matching entry among entries with a specific id.
        Uses the precomputed embedding index (filtered by target_id).
        
        Args:
            request: User query string
            target_id: Filter to entries with this id (1 or 2)
        
        Returns:
            Dict with matched_entry, matched_question, similarity_score
        """
        query_embedding = self._get_embedding(request)
        
        best_score = -1.0
        best_item = None
        
        for item in self.embedding_index:
            if item["id"] != target_id:
                continue
            sim = self._cosine_similarity(query_embedding, item["embedding"])
            if sim > best_score:
                best_score = sim
                best_item = item
        
        if best_item is None:
            return {
                "matched_entry": None,
                "matched_question": None,
                "similarity_score": 0.0
            }
        
        return {
            "matched_entry": best_item["entry"],
            "matched_question": best_item["text"],
            "similarity_score": best_score
        }
    
    def _get_embedding(self, text: str) -> List[float]:
        """
        Get embedding vector from Bedrock Titan
        
        Args:
            text: Input text to embed
            
        Returns:
            List of floats representing the embedding vector
        """
        try:
            body = json.dumps({"inputText": text})
            
            response = self.bedrock.invoke_model(
                modelId=self.embedding_model_id,
                body=body,
                contentType='application/json',
                accept='application/json'
            )
            
            response_body = json.loads(response['body'].read())
            return response_body['embedding']
            
        except Exception as e:
            print(f"   Error getting embedding: {str(e)}")
            return [0.0] * 1024
    
    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """
        Compute cosine similarity between two vectors
        
        Args:
            vec1: First vector
            vec2: Second vector
            
        Returns:
            Cosine similarity score (0-1)
        """
        vec1 = np.array(vec1)
        vec2 = np.array(vec2)
        
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return float(np.dot(vec1, vec2) / (norm1 * norm2))


__all__ = ['EmbeddingQueryClassifier']
