"""
Haiku G-Eval Module
Reference-based evaluation using AWS Bedrock Claude
"""

import json
import math
import boto3
from typing import Dict, Any
from datetime import datetime


class HaikuEvaluator:
    """
    Reference-based evaluation of answers against gold standard responses.
    Disabled by default (set ENABLE_EVALUATION=true to enable).
    """
    
    def __init__(self, model_id: str = "anthropic.claude-3-haiku-20240307-v1:0"):
        self.model_id = model_id
        self.bedrock = boto3.client('bedrock-runtime', region_name='us-east-1', verify=False)
        
        # Reference-based evaluation prompt (gold standard answer provided)
        self.eval_prompt_with_reference = """You are an expert evaluator for oil & gas discovery analysis systems.

GOLD STANDARD (REFERENCE) ANSWER:
{reference_answer}

USER QUESTION:
{question}

GENERATED ANSWER:
{generated_answer}

═══════════════════════════════════════════════════════════════════════════════
EVALUATION TASK (REFERENCE ANSWER PROVIDED)
═══════════════════════════════════════════════════════════════════════════════

Compare the GENERATED ANSWER against the GOLD STANDARD ANSWER and the QUESTION.
Use the gold standard as the authoritative source of truth.

1. COHERENCE (1-5):
   - Is the generated answer well-structured and logical?
   - Does it present information in a clear, organised manner?
   Score: 5 = perfectly structured, 1 = incoherent

2. CONSISTENCY (1-5):
   - Does the generated answer match the FACTS in the GOLD STANDARD?
   - Are field names, operators, reserves, counts identical?
   - Any factual contradiction with the reference answer?
   Score: 5 = fully consistent with reference, 1 = contradicts reference

3. FLUENCY (1-5):
   - Is the language clear and professional?
   - Are technical terms used correctly?
   Score: 5 = excellent writing, 1 = poor language

4. RELEVANCE (1-5):
   - Does the generated answer address the QUESTION as completely as the reference?
   - Does it cover the same key points the gold standard covers?
   Score: 5 = covers all reference points, 1 = misses the point

5. GROUNDEDNESS (1-5):
   - Is ALL information in the generated answer traceable to the GOLD STANDARD?
   - Does it avoid adding facts NOT present in the reference?
   - Are data values (reserves, operators, field names) exact matches?
   Score: 5 = fully grounded in reference, 1 = fabricated information

═══════════════════════════════════════════════════════════════════════════════
SCORING RULES
═══════════════════════════════════════════════════════════════════════════════

- CRITICAL RULE — IDENTICAL CONTENT: If the GENERATED ANSWER contains the same
  factual content as the GOLD STANDARD (same data values, same summaries, same
  key insights, same data table entries), then ALL five metrics MUST be scored
  5/5. Do NOT penalise for formatting, JSON structure, key ordering, or
  whitespace differences. Focus ONLY on whether the factual content matches.
- REFERENCE IS TRUTH: The gold standard answer is the single source of truth
- DATA ACCURACY: Field names, operators, reserves must match the reference exactly
- MISSING INFO: If the reference mentions data the generated answer omits, deduct relevance
- EXTRA INFO: If the generated answer adds facts NOT in the reference, deduct groundedness
- DEDUCT ONLY FOR FACTUAL DIFFERENCES: Only deduct points when there is a real
  factual deviation — missing data, wrong numbers, contradicted facts, or
  fabricated information. Never deduct for stylistic or structural preferences.

═══════════════════════════════════════════════════════════════════════════════
RESPONSE FORMAT
═══════════════════════════════════════════════════════════════════════════════

Return ONLY valid JSON (no markdown, no code blocks):
{{
  "coherence": <score 1-5>,
  "consistency": <score 1-5>,
  "fluency": <score 1-5>,
  "relevance": <score 1-5>,
  "groundedness": <score 1-5>,
  "overall_score": <average of 5 scores>,
  "reasoning": {{
    "coherence_notes": "Brief explanation",
    "consistency_notes": "Brief explanation",
    "fluency_notes": "Brief explanation",
    "relevance_notes": "Brief explanation",
    "groundedness_notes": "Brief explanation"
  }}
}}

EVALUATE NOW:
"""
    
    @staticmethod
    def _answers_are_equivalent(ref_str: str, gen_str: str) -> bool:
        """
        Robust structural comparison: parse both as JSON and compare.
        Handles float formatting, key ordering, and whitespace differences.
        """
        try:
            ref_obj = json.loads(ref_str.strip())
            gen_obj = json.loads(gen_str.strip())
            return HaikuEvaluator._deep_equal(ref_obj, gen_obj)
        except (json.JSONDecodeError, TypeError):
            return False
    
    def _perfect_scores_response(self) -> Dict:
        """Return perfect 5/5 scores for deterministic short-circuit."""
        return {
            "coherence": 5.0,
            "consistency": 5.0,
            "fluency": 5.0,
            "relevance": 5.0,
            "groundedness": 5.0,
            "overall_score": 5.0,
            "reasoning": {
                "coherence_notes": "Identical to gold standard",
                "consistency_notes": "Identical to gold standard",
                "fluency_notes": "Identical to gold standard",
                "relevance_notes": "Identical to gold standard",
                "groundedness_notes": "Identical to gold standard"
            },
            "evaluation_metadata": {
                "evaluator_model": self.model_id,
                "evaluation_type": "reference_based_identical",
                "timestamp": datetime.now().isoformat(),
                "skipped_llm_call": True
            }
        }
    
    @staticmethod
    def _deep_equal(a: Any, b: Any, rel_tol: float = 1e-9) -> bool:
        """Deep equality with float tolerance. Handles int/float cross-comparison."""
        if isinstance(a, dict):
            if not isinstance(b, dict) or set(a.keys()) != set(b.keys()):
                return False
            return all(HaikuEvaluator._deep_equal(a[k], b[k], rel_tol) for k in a)
        if isinstance(a, list):
            if not isinstance(b, list) or len(a) != len(b):
                return False
            return all(HaikuEvaluator._deep_equal(x, y, rel_tol) for x, y in zip(a, b))
        if isinstance(a, (int, float)) and isinstance(b, (int, float)):
            return math.isclose(float(a), float(b), rel_tol=rel_tol)
        return a == b
    
    def evaluate_turn_with_reference(
        self,
        reference_answer: str,
        question: str,
        generated_answer: Dict
    ) -> Dict:
        """
        Evaluate a generated answer against a gold standard reference answer.
        
        Args:
            reference_answer: The gold standard answer from the JSON (serialised str)
            question: User query
            generated_answer: System response dict with summary, key_insights, data_table
        
        Returns:
            Evaluation scores dict with 5 metrics + overall score
        """
        formatted_answer = json.dumps(generated_answer, indent=2)
        
        # Deterministic short-circuit: identical or structurally equivalent ⇒ perfect scores (no LLM call needed)
        if formatted_answer.strip() == reference_answer.strip():
            print("  Reference and generated answer are identical — returning 5/5 (deterministic)")
            return self._perfect_scores_response()
        if self._answers_are_equivalent(reference_answer, formatted_answer):
            print("  Reference and generated answer are structurally equivalent — returning 5/5 (deterministic)")
            return self._perfect_scores_response()
        
        eval_prompt = self.eval_prompt_with_reference.format(
            reference_answer=reference_answer,
            question=question,
            generated_answer=formatted_answer
        )
        
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 2048,
            "temperature": 0.0,
            "top_k": 1,
            "messages": [
                {
                    "role": "user",
                    "content": eval_prompt
                }
            ]
        })
        
        try:
            # Streaming Bedrock call for G-Eval
            response = self.bedrock.invoke_model_with_response_stream(
                modelId=self.model_id,
                body=body,
                contentType='application/json',
                accept='application/json'
            )
            
            eval_text = ""
            usage = {}
            for event in response.get("body", []):
                chunk = event.get("chunk")
                if chunk:
                    chunk_data = json.loads(chunk["bytes"])
                    if chunk_data.get("type") == "content_block_delta":
                        delta = chunk_data.get("delta", {})
                        if delta.get("type") == "text_delta":
                            eval_text += delta.get("text", "")
                    elif chunk_data.get("type") == "message_delta":
                        usage = chunk_data.get("usage", usage)
            
            eval_scores = self._parse_evaluation_response(eval_text)
            
            eval_scores["evaluation_metadata"] = {
                "evaluator_model": self.model_id,
                "evaluation_type": "reference_based",
                "timestamp": datetime.now().isoformat(),
                "usage": usage
            }
            
            return eval_scores
            
        except Exception as e:
            print(f"Error during reference-based evaluation: {str(e)}")
            return {
                "coherence": 3.0,
                "consistency": 3.0,
                "fluency": 3.0,
                "relevance": 3.0,
                "groundedness": 3.0,
                "overall_score": 3.0,
                "reasoning": {
                    "error": f"Reference-based evaluation failed: {str(e)}"
                },
                "evaluation_metadata": {
                    "evaluator_model": self.model_id,
                    "evaluation_type": "reference_based",
                    "timestamp": datetime.now().isoformat(),
                    "error": str(e)
                }
            }
    
    def _parse_evaluation_response(self, eval_text: str) -> Dict:
        """Parse evaluation response and extract scores"""
        try:
            # Try to extract JSON from response
            if "```json" in eval_text:
                json_start = eval_text.find("```json") + 7
                json_end = eval_text.find("```", json_start)
                json_text = eval_text[json_start:json_end].strip()
            elif "```" in eval_text:
                json_start = eval_text.find("```") + 3
                json_end = eval_text.find("```", json_start)
                json_text = eval_text[json_start:json_end].strip()
            else:
                json_text = eval_text.strip()
            
            scores = json.loads(json_text)
            
            # Ensure all required fields are present
            required_fields = ["coherence", "consistency", "fluency", "relevance", "groundedness"]
            for field in required_fields:
                if field not in scores:
                    scores[field] = 3.0
            
            # Calculate overall score if not present
            if "overall_score" not in scores:
                scores["overall_score"] = sum(
                    scores.get(f, 3.0) for f in required_fields
                ) / 5.0
            
            # Ensure reasoning is present
            if "reasoning" not in scores:
                scores["reasoning"] = {}
            
            return scores
            
        except Exception as e:
            print(f"Error parsing evaluation response: {str(e)}")
            print(f"Raw response: {eval_text}")
            return {
                "coherence": 3.0,
                "consistency": 3.0,
                "fluency": 3.0,
                "relevance": 3.0,
                "groundedness": 3.0,
                "overall_score": 3.0,
                "reasoning": {
                    "parse_error": str(e)
                }
            }


__all__ = ['HaikuEvaluator']