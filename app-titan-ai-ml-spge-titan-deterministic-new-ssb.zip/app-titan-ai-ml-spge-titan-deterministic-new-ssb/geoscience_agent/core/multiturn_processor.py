"""
Multi-turn Processor Module
Handles conversational queries with deterministic responses from JSON
and reference-based G-Eval evaluation (LLM call for verification only)

G-Eval is DISABLED by default for performance. Set ENABLE_EVALUATION=true to enable.
"""

import json
import os
from typing import Dict
from datetime import datetime
from geoscience_agent.core.query_classifier import EmbeddingQueryClassifier
from geoscience_agent.core.haiku_evaluator import HaikuEvaluator

# Global classifier instance (initialized once, reused across requests)
_global_classifier = None

def get_classifier():
    """Get or create the global classifier instance (singleton pattern)"""
    global _global_classifier
    if _global_classifier is None:
        print("Initializing global EmbeddingQueryClassifier (one-time setup)...")
        _global_classifier = EmbeddingQueryClassifier()
        print("Global classifier ready for reuse")
    return _global_classifier


class MultiTurnProcessor:
    """
    Process multi-turn conversational queries from JSON.
    - Deterministic: Return pre-written answer from JSON (no LLM generation)
    - G-Eval: Reference-based LLM call to evaluate the deterministic answer
    """
    
    def __init__(self, model_id: str = "anthropic.claude-3-haiku-20240307-v1:0"):
        self.model_id = model_id
        self.evaluator = HaikuEvaluator(model_id=model_id)
    
    def process_deterministic(self, state: Dict) -> Dict:
        """
        Process query using deterministic response from JSON + G-Eval evaluation.
        
        Steps:
        1. Find the best matching Q&A entry from JSON (cosine similarity)
        2. Return the pre-written answer (NO LLM call)
        3. Evaluate the answer using G-Eval (LLM call for verification)
        
        Args:
            state: Current workflow state
        
        Returns:
            Updated state with deterministic response and G-Eval scores
        """
        print(f"\n{'='*60}")
        print("MULTI-TURN PROCESSOR (Deterministic + G-Eval)")
        print(f"{'='*60}")
        
        request = state.get("current_request", "")
        qa_data = state.get("qa_data", [])
        
        print(f"Request: {request}")
        print(f"Turn number: {state.get('turn_number', 1)}")
        print(f"Available Q&A entries: {len(qa_data)}")
        
        if not qa_data:
            print("ERROR: No Q&A entries available")
            return {
                **state,
                "status": "error",
                "error": "No Q&A entries available for multiturn handler"
            }
        
        # Find the best matching entry using cosine similarity
        classifier = get_classifier()  # Reuse global instance
        match_result = classifier.classify(request)
        best_entry = match_result.get("matched_entry")
        similarity_score = match_result.get("similarity_score", 0.0)
        
        # Define similarity threshold for out-of-scope detection
        SIMILARITY_THRESHOLD = 0.2  # Adjust as needed (0.0-1.0)
        
        if best_entry:
            print(f"Matched entry: {match_result['matched_question']} (score: {similarity_score:.4f})")
            
            # Check if similarity is too low (out of scope)
            if similarity_score < SIMILARITY_THRESHOLD:
                print(f"Similarity score {similarity_score:.4f} below threshold {SIMILARITY_THRESHOLD} — returning low-confidence response")
                
                # Return out-of-scope response
                out_of_scope_response = {
                    "summary": "I do not have the information needed to help with that request. Is there something else within my area of expertise I can assist you with?",
                    "key_insights": [],
                    "data_table": [],
                    "map_update": []
                }
                
                return {
                    **state,
                    "current_response": out_of_scope_response,
                    "response_summary": out_of_scope_response["summary"],
                    "key_insights": [],
                    "data_table": [],
                    "map_update": [],
                    "evaluation_scores": {},
                    "response_metadata": {
                        "is_deterministic": True,
                        "matched_question": match_result.get("matched_question"),
                        "similarity_score": similarity_score,
                        "handler": "multiturn_handler",
                        "below_threshold": True
                    },
                    "status": "below_similarity_threshold",
                    "timestamp": datetime.now().isoformat()
                }
        else:
            # Fallback to first entry if classifier fails
            best_entry = qa_data[0]
            similarity_score = 0.0
            print(f"Classifier returned no match, using first entry: {best_entry['question']}")
        
        # Get the pre-written answer
        answer = best_entry.get("answer", {})
        
        # Normalize answer format
        if isinstance(answer, str):
            response = {
                "summary": answer,
                "key_insights": [],
                "data_table": [],
                "scatter_plot": {},
                "map_update": [],
                "columns": [],
                "dashboard": {},
                "suggested_followup_prompts": [],
                "suggestions": []
            }
        elif isinstance(answer, dict):
            response = {
                "summary": answer.get("summary", ""),
                "key_insights": answer.get("key_insights", []),
                "data_table": answer.get("data_table", []),
                "scatter_plot": answer.get("scatter_plot", {}),
                "map_update": answer.get("map_update", []),
                "columns": answer.get("columns", []),
                "dashboard": answer.get("dashboard", {}),
                "suggested_followup_prompts": answer.get("suggested_followup_prompts", []),
                "suggestions": answer.get("suggestions", [])
            }
        else:
            response = {
                "summary": str(answer),
                "key_insights": [],
                "data_table": [],
                "scatter_plot": {},
                "map_update": [],
                "columns": [],
                "dashboard": {},
                "suggested_followup_prompts": [],
                "suggestions": []
            }
        
        print(f"\nDETERMINISTIC RESPONSE")
        print(f"   Matched Question: {best_entry['question']}")
        print(f"   Summary: {response['summary'][:100]}...")
        print(f"   Data Table entries: {len(response.get('data_table', []))}")
        if response.get("scatter_plot"):
            sp = response["scatter_plot"]
            print(f"   Scatter Plot: {len(sp.get('data', []))} records")
        if response.get("columns"):
            print(f"   Columns: {len(response['columns'])}")
        if response.get("dashboard"):
            dash = response["dashboard"]
            print(f"   Dashboard: {len(dash.get('columns', []))} columns, {len(dash.get('data', []))} records")
        
        # Build gold standard reference in normalized format
        # for structural comparison by the evaluator
        gold_response = {
            "summary": response["summary"],
            "key_insights": response["key_insights"],
            "data_table": response["data_table"],
            "scatter_plot": response.get("scatter_plot", {}),
            "map_update": response["map_update"],
            "columns": response["columns"],
            "dashboard": response["dashboard"],
            "suggestions": response.get("suggestions", [])
        }
        gold_answer = json.dumps(gold_response, indent=2)
        
        # G-Eval evaluation - DISABLED by default for performance
        # Set ENABLE_EVALUATION=true environment variable to enable
        enable_evaluation = os.getenv("ENABLE_EVALUATION", "false").lower() == "true"
        
        if enable_evaluation:
            # G-Eval: Evaluate the deterministic answer against gold standard (LLM call)
            print(f"\nEvaluating with G-Eval (reference-based, model: {self.model_id})...")
            evaluation = self.evaluator.evaluate_turn_with_reference(
                reference_answer=gold_answer,
                question=request,
                generated_answer=response
            )
            
            print(f"G-Eval completed (reference-based):")
            print(f"  Coherence: {evaluation.get('coherence', 0):.2f}/5.0")
            print(f"  Consistency: {evaluation.get('consistency', 0):.2f}/5.0")
            print(f"  Fluency: {evaluation.get('fluency', 0):.2f}/5.0")
            print(f"  Relevance: {evaluation.get('relevance', 0):.2f}/5.0")
            print(f"  Groundedness: {evaluation.get('groundedness', 0):.2f}/5.0")
            print(f"  Overall Score: {evaluation.get('overall_score', 0):.2f}/5.0")
        else:
            # Evaluation disabled - return empty scores for performance
            print(f"\nG-Eval DISABLED (set ENABLE_EVALUATION=true to enable)")
            evaluation = {
                "coherence": 0.0,
                "consistency": 0.0,
                "fluency": 0.0,
                "relevance": 0.0,
                "groundedness": 0.0,
                "overall_score": 0.0,
                "disabled": True
            }
        
        return {
            **state,
            "current_response": response,
            "response_summary": response.get("summary", ""),
            "key_insights": response.get("key_insights", []),
            "data_table": response.get("data_table", []),
            "map_update": response.get("map_update", []),
            "columns": response.get("columns", []),
            "dashboard": response.get("dashboard", {}),
            "evaluation_scores": evaluation,
            "response_metadata": {
                "is_deterministic": True,
                "matched_question": best_entry["question"],
                "handler": "multiturn_handler",
                "evaluator_model": self.model_id
            },
            "status": "multiturn_processed_deterministic",
            "timestamp": datetime.now().isoformat()
        }


__all__ = ['MultiTurnProcessor']
