"""
LLM-based Guardrail
Uses Claude Sonnet 4.5 to detect and block inappropriate content.
Loads prompt from prompts/guardrail_prompt.txt.
"""

import os
import json
import boto3
from typing import Dict, Optional

from geoscience_agent.models.bedrock_models import SONNET_45_CONFIG


class HaikuGuardrail:
    """
    LLM-based guardrail using Claude Sonnet 4.5.
    Analyzes user questions before processing.
    Prompt loaded from prompts/ folder.
    """
    
    def __init__(self, model_id: str = None):
        self.model_id = model_id or SONNET_45_CONFIG["model_id"]
        self.bedrock = boto3.client('bedrock-runtime', region_name='us-east-1', verify=False)
        self.guardrail_prompt = self._load_prompt()

    @staticmethod
    def _load_prompt() -> str:
        """Load guardrail prompt from prompts/ folder."""
        prompt_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "prompts", "guardrail_prompt.txt"
        )
        with open(prompt_path, 'r', encoding='utf-8') as f:
            return f.read()
    
    def check_question(self, question: str) -> Dict:
        """
        Check if a question is allowed
        
        Args:
            question: User's question to check
        
        Returns:
            Dict with is_allowed, category, reason, suggested_response
        """
        print(f"\n{'='*60}")
        print("🛡️  GUARDRAIL CHECK (Sonnet 4.5)")
        print(f"{'='*60}")
        print(f"Question: {question}")
        
        # Format prompt
        formatted_prompt = self.guardrail_prompt.format(question=question)
        
        # Prepare request
        body = json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 512,
            "temperature": 0.0,
            "top_k": 1,
            "messages": [
                {
                    "role": "user",
                    "content": formatted_prompt
                }
            ]
        })
        
        try:
            # Call Sonnet 4.5 for guardrail check (streaming)
            response = self.bedrock.invoke_model_with_response_stream(
                modelId=self.model_id,
                body=body,
                contentType='application/json',
                accept='application/json'
            )
            
            result_text = ""
            for event in response.get("body", []):
                chunk = event.get("chunk")
                if chunk:
                    chunk_data = json.loads(chunk["bytes"])
                    if chunk_data.get("type") == "content_block_delta":
                        delta = chunk_data.get("delta", {})
                        if delta.get("type") == "text_delta":
                            result_text += delta.get("text", "")
            
            # Parse result
            result = self._parse_guardrail_response(result_text)
            
            if result["is_allowed"]:
                print(f"✅ ALLOWED - Category: {result['category']}")
            else:
                print(f"🚫 BLOCKED - Category: {result['category']}")
                print(f"   Reason: {result['reason']}")
            
            return result
            
        except Exception as e:
            print(f"⚠️  Guardrail check failed: {str(e)}")
            # Fail open (allow) if guardrail has an error
            return {
                "is_allowed": True,
                "category": "error",
                "reason": f"Guardrail check failed: {str(e)}",
                "suggested_response": None
            }
    
    def _parse_guardrail_response(self, response_text: str) -> Dict:
        try:
            # Extract JSON
            if "```json" in response_text:
                json_start = response_text.find("```json") + 7
                json_end = response_text.find("```", json_start)
                json_text = response_text[json_start:json_end].strip()
            elif "```" in response_text:
                json_start = response_text.find("```") + 3
                json_end = response_text.find("```", json_start)
                json_text = response_text[json_start:json_end].strip()
            else:
                json_text = response_text.strip()
            
            result = json.loads(json_text)
            
            # Ensure required fields
            return {
                "is_allowed": result.get("is_allowed", True),
                "category": result.get("category", "unknown"),
                "reason": result.get("reason", "No reason provided"),
                "suggested_response": result.get("suggested_response", 
                    "I apologize, but I can only answer questions about oil & gas discoveries and technical petroleum engineering topics.")
            }
            
        except Exception as e:
            print(f"Warning: Failed to parse guardrail response: {str(e)}")
            # Fail open on parse error
            return {
                "is_allowed": True,
                "category": "parse_error",
                "reason": f"Parse error: {str(e)}",
                "suggested_response": None
            }


__all__ = ['HaikuGuardrail']