# dynamodb_checkpointer.py
import json
import os
import gzip
import base64
import time
from typing import Optional, Dict, Any, Tuple
from datetime import datetime

import boto3
from botocore.exceptions import ClientError
from langgraph.checkpoint.base import BaseCheckpointSaver, Checkpoint, CheckpointMetadata, CheckpointTuple


class DynamoDBSaver(BaseCheckpointSaver):
    """
    DynamoDB-backed checkpoint saver for conversation state persistence.
    Disabled by default (set USE_DYNAMODB=true to enable).
    """
    
    def __init__(self, table_name: Optional[str] = None):
        """
        Initialize DynamoDB checkpointer.
        
        Args:
            table_name: Name of the DynamoDB table. If None, uses DYNAMODB_TABLE env var.
        """
        self.table_name = table_name or os.getenv("DYNAMODB_TABLE", "spge-titan-state-management")
        
        # Initialize DynamoDB client
        dynamodb = boto3.resource('dynamodb', region_name=os.getenv("AWS_REGION", "us-east-1"))
        self.table = dynamodb.Table(self.table_name)
        
        print(f"✓ DynamoDB checkpointer initialized with table: {self.table_name}")
    
    def put(self, config: Dict[str, Any], checkpoint: Checkpoint, metadata: Dict[str, Any], new_versions: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Save checkpoint to DynamoDB with compression.
        
        Args:
            config: Configuration containing thread_id
            checkpoint: The checkpoint data to save
            metadata: Additional metadata
            new_versions: Optional new version information (for compatibility)
            
        Returns:
            Dictionary with the saved configuration
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            raise ValueError("thread_id is required in config")
        
        try:
            # Serialize and compress checkpoint data
            checkpoint_json = json.dumps(checkpoint)
            compressed = gzip.compress(checkpoint_json.encode('utf-8'))
            checkpoint_b64 = base64.b64encode(compressed).decode('utf-8')
            
            # Compress metadata too
            metadata_json = json.dumps(metadata) if metadata else "{}"
            compressed_meta = gzip.compress(metadata_json.encode('utf-8'))
            metadata_b64 = base64.b64encode(compressed_meta).decode('utf-8')
            
            item = {
                "thread_id": thread_id,
                "checkpoint_id": checkpoint.get("id", datetime.utcnow().isoformat()),
                "checkpoint_data": checkpoint_b64,  # Compressed
                "metadata": metadata_b64,  # Compressed
                "compressed": True,  # Flag to indicate compression
                "created_at": datetime.utcnow().isoformat(),
                "ttl": int(datetime.utcnow().timestamp()) + (30 * 24 * 60 * 60)  # 30 days TTL
            }
            # Retry with exponential backoff for throughput exceptions
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    self.table.put_item(Item=item)
                    print(f"✓ Checkpoint saved for thread: {thread_id} (compressed size: {len(checkpoint_b64)} bytes)")
                    return config
                except ClientError as e:
                    error_code = e.response['Error']['Code']
                    if error_code == 'ProvisionedThroughputExceededException' and attempt < max_retries - 1:
                        wait_time = (2 ** attempt) * 0.5  # 0.5s, 1s, 2s
                        print(f"⚠️  DynamoDB throughput exceeded, retrying in {wait_time}s (attempt {attempt + 1}/{max_retries})")
                        time.sleep(wait_time)
                    else:
                        raise
            return config
            
        except ClientError as e:
            print(f"✗ Error saving checkpoint: {e.response['Error']['Message']}")
            raise
    
    def get(self, config: Dict[str, Any]) -> Optional[Checkpoint]:
        """
        Retrieve checkpoint from DynamoDB with decompression.
        
        Args:
            config: Configuration containing thread_id
            
        Returns:
            The checkpoint data or None if not found
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return None
        
        try:
            response = self.table.get_item(Key={"thread_id": thread_id})
            
            if "Item" in response:
                item = response["Item"]
                
                # Check if data is compressed
                if item.get("compressed", False):
                    # Decompress checkpoint data
                    checkpoint_b64 = item["checkpoint_data"]
                    compressed = base64.b64decode(checkpoint_b64)
                    checkpoint_json = gzip.decompress(compressed).decode('utf-8')
                    checkpoint_data = json.loads(checkpoint_json)
                else:
                    # Legacy uncompressed data
                    checkpoint_data = json.loads(item["checkpoint_data"])
                
                print(f"✓ Checkpoint loaded for thread: {thread_id}")
                return checkpoint_data
            else:
                print(f"○ No checkpoint found for thread: {thread_id}")
                return None
                
        except ClientError as e:
            print(f"✗ Error retrieving checkpoint: {e.response['Error']['Message']}")
            return None
    
    def get_tuple(self, config: Dict[str, Any]) -> Optional[Tuple[Checkpoint, CheckpointMetadata]]:
        """
        Retrieve checkpoint tuple (checkpoint, metadata) from DynamoDB.
        Required by BaseCheckpointSaver interface.
        
        Args:
            config: Configuration containing thread_id
            
        Returns:
            Tuple of (checkpoint, metadata) or None if not found
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return None
        
        try:
            response = self.table.get_item(Key={"thread_id": thread_id})
            
            if "Item" in response:
                item = response["Item"]
                
                # Check if data is compressed
                if item.get("compressed", False):
                    # Decompress checkpoint data
                    checkpoint_b64 = item["checkpoint_data"]
                    compressed = base64.b64decode(checkpoint_b64)
                    checkpoint_json = gzip.decompress(compressed).decode('utf-8')
                    checkpoint_data = json.loads(checkpoint_json)
                    
                    # Decompress metadata
                    metadata_b64 = item.get("metadata", "")
                    if metadata_b64:
                        compressed_meta = base64.b64decode(metadata_b64)
                        metadata_json = gzip.decompress(compressed_meta).decode('utf-8')
                        metadata_data = json.loads(metadata_json)
                    else:
                        metadata_data = {}
                else:
                    # Legacy uncompressed data
                    checkpoint_data = json.loads(item["checkpoint_data"])
                    metadata_data = json.loads(item.get("metadata", "{}"))
                
                # Create CheckpointMetadata object
                metadata = CheckpointMetadata(
                    source="input",
                    step=metadata_data.get("step", -1),
                    writes=metadata_data.get("writes", {}),
                    parents=metadata_data.get("parents", {})
                )
                
                print(f"✓ Checkpoint tuple loaded for thread: {thread_id}")
                return CheckpointTuple(
                    config=config,
                    checkpoint=checkpoint_data,
                    metadata=metadata,
                    parent_config=None,
                    pending_writes=[]
                )
            else:
                print(f"○ No checkpoint found for thread: {thread_id}")
                return None
                
        except ClientError as e:
            print(f"✗ Error retrieving checkpoint tuple: {e.response['Error']['Message']}")
            return None
    
    def list(self, config: Dict[str, Any]) -> list:
        """
        List all checkpoints for a thread.
        
        Args:
            config: Configuration containing thread_id
            
        Returns:
            List of checkpoints
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            return []
        
        try:
            response = self.table.query(
                KeyConditionExpression="thread_id = :tid",
                ExpressionAttributeValues={":tid": thread_id}
            )
            return response.get("Items", [])
            
        except ClientError as e:
            print(f"✗ Error listing checkpoints: {e.response['Error']['Message']}")
            return []
    
    def put_writes(self, config: Dict[str, Any], writes: list, task_id: str) -> None:
        """
        Store intermediate writes for a task.
        Required by LangGraph's checkpointer interface for streaming support.
        
        Args:
            config: Configuration containing thread_id
            writes: List of writes to store (may contain deque or other non-JSON types)
            task_id: Unique identifier for the task
        """
        thread_id = config.get("configurable", {}).get("thread_id")
        if not thread_id:
            raise ValueError("thread_id is required in config")
        
        try:
            # Convert writes to JSON-serializable format
            # Handle deque and other non-serializable types
            def make_serializable(obj):
                if isinstance(obj, (list, tuple)):
                    return [make_serializable(item) for item in obj]
                elif isinstance(obj, dict):
                    return {k: make_serializable(v) for k, v in obj.items()}
                elif hasattr(obj, '__iter__') and not isinstance(obj, (str, bytes)):
                    # Handle deque and other iterables
                    return list(obj)
                else:
                    return obj
            
            serializable_writes = make_serializable(writes)
            
            # Store writes as a separate item with task_id as sort key
            item = {
                "thread_id": thread_id,
                "task_id": task_id,
                "writes": json.dumps(serializable_writes),
                "created_at": datetime.utcnow().isoformat(),
                "ttl": int(datetime.utcnow().timestamp()) + (7 * 24 * 60 * 60)  # 7 days TTL
            }
            
            # Retry with exponential backoff for throughput exceptions
            max_retries = 3
            for attempt in range(max_retries):
                try:
                    self.table.put_item(Item=item)
                    print(f"✓ Writes saved for thread: {thread_id}, task: {task_id}")
                    return
                except ClientError as e:
                    error_code = e.response['Error']['Code']
                    if error_code == 'ProvisionedThroughputExceededException' and attempt < max_retries - 1:
                        wait_time = (2 ** attempt) * 0.5
                        print(f"⚠️  DynamoDB throughput exceeded (writes), retrying in {wait_time}s")
                        time.sleep(wait_time)
                    else:
                        # Don't raise for writes - they're optional
                        print(f"✗ Error saving writes: {e.response['Error']['Message']}")
                        return
            
        except (TypeError, ValueError) as e:
            print(f"✗ Error saving writes: {str(e)}")
            # Don't raise - writes are optional for checkpoint recovery
            pass