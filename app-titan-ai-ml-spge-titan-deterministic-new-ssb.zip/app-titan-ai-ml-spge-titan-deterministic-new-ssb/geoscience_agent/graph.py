"""
LangGraph Workflow Builder - Integrated from cera_week/v3
Main module for building the conditional discovery query workflow with guardrail
"""

import json
import os
import time
from typing import TypedDict, Optional, List, Dict, Generator
from datetime import datetime
from langgraph.graph import StateGraph, END, START
import mlflow

from geoscience_agent.dynamodb_checkpointer import DynamoDBSaver
from geoscience_agent.models.bedrock_models import HAIKU_CONFIG
from geoscience_agent.core.multiturn_processor import MultiTurnProcessor
from geoscience_agent.core.haiku_guardrail import HaikuGuardrail

# Global DynamoDB checkpointer instance (initialized once)
_dynamodb_checkpointer = None

def get_dynamodb_checkpointer():
    """Get or create the global DynamoDB checkpointer instance"""
    global _dynamodb_checkpointer
    
    # Only initialize if USE_DYNAMODB env var is set (for ECS Fargate deployment)
    use_dynamodb_env = os.getenv("USE_DYNAMODB", "false")
    print(f"DEBUG: get_dynamodb_checkpointer - USE_DYNAMODB env var = '{use_dynamodb_env}'")
    
    if use_dynamodb_env.lower() == "true":
        if _dynamodb_checkpointer is None:
            print("Initializing DynamoDB checkpointer for state management...")
            table_name = os.getenv("DYNAMODB_TABLE_NAME", "spge-titan-state-management")
            print(f"DEBUG: DynamoDB table name = '{table_name}'")
            _dynamodb_checkpointer = DynamoDBSaver(table_name=table_name)
        return _dynamodb_checkpointer
    else:
        print(f"DEBUG: USE_DYNAMODB is not 'true', returning None")
        return None


# ==============================================================================
# STATE DEFINITION
# ==============================================================================

class DiscoveryState(TypedDict):
    """State schema for the discovery query workflow"""
    # Session Management
    session_id: Optional[str]
    
    # Discovery Data
    discoveries_file_path: Optional[str]
    discoveries_data: Optional[List[Dict]]
    context: Optional[str]              # Discovery records JSON
    full_context: Optional[str]         # Entire JSON file for G-Eval
    
    # JSON Q&A Data (loaded by load_json_tool node)
    qa_data: Optional[List[Dict]]       # All Q&A entries from JSON
    
    # Current Query
    current_request: str
    metadata: Optional[Dict]
    current_response: Optional[Dict]
    turn_number: int
    
    # Query Classification
    query_type: Optional[str]
    routing_path: Optional[str]
    matched_json_entry: Optional[Dict]  # The matched Q&A entry from JSON
    classification_confidence: Optional[float]
    classification_scores: Optional[Dict]
    
    # Guardrail Check
    guardrail_check: Optional[Dict]     # Guardrail analysis result
    is_blocked: bool                    # Whether request is blocked
    
    # Conversation History
    conversation_history: List[Dict]
    
    # Model Configuration
    model_id: str
    
    # Response Components
    response_summary: Optional[str]
    key_insights: Optional[List[Dict]]
    data_table: Optional[List[Dict]]
    scatter_plot: Optional[Dict]
    columns: Optional[List[str]]
    dashboard: Optional[Dict]
    suggestions: Optional[List[str]]
    
    # Evaluation Results (for multi-turn queries)
    evaluation_scores: Optional[Dict]
    
    # Metadata
    response_metadata: Optional[dict]
    
    # Status Tracking
    status: str
    error: Optional[str]
    timestamp: Optional[str]


# ==============================================================================
# NODE FUNCTIONS
# ==============================================================================

def initialize_session_node(state: DiscoveryState) -> DiscoveryState:
    """Initialize session - conversation history maintained in DynamoDB checkpoint"""
    print(f"\n{'='*60}")
    print("INITIALIZE SESSION NODE")
    print(f"{'='*60}")
    
    node_start_time = time.time()
    
    session_id = state.get("session_id")
    conversation_history = state.get("conversation_history", [])
    
    # Generate session_id if not provided
    if not session_id:
        import uuid
        session_id = str(uuid.uuid4())
        is_new_session = True
        print(f"New session created: {session_id}")
    else:
        is_new_session = len(conversation_history) == 0
        print(f"Existing session: {session_id} ({len(conversation_history)} previous turns)")
    
    # MLflow logging
    if mlflow.active_run():
        node_time = (time.time() - node_start_time) * 1000
        mlflow.log_metric("node_initialize_session_time_ms", node_time)
        mlflow.log_param("is_new_session", is_new_session)
        mlflow.log_param("previous_turns", len(conversation_history))
    
    return {
        **state,
        "session_id": session_id,
        "conversation_history": conversation_history,
        "status": "session_initialized",
        "error": None
    }


def guardrail_check_node(state: DiscoveryState) -> DiscoveryState:
    """Check if the question should be blocked by guardrail (LLM call)"""
    print(f"\n{'='*60}")
    print("GUARDRAIL CHECK NODE")
    print(f"{'='*60}")
    
    node_start_time = time.time()
    
    # Check if guardrail should be skipped
    metadata = state.get("metadata", {})
    skip_guardrail = metadata.get("skip_guardrail", False)
    
    if skip_guardrail:
        print("Guardrail check SKIPPED (skip_guardrail=true)")
        
        # MLflow logging
        if mlflow.active_run():
            node_time = (time.time() - node_start_time) * 1000
            mlflow.log_metric("node_guardrail_check_time_ms", node_time)
            mlflow.log_param("guardrail_skipped", True)
        
        return {
            **state,
            "guardrail_check": {
                "is_allowed": True,
                "category": "skipped",
                "reason": "Guardrail check skipped for performance"
            },
            "is_blocked": False,
            "status": "guardrail_skipped"
        }
    
    request = state.get("current_request", "")
    
    guardrail = HaikuGuardrail()
    check_result = guardrail.check_question(request)
    
    is_blocked = not check_result["is_allowed"]
    
    # MLflow logging
    if mlflow.active_run():
        node_time = (time.time() - node_start_time) * 1000
        mlflow.log_metric("node_guardrail_check_time_ms", node_time)
        mlflow.log_param("guardrail_is_allowed", check_result["is_allowed"])
        mlflow.log_param("guardrail_category", check_result.get("category", "N/A"))
        if is_blocked:
            mlflow.log_param("guardrail_block_reason", check_result.get("reason", "N/A"))
    
    if is_blocked:
        # Create blocked response
        blocked_response = {
            "summary": "I'm sorry, but I'm unable to help with that request. Is there something else I can assist you with?",
            "key_insights": [],
            "data_table": []
        }
        
        print(f"\nRequest BLOCKED by guardrail")
        print(f"   Category: {check_result['category']}")
        print(f"   Reason: {check_result['reason']}")
        
        return {
            **state,
            "guardrail_check": check_result,
            "is_blocked": True,
            "current_response": blocked_response,
            "response_summary": blocked_response["summary"],
            "key_insights": blocked_response["key_insights"],
            "data_table": blocked_response["data_table"],
            "status": "blocked_by_guardrail",
            "timestamp": datetime.now().isoformat()
        }
    else:
        print(f"\nRequest ALLOWED by guardrail")
        return {
            **state,
            "guardrail_check": check_result,
            "is_blocked": False,
            "status": "guardrail_passed"
        }


def load_json_tool_node(state: DiscoveryState) -> DiscoveryState:
    """
    Load Q&A entries from JSON file into state.
    """
    print(f"\n{'='*60}")
    print("LOAD JSON TOOL NODE")
    print(f"{'='*60}")
    
    node_start_time = time.time()
    
    file_path = state.get("discoveries_file_path", "geoscience_agent/data/cera_week_qna.json")
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            qa_data = json.load(f)
        
        # Build discovery context for G-Eval
        if isinstance(qa_data, list):
            discoveries = qa_data
            full_json = json.dumps(qa_data, indent=2)
        elif isinstance(qa_data, dict) and "discoveries" in qa_data:
            discoveries = qa_data.get("discoveries", [])
            full_json = json.dumps(qa_data, indent=2)
        else:
            discoveries = [qa_data]
            full_json = json.dumps(qa_data, indent=2)
        
        context = json.dumps(discoveries, indent=2)
        
        print(f"JSON loaded from {file_path}")
        print(f"  Total entries: {len(qa_data)}")
        print(f"  Discovery context: {len(context)} characters")
        
        for i, q in enumerate(qa_data):
            print(f"    Turn {i+1}: {q['question']}")
        
        # MLflow logging
        if mlflow.active_run():
            node_time = (time.time() - node_start_time) * 1000
            mlflow.log_metric("node_load_json_time_ms", node_time)
            mlflow.log_param("json_file_path", file_path)
            mlflow.log_param("num_qa_entries", len(qa_data))
            mlflow.log_metric("context_size_chars", len(context))
        
        return {
            **state,
            "qa_data": qa_data,
            "discoveries_data": discoveries,
            "context": context,
            "full_context": full_json,
            "status": "json_loaded"
        }
        
    except Exception as e:
        error_msg = f"Failed to load JSON: {str(e)}"
        print(f"ERROR: {error_msg}")
        
        # MLflow logging
        if mlflow.active_run():
            node_time = (time.time() - node_start_time) * 1000
            mlflow.log_metric("node_load_json_time_ms", node_time)
            mlflow.log_param("json_load_error", error_msg)
        
        return {
            **state,
            "qa_data": [],
            "discoveries_data": [],
            "context": "",
            "full_context": "",
            "status": "error",
            "error": error_msg
        }


def multiturn_handler_node(state: DiscoveryState) -> DiscoveryState:
    """Handle multi-turn conversational queries - deterministic response from JSON + G-Eval"""
    print(f"\n{'='*60}")
    print("MULTI-TURN HANDLER NODE (Deterministic + G-Eval)")
    print(f"{'='*60}")
    
    node_start_time = time.time()
    
    model_id = state.get("model_id", HAIKU_CONFIG["model_id"])
    processor = MultiTurnProcessor(model_id=model_id)
    
    result = processor.process_deterministic(state)
    
    # MLflow logging
    if mlflow.active_run():
        node_time = (time.time() - node_start_time) * 1000
        mlflow.log_metric("node_multiturn_handler_time_ms", node_time)
        
        # Log response metadata
        response_metadata = result.get("response_metadata", {})
        if response_metadata.get("matched_question"):
            mlflow.log_param("matched_question", response_metadata["matched_question"])
        
        # Log evaluation scores
        evaluation = result.get("evaluation_scores", {})
        if evaluation:
            mlflow.log_metric("eval_coherence", evaluation.get("coherence", 0))
            mlflow.log_metric("eval_consistency", evaluation.get("consistency", 0))
            mlflow.log_metric("eval_fluency", evaluation.get("fluency", 0))
            mlflow.log_metric("eval_relevance", evaluation.get("relevance", 0))
            mlflow.log_metric("eval_groundedness", evaluation.get("groundedness", 0))
            mlflow.log_metric("eval_overall_score", evaluation.get("overall_score", 0))
        
        # Log response metrics
        current_response = result.get("current_response", {})
        if current_response:
            data_table = current_response.get("data_table", [])
            map_update = current_response.get("map_update", [])
            mlflow.log_metric("num_data_table_rows", len(data_table))
            mlflow.log_metric("num_map_update_assets", len(map_update))
            mlflow.log_param("has_data_table", len(data_table) > 0)
            mlflow.log_param("has_map_update", len(map_update) > 0)
    
    return result


def save_session_node(state: DiscoveryState) -> DiscoveryState:
    """Save conversation turn to state (DynamoDB checkpoint persists automatically)"""
    print(f"\n{'='*60}")
    print("SAVE SESSION NODE")
    print(f"{'='*60}")
    
    node_start_time = time.time()
    
    if state.get("status") == "error":
        print("Not saving due to error")
        
        # MLflow logging
        if mlflow.active_run():
            node_time = (time.time() - node_start_time) * 1000
            mlflow.log_metric("node_save_session_time_ms", node_time)
            mlflow.log_param("session_saved", False)
            mlflow.log_param("save_skip_reason", "error_state")
        
        return state
    
    # Prepare turn data
    current_request = state.get("current_request")
    current_response = state.get("current_response")
    evaluation_scores = state.get("evaluation_scores")
    conversation_history = state.get("conversation_history", [])
    
    # Build metadata
    metadata = {
        "query_type": state.get("query_type"),
        "routing_path": state.get("routing_path"),
        "model_id": state.get("model_id"),
        "timestamp": state.get("timestamp"),
        "is_deterministic": True
    }
    
    # Add evaluation to metadata if available
    if evaluation_scores:
        metadata["evaluation"] = evaluation_scores
    
    # Add classification scores
    if state.get("classification_scores"):
        metadata["classification"] = state.get("classification_scores")
    
    # Create turn entry (response already truncated in multiturn_handler)
    turn = {
        "question": current_request,
        "answer": current_response,
        "metadata": metadata,
        "timestamp": datetime.now().isoformat()
    }
    
    # Add turn to conversation history
    conversation_history.append(turn)
    
    print(f"Turn saved to state (Total turns: {len(conversation_history)})")
    # Note: State persistence depends on whether checkpointer was enabled during workflow build
    
    # MLflow logging
    if mlflow.active_run():
        node_time = (time.time() - node_start_time) * 1000
        mlflow.log_metric("node_save_session_time_ms", node_time)
        mlflow.log_param("session_saved", True)
        mlflow.log_metric("total_turns_in_session", len(conversation_history))
    
    return {
        **state,
        "conversation_history": conversation_history,
        "status": "completed"
    }


# ==============================================================================
# ROUTING FUNCTIONS
# ==============================================================================

def route_after_guardrail(state: DiscoveryState) -> str:
    """
    Route based on guardrail check
    
    Returns:
        'blocked' if question is inappropriate (goes to save_session -> END)
        'allowed' if allowed to proceed (goes to load_json_tool)
    """
    is_blocked = state.get("is_blocked", False)
    
    if is_blocked:
        print(f"\nRouting to: save_session (blocked)")
        return "blocked"
    else:
        print(f"\nRouting to: load_json_tool (allowed)")
        return "allowed"


# ==============================================================================
# WORKFLOW BUILDER
# ==============================================================================

def build_discovery_workflow(model_id: Optional[str] = None, use_checkpointer: bool = None):
    """
    Build and compile the discovery query workflow with guardrail.
    
    Workflow structure (5 nodes, 1 conditional route):
        START 
          |
        initialize_session
          |
        guardrail_check (LLM call)
          |
        [GUARDRAIL ROUTING]
          |-> BLOCKED -> save_session -> END
          |-> ALLOWED -> load_json_tool -> multiturn_handler (G-Eval) -> save_session -> END
    
    Args:
        model_id: Model to use (default: Haiku)
        use_checkpointer: Whether to use DynamoDB checkpointer (default: from USE_DYNAMODB env var)
    
    Returns:
        Compiled LangGraph workflow
    """
    print(f"\n{'='*60}")
    print("BUILDING DISCOVERY WORKFLOW WITH GUARDRAIL")
    print(f"{'='*60}")
    
    # Determine if checkpointer should be used
    if use_checkpointer is None:
        use_dynamodb_env = os.getenv("USE_DYNAMODB", "false")
        print(f"DEBUG: USE_DYNAMODB env var = '{use_dynamodb_env}'")
        use_checkpointer = use_dynamodb_env.lower() == "true"
        print(f"DEBUG: use_checkpointer resolved to = {use_checkpointer}")
    
    workflow = StateGraph(DiscoveryState)
    
    # Add nodes (5 nodes)
    workflow.add_node("initialize_session", initialize_session_node)
    workflow.add_node("guardrail_check", guardrail_check_node)
    workflow.add_node("load_json_tool", load_json_tool_node)
    workflow.add_node("multiturn_handler", multiturn_handler_node)
    workflow.add_node("save_session", save_session_node)
    
    # Edge: START -> initialize_session -> guardrail_check
    workflow.add_edge(START, "initialize_session")
    workflow.add_edge("initialize_session", "guardrail_check")
    
    # Conditional routing after guardrail check
    workflow.add_conditional_edges(
        "guardrail_check",
        route_after_guardrail,
        {
            "blocked": "save_session",
            "allowed": "load_json_tool"
        }
    )
    
    # Discovery path: load_json_tool -> multiturn_handler -> save_session -> END
    workflow.add_edge("load_json_tool", "multiturn_handler")
    workflow.add_edge("multiturn_handler", "save_session")
    workflow.add_edge("save_session", END)
    
    # Compile with or without checkpointer
    if use_checkpointer:
        checkpointer = get_dynamodb_checkpointer()
        if checkpointer:
            app = workflow.compile(checkpointer=checkpointer)
            print("Workflow compiled successfully with DynamoDB checkpointing")
        else:
            app = workflow.compile()
            print("Workflow compiled successfully (checkpointer initialization failed, using in-memory)")
    else:
        app = workflow.compile()
        print("Workflow compiled successfully (no checkpointer)")
    
    print(f"  Nodes: 5 (initialize_session, guardrail_check,")
    print(f"             load_json_tool, multiturn_handler, save_session)")
    print(f"  Conditional routes: 1 (guardrail)")
    print(f"  Model: {model_id or HAIKU_CONFIG['model_id']}")
    
    # Determine state management
    dynamodb_available = os.getenv("USE_DYNAMODB", "false").lower() == "true"
    if use_checkpointer:
        state_mgmt = "DynamoDB (Active)"
    elif dynamodb_available:
        state_mgmt = "DynamoDB (Available)"
    else:
        state_mgmt = "In-Memory"
    
    print(f"  State Management: {state_mgmt}")
    print(f"  Guardrail: Haiku-based content moderation (LLM call)")
    print(f"  Discovery Responses: Deterministic from JSON (no LLM) + G-Eval")
    
    return app


# ==============================================================================
# LEGACY COMPATIBILITY (for existing API)
# ==============================================================================

def build_graph():
    """Compatibility wrapper for build_discovery_workflow()"""
    return build_discovery_workflow()


def run_orchestration(user_query: str, thread_id: str):
    """Execute workflow with given query and thread ID"""
    graph = build_discovery_workflow()
    
    initial_state = {
        "session_id": thread_id,
        "current_request": user_query,
        "metadata": None,
        "turn_number": 1,
        "model_id": HAIKU_CONFIG["model_id"],
        "discoveries_file_path": "geoscience_agent/data/cera_week_qna.json",
        "conversation_history": [],
        "status": "initialized"
    }
    
    result = dict(initial_state)
    for step_output in graph.stream(initial_state):
        for node_name, node_state in step_output.items():
            result.update(node_state)
    
    # Return response summary or full response
    return result.get("response_summary", str(result.get("current_response", "")))


# ==============================================================================
# CONVENIENCE FUNCTIONS
# ==============================================================================

def query_discoveries(
    request: str,
    session_id: Optional[str] = None,
    model_id: Optional[str] = None,
    discoveries_file_path: str = "geoscience_agent/data/cera_week_qna.json",
    metadata: Optional[Dict] = None
) -> Dict:
    """
    Convenience function to query discoveries
    
    Args:
        request: The discovery query/request
        session_id: Existing session ID or None for new session
        model_id: Model ID to use (default: Haiku)
        discoveries_file_path: Path to discoveries JSON file
        metadata: Optional metadata (e.g., for UI interactions)
        
    Returns:
        Result dictionary with structured response
    """
    # Only use checkpointer for existing sessions to reduce DynamoDB writes
    use_checkpointer = session_id is not None
    app = build_discovery_workflow(model_id, use_checkpointer=use_checkpointer)
    
    # Determine turn number (DynamoDB handles state, default to turn 1 for new sessions)
    turn_number = 1
    
    # Generate session_id if not provided
    if not session_id:
        import uuid
        session_id = str(uuid.uuid4())
    
    initial_state = {
        "session_id": session_id,
        "current_request": request,
        "metadata": metadata,
        "turn_number": turn_number,
        "model_id": model_id or HAIKU_CONFIG["model_id"],
        "discoveries_file_path": discoveries_file_path,
        "conversation_history": [],
        "status": "initialized"
    }
    
    result = dict(initial_state)
    
    # Prepare config if using checkpointer
    if use_checkpointer:
        config = {"configurable": {"thread_id": session_id}}
        for step_output in app.stream(initial_state, config=config):
            for node_name, node_state in step_output.items():
                result.update(node_state)
    else:
        # No checkpointer needed for new sessions
        for step_output in app.stream(initial_state):
            for node_name, node_state in step_output.items():
                result.update(node_state)
    
    return result


# ==============================================================================
# JSON RESPONSE FORMATTING
# ==============================================================================

def format_response_json(state: Dict) -> Dict:
    """
    Convert raw LangGraph state into a clean, frontend-friendly JSON structure.
    """
    status = state.get("status", "unknown")
    is_blocked = state.get("is_blocked", False)

    response_payload = state.get("current_response") or {}
    response = {
        "summary": response_payload.get("summary", ""),
        "key_insights": response_payload.get("key_insights", []),
        "data_table": response_payload.get("data_table", []),
        "scatter_plot": response_payload.get("scatter_plot", {}),
        "map_update": response_payload.get("map_update", []),
        "columns": response_payload.get("columns", []),
        "dashboard": response_payload.get("dashboard", {}),
        "suggested_followup_prompts": response_payload.get("suggested_followup_prompts", []),
        "suggestions": response_payload.get("suggestions", []),
    }

    evaluation_raw = state.get("evaluation_scores") or {}
    evaluation = {
        k: evaluation_raw[k]
        for k in (
            "coherence", "consistency", "fluency",
            "relevance", "groundedness", "overall_score",
        )
        if k in evaluation_raw
    } if evaluation_raw else None

    response_meta = state.get("response_metadata") or {}

    guardrail_raw = state.get("guardrail_check") or {}
    guardrail = {
        "is_allowed": guardrail_raw.get("is_allowed"),
        "category": guardrail_raw.get("category"),
        "reason": guardrail_raw.get("reason"),
    } if guardrail_raw else None

    return {
        "session_id": state.get("session_id"),
        "status": status,
        "is_blocked": is_blocked,
        "query": state.get("current_request", ""),
        "turn_number": state.get("turn_number", 1),
        "response": response,
        "evaluation": evaluation,
        "metadata": {
            "matched_question": response_meta.get("matched_question"),
            "is_deterministic": response_meta.get("is_deterministic", True),
            "model_id": state.get("model_id"),
            "handler": response_meta.get("handler"),
            "timestamp": state.get("timestamp"),
        },
        "guardrail": guardrail,
    }


def query_discoveries_json(
    request: str,
    session_id: Optional[str] = None,
    model_id: Optional[str] = None,
    discoveries_file_path: str = "geoscience_agent/data/cera_week_qna.json",
    metadata: Optional[Dict] = None,
) -> Dict:
    """Same as query_discoveries but returns a clean JSON dict"""
    raw_state = query_discoveries(
        request=request,
        session_id=session_id,
        model_id=model_id,
        discoveries_file_path=discoveries_file_path,
        metadata=metadata,
    )
    return format_response_json(raw_state)


__all__ = [
    'DiscoveryState',
    'build_discovery_workflow',
    'query_discoveries_json',
    'format_response_json',
]