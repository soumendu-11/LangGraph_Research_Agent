"""
Geoscience Discovery Agent (v3 Architecture)
Deterministic Q&A system with guardrail checking and G-Eval evaluation
"""
from .graph import (
    build_discovery_workflow,
    query_discoveries_json,
    format_response_json,
    DiscoveryState,
)

from .dynamodb_checkpointer import DynamoDBSaver

__version__ = "3.0.0"

__all__ = [
    "build_discovery_workflow",
    "query_discoveries_json",
    "format_response_json",
    "DiscoveryState",
    "DynamoDBSaver",
]
