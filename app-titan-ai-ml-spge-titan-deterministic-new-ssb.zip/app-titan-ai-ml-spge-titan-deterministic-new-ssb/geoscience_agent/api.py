# api.py
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from typing import Optional, AsyncGenerator
import json
import asyncio
from datetime import datetime
import uuid
import time
import os

from geoscience_agent.graph import (
    query_discoveries_json, 
    build_discovery_workflow,
    format_response_json
)
import mlflow

app = FastAPI(
    title="Geoscience LangGraph Agent API",
    description="Enterprise geoscience analytics powered by LangGraph, AWS Bedrock, MLflow, and DynamoDB",
    version="1.0.0",
    root_path=os.getenv("ROOT_PATH", "")  # Support for reverse proxy/API Gateway
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize resources on application startup"""
    print("\n" + "="*60)
    print("STARTING UP GEOSCIENCE AGENT API")
    print("="*60)
    
    # Pre-initialize the embedding classifier (avoids 25-50s delay on first request)
    print("Pre-initializing EmbeddingQueryClassifier...")
    from geoscience_agent.core.multiturn_processor import get_classifier
    get_classifier()
    print("Classifier initialized and ready")
    
    print("="*60)
    print("API READY TO ACCEPT REQUESTS")
    print("="*60 + "\n")


# Helper function to format SSE events
def format_sse_event(event_type: str, data: dict) -> str:
    """Format data as Server-Sent Event"""
    return f"event: {event_type}\ndata: {json.dumps(data)}\n\n"


def transform_map_update_to_assets(map_update_list: list, data_table: list = None) -> list:
    """
    Transform map_update data from JSON format to frontend-expected asset format.
    
    Input format (from JSON):
    {
        "Asset ID": "100000055097",
        "Asset Name": "Fawz 1 (QSF)",  # optional - will lookup from data_table if missing
        "Coordinates (WKT)": "POINT(57.067534 22.025205)",
        "Operator": "...",
        ...other fields...
    }
    
    Output format (for frontend):
    {
        "asset_id": "well_100000055097",
        "asset_type": "well",
        "asset_name": "Fawz 1 (QSF)",
        "wkt": "POINT(57.067534 22.025205)",
        "properties": {...all other fields...}
    }
    """
    # Create lookup dict from data_table if provided
    data_lookup = {}
    if data_table:
        for row in data_table:
            api_num = row.get("API Number") or row.get("Asset ID")
            if api_num:
                data_lookup[str(api_num)] = row
    
    assets = []
    for item in map_update_list:
        asset_id = item.get("Asset ID") or item.get("API Number", "unknown")
        asset_name = item.get("Asset Name") or item.get("Well Name")
        
        # If asset name is missing, try to look it up from data_table
        if not asset_name and str(asset_id) in data_lookup:
            data_row = data_lookup[str(asset_id)]
            asset_name = data_row.get("Well Name") or data_row.get("Asset Name", f"Asset {asset_id}")
        elif not asset_name:
            asset_name = f"Asset {asset_id}"
        
        wkt = item.get("Coordinates (WKT)", "")
        
        # Create properties dict with all fields except the ones we've extracted
        properties = {k: v for k, v in item.items() 
                     if k not in ["Asset ID", "Asset Name", "Coordinates (WKT)"]}
        
        # If we have data_table info, add additional properties
        if str(asset_id) in data_lookup:
            data_row = data_lookup[str(asset_id)]
            for k, v in data_row.items():
                if k not in ["API Number", "Asset ID", "Well Name", "Asset Name", "Coordinates (WKT)"]:
                    if k not in properties:  # Don't override existing properties
                        properties[k] = v
        
        assets.append({
            "asset_id": f"well_{asset_id}",
            "asset_type": "well",
            "asset_name": asset_name,
            "wkt": wkt,
            "properties": properties
        })
    
    return assets


# Request Models
class AssetGeometry(BaseModel):
    type: str = Field(..., description="GeoJSON geometry type (Point, Polygon, LineString, MultiPoint)")
    coordinates: list = Field(..., description="GeoJSON coordinate array")

class SelectedAsset(BaseModel):
    asset_id: str = Field(..., description="Unique asset identifier")
    asset_type: str = Field(..., description="Asset type (well, lease, field, spacing_unit, etc.)")
    asset_name: str = Field(..., description="Asset name")
    geometry: AssetGeometry = Field(..., description="Asset geometry")
    asset_metadata: Optional[dict] = Field(None, description="Additional asset attributes")

class DrawnGeometry(BaseModel):
    type: str = Field(..., description="Geometry type (Polygon, Circle, Rectangle)")
    coordinates: list = Field(..., description="GeoJSON coordinate array")

class Viewport(BaseModel):
    bounds: dict = Field(..., description="Bounding box with xmin, ymin, xmax, ymax")
    center: list = Field(..., description="[longitude, latitude]")
    spatial_reference: Optional[dict] = Field({"wkid": 4326}, description="Spatial reference (default EPSG:4326)")

class MapContext(BaseModel):
    type: str = Field(..., description="selected_asset | drawn_geometry | viewport")
    asset: Optional[SelectedAsset] = Field(None, description="Asset details if type=selected_asset")
    geometry: Optional[DrawnGeometry] = Field(None, description="Drawn geometry if type=drawn_geometry")
    viewport: Optional[Viewport] = Field(None, description="Viewport details if type=viewport")

class Context(BaseModel):
    trigger: str = Field(..., description="user_typed | well_click | area_drawn | action_button")

class QueryRequest(BaseModel):
    query: str = Field(..., min_length=1, max_length=2000, description="Natural language query or user prompt")
    session_id: Optional[str] = Field(None, description="Session identifier for conversation continuity (null = new session)")
    map_context: Optional[MapContext] = Field(None, description="Geospatial context at highest level of user specificity")
    context: Optional[Context] = Field(None, description="Request context metadata")
    include_map_update: bool = Field(False, description="If true, backend returns map_update event with geospatial data")
    
    # Performance optimization flags
    skip_guardrail: bool = Field(False, description="Skip guardrail check for trusted sources (saves 2-4s)")
    
    # Legacy fields for backwards compatibility
    thread_id: Optional[str] = Field(None, max_length=100, description="Legacy: Thread ID for conversation context")
    user_id: Optional[str] = Field(None, max_length=100, description="User identifier")
    metadata: Optional[dict] = Field(None, description="Additional metadata")

    @property
    def effective_session_id(self) -> Optional[str]:
        """Return thread_id or session_id, prioritizing thread_id, ignoring placeholder values"""
        # Ignore common placeholder/test values
        placeholders = {"string", "test", "sample", "example", ""}
        
        # Check thread_id first (if not a placeholder)
        if self.thread_id and self.thread_id.lower() not in placeholders:
            return self.thread_id
        
        # Fall back to session_id (if not a placeholder)
        if self.session_id and self.session_id.lower() not in placeholders:
            return self.session_id
        
        # If both are placeholders or None, return None
        return None


# Health check endpoint
@app.get("/health")
async def health_check():
    """Health check endpoint for ECS/Fargate"""
    return {
        "status": "healthy",
        "service": "geoscience-langgraph-agent",
        "timestamp": datetime.utcnow().isoformat()
    }


# Server-Sent Events (SSE) streaming endpoint
@app.post("/query/stream")
async def process_query_stream(request: QueryRequest):
    """
    Stream discovery query response as Server-Sent Events (SSE).
    
    Streams: chain_of_thought, text, data, map_update, dashboard, 
    scatter_plot, suggestions, and complete events.
    """
    async def event_generator() -> AsyncGenerator[str, None]:
        start_time = time.time()
        query_id = str(uuid.uuid4())
        
        try:
            # Use provided session_id or generate new one
            session_id = request.effective_session_id
            is_new_session = not session_id
            if not session_id:
                session_id = str(uuid.uuid4())
            
            # Only use DynamoDB checkpointer for existing sessions (to reduce writes)
            # New sessions don't need checkpointing until the 2nd turn
            use_checkpointer = not is_new_session and os.getenv("USE_DYNAMODB", "false").lower() == "true"
            graph = build_discovery_workflow(use_checkpointer=use_checkpointer)
            
            # Turn number starts at 1 (conversation history maintained in DynamoDB state)
            turn_number = 1
            
            # Send session_start event
            yield format_sse_event("session_start", {
                "session_id": session_id,
                "query_id": query_id,
                "timestamp": datetime.utcnow().isoformat()
            })
            
            mlflow.set_experiment("Geoscience_Discovery_Agent")
            
            # Ensure any previous run is ended before starting a new one
            try:
                mlflow.end_run()
            except Exception:
                pass  # No active run to end
            
            with mlflow.start_run():
                # Log query parameters
                mlflow.log_param("user_query", request.query)
                mlflow.log_param("session_id", session_id)
                mlflow.log_param("turn_number", turn_number)
                mlflow.log_param("query_id", query_id)
                
                if request.user_id:
                    mlflow.log_param("user_id", request.user_id)
                
                if request.map_context:
                    mlflow.log_param("map_context_type", request.map_context.type)
                    
                    # Log viewport details if available
                    if request.map_context.viewport:
                        viewport = request.map_context.viewport
                        if viewport.center and len(viewport.center) >= 2:
                            mlflow.log_param("map_context_center", f"{viewport.center[0]},{viewport.center[1]}")
                        if viewport.bounds:
                            bounds_str = f"xmin:{viewport.bounds.get('xmin')},ymin:{viewport.bounds.get('ymin')},xmax:{viewport.bounds.get('xmax')},ymax:{viewport.bounds.get('ymax')}"
                            mlflow.log_param("map_context_bounds", bounds_str)
                    
                    # Log asset details if available
                    if request.map_context.asset:
                        mlflow.log_param("map_context_asset_id", request.map_context.asset.asset_id)
                        mlflow.log_param("map_context_asset_type", request.map_context.asset.asset_type)
                    
                    # Log geometry details if available
                    if request.map_context.geometry:
                        mlflow.log_param("map_context_geometry_type", request.map_context.geometry.type)
                
                # Log model configuration
                mlflow.log_param("model_id", "anthropic.claude-3-haiku-20240307-v1:0")
                mlflow.log_param("guardrail_model", "anthropic.claude-3-haiku-20240307-v1:0")
                mlflow.log_param("evaluator_model", "anthropic.claude-3-haiku-20240307-v1:0")
                mlflow.log_param("embedding_model", "amazon.titan-embed-text-v2:0")
                
                # Log workflow configuration
                mlflow.log_param("include_map_update", request.include_map_update)
                mlflow.log_param("skip_guardrail", request.skip_guardrail)
                mlflow.log_param("discoveries_file", "geoscience_agent/data/cera_week_qna.json")
                mlflow.log_param("workflow_type", "deterministic_no_eval")
                mlflow.log_param("workflow_nodes", "5")  # initialize, guardrail, load_json, multiturn, save
                mlflow.log_param("state_management", "dynamodb" if os.getenv("USE_DYNAMODB", "false").lower() == "true" else "in-memory")
                if os.getenv("USE_DYNAMODB", "false").lower() == "true":
                    mlflow.log_param("dynamodb_table", os.getenv("DYNAMODB_TABLE_NAME", "langgraph_checkpoints"))
                
                # Log query length
                mlflow.log_metric("query_length_chars", len(request.query))
                mlflow.log_metric("query_length_words", len(request.query.split()))
                
                initial_state = {
                    "session_id": session_id,
                    "current_request": request.query,
                    "metadata": {
                        **(request.metadata or {}),
                        "skip_guardrail": request.skip_guardrail
                    },
                    "map_context": request.map_context.dict() if request.map_context else None,
                    "include_map_update": request.include_map_update,
                    "turn_number": turn_number,
                    "model_id": "anthropic.claude-3-haiku-20240307-v1:0",
                    "discoveries_file_path": "geoscience_agent/data/cera_week_qna.json",
                    "conversation_history": [],
                    "status": "initialized",
                    "query_id": query_id
                }
                
                final_state = dict(initial_state)
                response_text_parts = []
                
                # Prepare config for LangGraph checkpointer
                config = {"configurable": {"thread_id": session_id}}
                
                # Stream through workflow
                for step_output in graph.stream(initial_state, config=config):
                    for node_name, node_state in step_output.items():
                        final_state.update(node_state)
                        
                        # Send chain_of_thought for each node
                        yield format_sse_event("chain_of_thought", {
                            "step": node_name,
                            "reasoning": f"Processing {node_name}",
                            "tool": node_name,
                            "query_id": query_id
                        })
                        
                        # Handle guardrail check
                        if node_name == "guardrail_check":
                            gc = node_state.get("guardrail_check") or {}
                            if not gc.get("is_allowed", True):
                                # Use suggested_response from guardrail
                                blocked_msg = gc.get("suggested_response") or "I'm sorry, but I'm unable to help with that request. Is there something else I can assist you with?"
                                yield format_sse_event("text", {
                                    "delta": blocked_msg,
                                    "query_id": query_id
                                })
                                
                                # Send error event
                                yield format_sse_event("error", {
                                    "error_type": "forbidden",
                                    "error_code": 403,
                                    "message": blocked_msg,
                                    "query_id": query_id,
                                    "timestamp": datetime.utcnow().isoformat()
                                })
                                return
                
                # Get final response
                final_response = format_response_json(final_state)
                
                # Send text events (stream the summary)
                summary = final_response.get("response", {}).get("summary", "")
                if summary:
                    # Split summary into chunks for streaming effect
                    words = summary.split()
                    chunk_size = 5  # words per chunk
                    for i in range(0, len(words), chunk_size):
                        chunk = " ".join(words[i:i+chunk_size])
                        if i + chunk_size < len(words):
                            chunk += " "
                        yield format_sse_event("text", {
                            "delta": chunk,
                            "query_id": query_id
                        })
                
                # Send data event if there's a data table
                data_table = final_response.get("response", {}).get("data_table", [])
                if data_table and len(data_table) > 0:
                    # Convert data_table to columns and rows format
                    if len(data_table) > 0:
                        columns = [{"name": k, "type": "string", "display_name": k.replace("_", " ").title()} 
                                  for k in data_table[0].keys()]
                        
                        yield format_sse_event("data", {
                            "type": "tabular",
                            "columns": columns,
                            "rows": data_table,
                            "total_rows": len(data_table),
                            "pagination": None,
                            "query_id": query_id
                        })
                
                # Send map_update event if requested and available
                if request.include_map_update:
                    map_data = final_response.get("response", {}).get("map_update", [])
                    if map_data:
                        # Transform to frontend-expected asset format
                        data_table = final_response.get("response", {}).get("data_table", [])
                        assets = transform_map_update_to_assets(map_data, data_table)
                        yield format_sse_event("map_update", {
                            "action": "show",
                            "assets": assets,
                            "query_id": query_id
                        })
                
                # Send dashboard event if available
                dashboard = final_response.get("response", {}).get("dashboard", {})
                if dashboard:
                    yield format_sse_event("dashboard", {
                        "dashboard": dashboard,
                        "query_id": query_id
                    })
                
                # Send scatter_plot event if available
                scatter_plot = final_response.get("response", {}).get("scatter_plot", {})
                if scatter_plot:
                    yield format_sse_event("scatter_plot", {
                        "scatter_plot": scatter_plot,
                        "query_id": query_id
                    })
                
                # Send suggestions event if available
                suggestions = final_response.get("response", {}).get("suggestions", [])
                if suggestions:
                    yield format_sse_event("suggestions", {
                        "suggestions": suggestions,
                        "query_id": query_id
                    })
                
                # Send complete event
                execution_time_ms = int((time.time() - start_time) * 1000)
                yield format_sse_event("complete", {
                    "query_id": query_id,
                    "total_tokens": 0,  # TODO: Add token counting if needed
                    "execution_time_ms": execution_time_ms,
                    "data_cached": False
                })
                
                # Log final response to MLflow
                mlflow.log_dict(final_response, "final_response.json")
                mlflow.log_metric("total_execution_time_ms", execution_time_ms)
                
                # Log response structure metrics
                response_data = final_response.get("response", {})
                summary = response_data.get("summary", "")
                data_table = response_data.get("data_table", [])
                map_update = response_data.get("map_update", [])
                
                mlflow.log_metric("response_summary_length_chars", len(summary))
                mlflow.log_metric("response_summary_length_words", len(summary.split()))
                mlflow.log_metric("response_data_table_rows", len(data_table))
                mlflow.log_metric("response_map_update_assets", len(map_update))
                
                # Log evaluation scores if present
                if final_response.get("evaluation"):
                    for metric, value in final_response["evaluation"].items():
                        if isinstance(value, (int, float)):
                            mlflow.log_metric(f"final_{metric}", value)
                
                # Log workflow status
                workflow_status = final_state.get("status", "unknown")
                mlflow.log_param("workflow_status", workflow_status)
                
                if final_state.get("error"):
                    mlflow.log_param("workflow_error", final_state.get("error"))
                
        except Exception as e:
            import traceback
            
            # Ensure MLflow run is ended on error
            try:
                mlflow.end_run(status="FAILED")
            except Exception:
                pass
            
            yield format_sse_event("error", {
                "error_type": "internal_error",
                "error_code": 500,
                "message": str(e),
                "details": traceback.format_exc(),
                "query_id": query_id,
                "timestamp": datetime.utcnow().isoformat()
            })
    
    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no"
        }
    )


# Get conversation history endpoint
@app.get("/conversations/{session_id}")
async def get_conversation_history(session_id: str):
    """Retrieve conversation history for a given session."""
    try:
        # Conversation history is stored in DynamoDB checkpoints
        # This endpoint is not available when using DynamoDB state management
        if os.getenv("USE_DYNAMODB", "false").lower() == "true":
            raise HTTPException(
                status_code=501,
                detail="Conversation history endpoint not available with DynamoDB state management. Query DynamoDB checkpoints table directly."
            )
        
        return {
            "status": "success",
            "session_id": session_id,
            "created_at": session.get("created_at"),
            "last_updated": session.get("last_updated"),
            "conversation_history": session.get("conversation_history", []),
            "num_turns": len(session.get("conversation_history", []))
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Non-streaming query endpoint
@app.post("/query")
async def process_query(request: QueryRequest):
    """
    Process a user query without streaming (returns complete response).
    Uses the new v3 discovery workflow architecture.
    """
    try:
        result = query_discoveries_json(
            request=request.query,
            session_id=request.effective_session_id,
            discoveries_file_path="geoscience_agent/data/cera_week_qna.json",
            metadata=request.metadata
        )
        
        return {
            "status": "success",
            "timestamp": datetime.utcnow().isoformat(),
            **result
        }
    except Exception as e:
        import traceback
        raise HTTPException(
            status_code=500,
            detail={
                "error": str(e),
                "error_type": type(e).__name__,
                "traceback": traceback.format_exc()
            }
        )


# List sessions endpoint  
@app.get("/sessions")
async def list_sessions():
    """
    List all available sessions (file-based only, not available with DynamoDB).
    For DynamoDB deployments, query DynamoDB checkpoints table directly.
    """
    try:
        if os.getenv("USE_DYNAMODB", "false").lower() == "true":
            return {
                "status": "error",
                "message": "Session listing not available with DynamoDB state management. Query DynamoDB checkpoints table directly.",
                "dynamodb_table": os.getenv("DYNAMODB_TABLE_NAME", "langgraph_checkpoints")
            }
        
        # File-based session storage not available
        raise HTTPException(
            status_code=501,
            detail="Session listing not available. Use DynamoDB for state management."
        )
        
        return {
            "status": "success",
            "sessions": sessions,
            "count": len(sessions)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# List available tools endpoint
@app.get("/tools")
async def list_tools():
    """List all available geoscience agent tools"""
    # In v3 architecture, we use deterministic JSON responses instead of tools
    return {
        "status": "success",
        "message": "This v3 agent uses deterministic JSON-based responses with guardrail checking",
        "features": [
            "Guardrail-based content moderation (Haiku LLM)",
            "Deterministic responses from curated Q&A JSON",
            "Embedding-based query classification (Titan)",
            "G-Eval quality scoring (Haiku LLM)",
            "Multi-turn conversation support",
            "Session persistence"
        ]
    }


# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information"""
    return {
        "service": "Geoscience Discovery Agent API (v3 Architecture)",
        "version": "3.0.0",
        "status": "running",
        "description": "Deterministic discovery Q&A with guardrail checking and G-Eval scoring",
        "endpoints": {
            "health": "/health",
            "query_streaming": "/query/stream",
            "query_non_streaming": "/query",
            "sessions": "/sessions",
            "conversation_history": "/conversations/{session_id}",
            "tools_info": "/tools",
            "docs": "/docs"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8000,
        log_level="info"
    )