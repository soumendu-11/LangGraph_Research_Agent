# app-titan-config
This repository contains all the Terraform code and related scripts used to provision cloud infrastructure for the S&P Global Energy Titan Project.

## To run Terraform Locally:
 - Get the `SAML to AWS STS Keys Google Chrome` extension and make sure the `Apply the session duration requested by the SAML provider` option is set to `no`
 - Log into the Amazon AWS dashboard via myapplications.microsoft.com
   - If the extension is working correctly, you should automatically download a file called "credentials" to your Downloads folder
   - If it doesn't download, try closing the tab and re-entering from the My Applications portal
 - Configure the AWS CLI with the credentials in the credentials file you downloaded
 - Configure a profile called "titan-dev" in the AWS CLI, you can do this easily by opening `~/.aws/credentials` and duplicating the content there, then changing `[default]` to `[titan-dev]`
   - It should look something like this:
    ```
    [default]
    aws_access_key_id=<KEY>
    aws_secret_access_key=<OTHER KEY>
    aws_session_token=<TOKEN>
    [titan-dev]
    aws_access_key_id=<KEY>
    aws_secret_access_key=<OTHER KEY>
    aws_session_token=<TOKEN>
    ```

 - Once all that's configured, go to `env_config/titan/titan_all/terraform/local`
 - For the next few steps, `<module name>` refers to the name of the folder under the `terraform` folder that you want to run Terraform on

  ## Prerequisites:
   - Make sure you have Terraform, the AWS CLI and Python installed
   - Make sure you have the `pyyaml` package installed for Python
     - You can get this by running `pip install pyyaml`

   ### If you're on a Mac
   - Run `source set-env.sh dev us.dev`
   - Run `sh terraform-init.sh <module name>`
   - Run `sh terraform-plan.sh <module name>`
   - Once that's finished, check the output that the planned actions look correct
   - Finally, run `sh terraform-apply.sh <module name>`
     - If it succeeds, you can go to the AWS Dashboard in your browser and confirm all the resources were set up correctly

   ### If you're on a Windows machine
   - **Do the following in a _Command Prompt_**
   - Run `set-env.cmd dev us.dev`
   - Run `terraform-init.cmd <module name>`
   - Run `terraform-plan.cmd <module name>`
     - Once that's finished, check the output that the planned actions look correct
   - Finally, run `terraform-apply.cmd <module name>`
     - If it succeeds, you can go to the AWS Dashboard in your browser and confirm all the resources were set up correctly

## On Order of Operations
Sometimes, your modules will depend on one another. In this case, you must run the first apply for each module manually, in the correct order. Once all resources have been created, you should not have to worry about order of operations, and Ansible will be able to run Terraform scripts at its discretion.

For setting up a new environment in AWS, you should try to run the modules in this order:
 1. `security-groups` -> Sets up the load balancer and app security groups, the load balancer and the load balander listeners and rules  
 2. `platform-s3` -> Sets up the S3 bucket that contains the Titan front-end and its asssociated policies; also sets up a CloudFront distribution that sits in front of the front-end
 3. `platform-db` -> Sets up the user table in DynamoDB for the platform UserService as well as some IAM roles to access the database
 4. `data-ecr` -> Sets up the Elastic Container Resgitry to hold data service images and its lifecycle policy
 5. `platform-ecs` -> Sets up the Elastic Container Service Cluster for running data and platform services, as well as its associated IAM role
 6. `data-products-ecs-tasks` -> Sets up the Data API Service, its associated IAM roles and policies, task definitions, security groups, target groups, ALB listener rules and ECS services
 7. `data-ecs-tasks` -> Sets up the Mlflow service, its associated IAM roles and policies, task definitions, security groups, target groups, ALB listener rules and ECS services
 8. `platform-user-service` -> Sets up the ECR to hold UserService images, the UserService itself and its associated task definitions, target groups, ECS services and ALB listener rules
 9. `api-gateway` -> Sets up the HTTP API Gateway and the CloudFront distribution that sits in front of it
