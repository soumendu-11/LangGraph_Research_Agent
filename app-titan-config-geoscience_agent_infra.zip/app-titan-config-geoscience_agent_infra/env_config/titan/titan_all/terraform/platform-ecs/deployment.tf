variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "AppHealthCheckPath" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

variable "AppPort" {}
variable "AppCount" {}
variable "FargateCpuUnits" {}
variable "FargateMemoryMb" {}

variable "ITSgName" {}
variable "ITServerlessSgName" {}
variable "NumberOfAZs" {}

variable "AppVPC" {}
variable "AWSRegionShort" {}
variable "AppSubnetA" {}
variable "AppSubnetB" {}

variable "AmazonECRExecutionPolicyArn" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

#####################
### Compute (ECS)
#####################
resource "aws_ecs_cluster" "App" {
  name = "${var.DeployName}-cluster"

  tags = {
    name = "${var.DeployName}-cluster"
  }
}

resource "aws_iam_role" "ECS" {
  provider           = aws.aws-iam-users
  name               = "${var.DeployName}-ecs"
  assume_role_policy = data.aws_iam_policy_document.assume_role_policy_ecs.json
}

resource "aws_iam_role_policy_attachment" "ECRECRPolicy" {
  provider   = aws.aws-iam-users
  role       = aws_iam_role.ECS.name
  policy_arn = var.AmazonECRExecutionPolicyArn
}

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

data "aws_iam_policy_document" "assume_role_policy_ecs" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}

provider "aws" {
  region  = var.AWSRegion
  alias   = "aws-iam-users"
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      Admin-email = var.TagContact
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
      name        = var.DeployName # To satisfy AWS role constraints
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
