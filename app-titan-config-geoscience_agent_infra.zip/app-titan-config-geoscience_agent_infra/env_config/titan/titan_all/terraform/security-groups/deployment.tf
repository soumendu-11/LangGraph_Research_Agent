variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "SSLPolicy" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

variable "AppPort" {}
variable "AppVPC" {}
variable "WAF" {}
variable "WAFScope" {}

variable "PublicSubnetA" {}
variable "PublicSubnetB" {}
variable "AppSubnetA" {}
variable "AppSubnetB" {}
variable "ElbWebSubnetA" {}
variable "ElbWebSubnetB" {}

variable "AccessLogsBucket" {}
variable "AppHealthCheckPath" {}

variable "UsePrivateLoadBalancer" {
  type = bool
}
variable "LBAllowedCidrBlocks" {
  type        = string
  description = "List of CIDR blocks allowed to access the Load Balancer"
  default     = "10.0.0.0/8"
}
variable "DnsNames" {
  type = string
}

###########################
locals {
  EnvLower     = lower(var.Environment)
  DnsNamesList = split(",", var.DnsNames)
}

###########################
### Security Groups
###########################
resource "aws_security_group" "Edge" {
  name        = "${var.DeployName}_lb_sg"
  description = "Controls Access to the Titan Load Balancer"
  vpc_id      = data.aws_vpc.AppVPC.id

  ingress {
    description = "HTTP"
    protocol    = "tcp"
    from_port   = 80
    to_port     = 80
    cidr_blocks = ["10.0.0.0/8"]
  }

  ingress {
    description = "HTTPS"
    protocol    = "tcp"
    from_port   = 443
    to_port     = 443
    cidr_blocks = [for c in split(",", var.LBAllowedCidrBlocks) : trimspace(c)]
  }

  tags = {
    name = "${var.DeployName}_lb_sg"
  }
}

resource "aws_security_group_rule" "EdgeEgressToAppSubnetA" {
  security_group_id = aws_security_group.Edge.id
  type              = "egress"
  description       = "Traffic from Edge to Subnet A"
  from_port         = var.AppPort
  to_port           = var.AppPort
  protocol          = "tcp"
  cidr_blocks       = [data.aws_subnet.AppSubnetA.cidr_block]
}

resource "aws_security_group_rule" "EdgeEgressToAppSubnetB" {
  security_group_id = aws_security_group.Edge.id
  type              = "egress"
  description       = "Traffic from Edge to Subnet B"
  from_port         = var.AppPort
  to_port           = var.AppPort
  protocol          = "tcp"
  cidr_blocks       = [data.aws_subnet.AppSubnetB.cidr_block]
}

resource "aws_security_group" "App" {
  name   = "${var.DeployName}-app-sg"
  vpc_id = data.aws_vpc.AppVPC.id
}

resource "aws_security_group_rule" "AppHttpIn" {
  security_group_id        = aws_security_group.App.id
  type                     = "ingress"
  description              = "Traffic Port"
  from_port                = var.AppPort
  to_port                  = var.AppPort
  protocol                 = "tcp"
  source_security_group_id = aws_security_group.Edge.id
}

resource "aws_security_group_rule" "AppHttpsIn" {
  security_group_id = aws_security_group.App.id
  type              = "ingress"
  description       = "HTTPS"
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  cidr_blocks       = ["10.0.0.0/8"]
}

resource "aws_security_group_rule" "AppHttpOut" {
  security_group_id = aws_security_group.App.id
  type              = "egress"
  description       = "HTTP"
  from_port         = 80
  to_port           = 80
  protocol          = "tcp"
  cidr_blocks       = ["10.0.0.0/8"]
}

resource "aws_security_group_rule" "AppHttpsOut" {
  security_group_id = aws_security_group.App.id
  type              = "egress"
  description       = "HTTPS"
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  cidr_blocks       = ["0.0.0.0/0"]
}

resource "aws_lb" "Edge" {
  name                       = "${var.DeployName}-edge"
  internal                   = var.UsePrivateLoadBalancer
  ip_address_type            = "ipv4"
  load_balancer_type         = "application"
  idle_timeout               = 120
  desync_mitigation_mode     = "defensive"
  enable_waf_fail_open       = false
  enable_deletion_protection = true
  security_groups = [
    aws_security_group.Edge.id
  ]
  drop_invalid_header_fields = true
  subnets = var.UsePrivateLoadBalancer ? [
    data.aws_subnet.ElbWebSubnetA.id,
    data.aws_subnet.ElbWebSubnetB.id
    ] : [
    data.aws_subnet.PublicSubnetA.id,
    data.aws_subnet.PublicSubnetB.id
  ]

  tags = {
    name = "${var.DeployName}-edge"
  }
}

resource "aws_wafv2_web_acl_association" "Edge" {
  resource_arn = aws_lb.Edge.arn
  web_acl_arn  = data.aws_wafv2_web_acl.WAF.arn
}

resource "aws_lb_listener" "EdgeHTTPSListener" {
  load_balancer_arn = aws_lb.Edge.arn
  port              = 443
  protocol          = "HTTPS"
  ssl_policy        = var.SSLPolicy

  certificate_arn = data.aws_acm_certificate.Certs[local.DnsNamesList[0]].arn

  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      status_code  = 503
      message_body = "service not available"
    }
  }

  tags = {
    name = "${var.DeployName}-edge-https-forward"
  }
}

resource "aws_lb_listener" "EdgeHTTPListener" {
  load_balancer_arn = aws_lb.Edge.arn
  port              = 80
  protocol          = "HTTP"
  default_action {
    type = "fixed-response"
    fixed_response {
      content_type = "text/plain"
      status_code  = 503
      message_body = "service not available"
    }
  }

  tags = {
    name = "${var.DeployName}-edge-http-redirect"
  }
}

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

data "aws_vpc" "AppVPC" {
  filter {
    name   = "tag:Name"
    values = [var.AppVPC]
  }
}

data "aws_subnet" "PublicSubnetA" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.PublicSubnetA]
  }
}

data "aws_subnet" "PublicSubnetB" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.PublicSubnetB]
  }
}

data "aws_subnet" "AppSubnetA" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetA]
  }
}

data "aws_subnet" "AppSubnetB" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetB]
  }
}

data "aws_subnet" "ElbWebSubnetA" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.ElbWebSubnetA]
  }
}

data "aws_subnet" "ElbWebSubnetB" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.ElbWebSubnetB]
  }
}

data "aws_wafv2_web_acl" "WAF" {
  name  = var.WAF
  scope = var.WAFScope
}

data "aws_acm_certificate" "Certs" {
  for_each = toset(local.DnsNamesList)
  domain   = lower(each.value)
  statuses = ["ISSUED"]
}


#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
