variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "AWSAccount" {}
variable "ComponentName" {}

variable "AppVPC" {}
variable "PublicSubnetA" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

####################
### Data Sources
####################
data "aws_vpc" "AppVPC" {
  filter {
    name   = "tag:Name"
    values = [var.AppVPC]
  }
}

data "aws_subnet" "SageMakerSubnet" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.PublicSubnetA]
  }
}

####################
### IAM Role for SageMaker
####################
resource "aws_iam_role" "sagemaker_execution_role" {
  name = "${var.DeployName}-sagemaker-execution-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "sagemaker.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
    ]
  })

  tags = {
    Name = "${var.DeployName}-sagemaker-execution-role"
  }
}

resource "aws_iam_role_policy_attachment" "bedrock_full_access" {
  role       = aws_iam_role.sagemaker_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonBedrockFullAccess"
}

resource "aws_iam_role_policy_attachment" "sagemaker_canvas_data_science_assitant_access" {
  role       = aws_iam_role.sagemaker_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSageMakerCanvasSMDataScienceAssistantAccess"
}

resource "aws_iam_role_policy_attachment" "sagemaker_full_access" {
  role       = aws_iam_role.sagemaker_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSageMakerFullAccess"
}

resource "aws_iam_role_policy" "sagemaker_dynamodb_permissions" {
  name = "${var.DeployName}-sagemaker-dynamodb-permissions"
  role = aws_iam_role.sagemaker_execution_role.id

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Sid    = "DynamoDBPromptVersionsAccess",
        Effect = "Allow",
        Action = [
          "dynamodb:PutItem",
          "dynamodb:GetItem",
          "dynamodb:Query",
          "dynamodb:Scan",
          "dynamodb:UpdateItem"
        ],
        Resource = "arn:aws:dynamodb:*:*:table/spge-titan-prompt_versions"
      },
      {
        Sid    = "DynamoDBSPGETitanTablesAccess",
        Effect = "Allow",
        Action = [
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:GetItem",
          "dynamodb:Query",
          "dynamodb:Scan",
          "dynamodb:DescribeTable"
        ],
        Resource = "arn:aws:dynamodb:*:*:table/spge-titan*"
      }
    ]
  })
}

resource "aws_iam_role_policy" "sagemaker_s3_access" {
  name = "${var.DeployName}-sagemaker-s3-access"
  role = aws_iam_role.sagemaker_execution_role.id

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Sid      = "AllowListBucketsInAccount",
        Effect   = "Allow",
        Action   = "s3:ListAllMyBuckets",
        Resource = "*"
      },
      {
        Sid    = "AllowListSpgeTitanBuckets",
        Effect = "Allow",
        Action = [
          "s3:ListBucket",
          "s3:ListBucketVersions"
        ],
        Resource = "arn:aws:s3:::spge-titan*"
      },
      {
        Sid    = "AllowReadWriteObjectsFromSpgeTitanBuckets",
        Effect = "Allow",
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:DeleteObjectVersion"
        ],
        Resource = "arn:aws:s3:::spge-titan*/*"
      },
      {
        Sid    = "AllowBucketVersioningManagement",
        Effect = "Allow",
        Action = [
          "s3:GetBucketVersioning",
          "s3:PutBucketVersioning"
        ],
        Resource = "arn:aws:s3:::spge-titan*"
      }
    ]
  })
}

resource "aws_iam_role_policy" "sagemaker_iam_management" {
  name = "${var.DeployName}-sagemaker-iam-management"
  role = aws_iam_role.sagemaker_execution_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SageMakerCanvasBedrockRoleManagement"
        Effect = "Allow"
        Action = [
          "iam:CreateRole",
          "iam:AttachRolePolicy",
          "iam:DetachRolePolicy",
          "iam:PutRolePolicy",
          "iam:DeleteRolePolicy",
          "iam:GetRole",
          "iam:GetRolePolicy",
          "iam:ListAttachedRolePolicies",
          "iam:ListRolePolicies",
          "iam:PassRole",
          "iam:CreateServiceLinkedRole"
        ]
        Resource = [
          "arn:aws:iam::${var.AWSAccount}:role/AmazonSagemakerCanvasBedrockRole*",
          "arn:aws:iam::${var.AWSAccount}:role/service-role/AmazonSageMaker*"
        ]
      },
      {
        Sid    = "SageMakerStudioAccess"
        Effect = "Allow"
        Action = [
          "sagemaker:CreatePresignedDomainUrl",
          "sagemaker:DescribeDomain",
          "sagemaker:DescribeUserProfile",
          "sagemaker:ListDomains",
          "sagemaker:ListUserProfiles",
          "sagemaker:CreateApp",
          "sagemaker:DeleteApp",
          "sagemaker:DescribeApp"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy" "sagemaker_parameter_store_access" {
  name = "${var.DeployName}-sagemaker-parameter-store-access"
  role = aws_iam_role.sagemaker_execution_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowParameterStoreRead"
        Effect = "Allow"
        Action = [
          "ssm:GetParameter",
          "ssm:GetParameters",
          "ssm:GetParametersByPath"
        ]
        Resource = [
          "arn:aws:ssm:us-east-1:${var.AWSAccount}:parameter/spge-titan/*"
        ]
      },
      {
        Sid    = "AllowParameterStoreList"
        Effect = "Allow"
        Action = [
          "ssm:DescribeParameters"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_sagemaker_domain" "sagemaker-studio" {
  domain_name = "${var.DeployName}-sagemaker-studio"
  auth_mode   = "IAM"
  vpc_id      = data.aws_vpc.AppVPC.id
  subnet_ids  = [data.aws_subnet.SageMakerSubnet.id]

  default_user_settings {
    execution_role = aws_iam_role.sagemaker_execution_role.arn
  }
}


resource "aws_sagemaker_user_profile" "user-profile" {
  domain_id         = aws_sagemaker_domain.sagemaker-studio.id
  user_profile_name = "${var.DeployName}-user-profile"

  # User-specific settings can override domain defaults if needed
  user_settings {
    execution_role = aws_iam_role.sagemaker_execution_role.arn
  }
}

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      Admin-email = var.TagContact
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
      name        = var.DeployName # To satisfy AWS role constraints
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
