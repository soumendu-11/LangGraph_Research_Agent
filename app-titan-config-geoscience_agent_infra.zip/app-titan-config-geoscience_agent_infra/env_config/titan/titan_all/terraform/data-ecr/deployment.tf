variable "Environment" {}
variable "ProjectName" {}
variable "ProjectBu" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

###########################
### ECR Repository
###########################

resource "aws_ecr_repository" "DataECR" {
  name                 = "spge-${var.ProjectName}-${var.Environment}-data/snowpark"
  image_tag_mutability = "IMMUTABLE_WITH_EXCLUSION"
  image_tag_mutability_exclusion_filter {
    filter      = "latest*"
    filter_type = "WILDCARD"
  }

  image_scanning_configuration {
    scan_on_push = false
  }

  tags = {
    Name = "spge-${var.ProjectName}-${var.Environment}-data/snowpark"
  }

  lifecycle {
    ignore_changes = [tags, tags_all]
  }
}

resource "aws_ecr_lifecycle_policy" "DataECRConfigLifecycle" {
  repository = aws_ecr_repository.DataECR.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Keep latest"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["v"]
          countType     = "imageCountMoreThan"
          countNumber   = 1
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep last 5"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 6
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

###########################
### Geoscience Agent ECR Repository
###########################

resource "aws_ecr_repository" "GeoscienceAgentECR" {
  name                 = "spge-${var.ProjectName}-${var.Environment}-geoscience-agent"
  image_tag_mutability = "IMMUTABLE_WITH_EXCLUSION"
  image_tag_mutability_exclusion_filter {
    filter      = "latest*"
    filter_type = "WILDCARD"
  }

  image_scanning_configuration {
    scan_on_push = false
  }

  tags = {
    Name = "spge-${var.ProjectName}-${var.Environment}-geoscience-agent"
  }
}

resource "aws_ecr_lifecycle_policy" "GeoscienceAgentECRLifecycle" {
  repository = aws_ecr_repository.GeoscienceAgentECR.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "Keep latest"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["v"]
          countType     = "imageCountMoreThan"
          countNumber   = 1
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "Keep last 5"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 6
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
