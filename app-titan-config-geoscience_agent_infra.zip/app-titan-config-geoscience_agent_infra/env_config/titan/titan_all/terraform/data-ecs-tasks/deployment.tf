variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "AppHealthCheckPath" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

variable "AppPort" {}
variable "AppCount" {}
variable "FargateCpuUnits" {}
variable "FargateMemoryMb" {}
variable "ECSPostgresPort" {}
variable "ECSPostgresSubnets" {}

variable "ITSgName" {}
variable "ITServerlessSgName" {}
variable "NumberOfAZs" {}

variable "AppVPC" {}
variable "AWSRegionShort" {}
variable "AppSubnetA" {}
variable "AppSubnetB" {}

# MLflow-specific variables
variable "MLflowPort" {
  default = 3000
}
variable "MLflowCpuUnits" {
  default = 512
}
variable "MLflowMemoryMb" {
  default = 1024
}
variable "MLflowImage" {
  default = "ghcr.io/mlflow/mlflow:v2.9.2"
}

# Geoscience Agent variables
variable "GeoscienceAgentPort" {
  default = 3000
}
variable "GeoscienceAgentCpuUnits" {
  default = 512
}
variable "GeoscienceAgentMemoryMb" {
  default = 1024
}
variable "GeoscienceAgentImage" {
  default = "975050171513.dkr.ecr.us-east-1.amazonaws.com/spge-titan-dev-geoscience-agent:v1.0.0"
}

###########################
locals {
  EnvLower               = lower(var.Environment)
  ECSPostgresSubnetsList = split(",", var.ECSPostgresSubnets)
}

#####################
### Compute (ECS)
#####################

// MLflow Security Group
resource "aws_security_group" "mlflow" {
  name        = "${var.DeployName}-mlflow-sg"
  description = "Security group for MLflow ECS tasks"
  vpc_id      = data.aws_vpc.AppVPC.id

  ingress {
    description = "Allow traffic from VPC to MLflow"
    from_port   = var.MLflowPort
    to_port     = var.MLflowPort
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }

  egress {
    description = "Allow traffic from MLflow to Postgres"
    from_port   = var.ECSPostgresPort
    to_port     = var.ECSPostgresPort
    protocol    = "tcp"
    cidr_blocks = local.ECSPostgresSubnetsList
  }
}

// MLflow Target Group
resource "aws_lb_target_group" "mlflow" {
  name        = "${var.DeployName}-tg-mlflow"
  port        = var.MLflowPort
  protocol    = "HTTP"
  vpc_id      = data.aws_vpc.AppVPC.id
  target_type = "ip"

  health_check {
    enabled             = true
    healthy_threshold   = 2
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
    path                = "/mlflow/"
    protocol            = "HTTP"
    matcher             = "200"
  }

  deregistration_delay = 30
}

// MLflow Listener Rule (HTTPS)
resource "aws_lb_listener_rule" "mlflow" {
  listener_arn = data.aws_lb_listener.EdgeHTTPSListener.arn
  priority     = 1

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.mlflow.arn
  }

  condition {
    path_pattern {
      values = ["/mlflow", "/mlflow/*", "/api/2.0/mlflow/*"]
    }
  }
}

resource "aws_lb_listener_rule" "TransformMlFlowPath" {
  listener_arn = data.aws_lb_listener.EdgeHTTPListener.arn
  priority     = 4
  condition {
    path_pattern {
      values = [
        "/spge-${var.ProjectName}-api-stage/mlflow/*",
        "*/mlflow/*",
        "/mlflow/",
        "/spge-${var.ProjectName}-api-stage/mlflow"
      ]
    }
  }

  transform {
    type = "url-rewrite"
    url_rewrite_config {
      rewrite {
        regex   = "/spge-${var.ProjectName}-api-stage"
        replace = ""
      }
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.mlflow.arn
  }
}

// MLflow Listener Rule (HTTP) - for internal service-to-service API calls
resource "aws_lb_listener_rule" "mlflow_http" {
  listener_arn = data.aws_lb_listener.EdgeHTTPListener.arn
  priority     = 7

  condition {
    path_pattern {
      values = ["/api/2.0/mlflow/*", "/mlflow", "/mlflow/*"]
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.mlflow.arn
  }
}

resource "aws_iam_role" "mlflow" {
  name               = "${var.DeployName}-mlflow-access-role"
  assume_role_policy = data.aws_iam_policy_document.assume_role_policy_ecs.json
}

resource "aws_iam_role" "ECS" {
  name               = "${var.DeployName}-ecs-execution-role"
  assume_role_policy = data.aws_iam_policy_document.assume_role_policy_ecs.json
}

resource "aws_iam_role_policy_attachment" "ecs_execution_policy" {
  role       = aws_iam_role.ECS.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}

resource "aws_iam_role_policy" "ecs_logs_policy" {
  name = "${var.DeployName}-ecs-logs-policy"
  role = aws_iam_role.ECS.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = [
          "arn:aws:logs:${var.AWSRegion}:*:log-group:/ecs/${var.DeployName}-mlflow*",
          "arn:aws:logs:${var.AWSRegion}:*:log-group:/ecs/${var.DeployName}-geoscience-agent*"
        ]
      }
    ]
  })
}

// MLflow Task
resource "aws_ecs_task_definition" "MLflowTask" {
  family                   = "${var.DeployName}-mlflow-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.MLflowCpuUnits
  memory                   = var.MLflowMemoryMb
  task_role_arn            = aws_iam_role.mlflow.arn
  execution_role_arn       = aws_iam_role.ECS.arn

  container_definitions = <<DEFINITION
    [
      {
        "name": "${var.DeployName}-mlflow-container",
        "image": "${var.MLflowImage}",
        "cpu": ${var.MLflowCpuUnits},
        "memory": ${var.MLflowMemoryMb},
        "essential": true,
        "command": [
          "mlflow",
          "server",
          "--host", "0.0.0.0",
          "--port", "${var.MLflowPort}",
          "--static-prefix", "/mlflow",
          "--backend-store-uri", "file:///mlflow/mlruns",
          "--default-artifact-root", "file:///mlflow/artifacts"
        ],
        "portMappings": [
          {
            "containerPort": ${var.MLflowPort},
            "hostPort": ${var.MLflowPort},
            "protocol": "tcp"
          }
        ],
        "logConfiguration": {
          "logDriver": "awslogs",
          "options": {
            "awslogs-group": "/ecs/${var.DeployName}-mlflow",
            "awslogs-region": "${var.AWSRegion}",
            "awslogs-stream-prefix": "mlflow",
            "awslogs-create-group": "true"
          }
        }
      }
    ]
  DEFINITION


  runtime_platform {
    operating_system_family = "LINUX"
  }

  lifecycle {
    ignore_changes = [container_definitions, cpu, memory]
  }
}

// ECS Service
resource "aws_ecs_service" "mlflow_service" {
  name            = "${var.DeployName}-mlflow-service"
  cluster         = data.aws_ecs_cluster.existing.id
  task_definition = aws_ecs_task_definition.MLflowTask.arn
  desired_count   = 1
  launch_type     = "FARGATE"

  network_configuration {
    subnets = [
      data.aws_subnet.AppSubnetA.id,
      data.aws_subnet.AppSubnetB.id
    ]
    security_groups = [
      aws_security_group.mlflow.id,
      data.aws_security_group.App.id,
      data.aws_security_group.ITSG.id,
      data.aws_security_group.ITServerlessSG.id
    ]
    assign_public_ip = true
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.mlflow.arn
    container_name   = "${var.DeployName}-mlflow-container"
    container_port   = var.MLflowPort
  }

  depends_on = [
    data.aws_lb_listener.EdgeHTTPSListener,
    aws_lb_target_group.mlflow
  ]

  lifecycle {
    ignore_changes = [desired_count, task_definition]
  }
}

#####################
### Geoscience Agent
#####################

// Geoscience Agent Security Group
resource "aws_security_group" "geoscience_agent" {
  name        = "${var.DeployName}-geoscience-agent-sg"
  description = "Security group for Geoscience Agent ECS tasks"
  vpc_id      = data.aws_vpc.AppVPC.id

  ingress {
    description = "Allow traffic from VPC"
    from_port   = var.GeoscienceAgentPort
    to_port     = var.GeoscienceAgentPort
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }

  egress {
    description = "Allow all outbound traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${var.DeployName}-geoscience-agent-sg"
  }
}

// Geoscience Agent IAM Role
resource "aws_iam_role" "geoscience_agent" {
  name               = "${var.DeployName}-geoscience-agent-role"
  assume_role_policy = data.aws_iam_policy_document.assume_role_policy_ecs.json

  tags = {
    Name = "${var.DeployName}-geoscience-agent-role"
  }
}

// DynamoDB policy for Geoscience Agent
resource "aws_iam_role_policy" "geoscience_agent_dynamodb" {
  name = "${var.DeployName}-geoscience-agent-dynamodb-policy"
  role = aws_iam_role.geoscience_agent.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "dynamodb:GetItem",
          "dynamodb:PutItem",
          "dynamodb:UpdateItem",
          "dynamodb:DeleteItem",
          "dynamodb:Query",
          "dynamodb:Scan"
        ]
        Resource = [
          "arn:aws:dynamodb:${var.AWSRegion}:${data.aws_caller_identity.Me.account_id}:table/spge-${var.ProjectName}-state-management"
        ]
      }
    ]
  })
}

// Bedrock policy for Geoscience Agent
resource "aws_iam_role_policy" "geoscience_agent_bedrock" {
  name = "${var.DeployName}-geoscience-agent-bedrock-policy"
  role = aws_iam_role.geoscience_agent.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream"
        ]
        Resource = [
          "arn:aws:bedrock:${var.AWSRegion}::foundation-model/*",
          "arn:aws:bedrock:${var.AWSRegion}:${data.aws_caller_identity.Me.account_id}:inference-profile/*"
        ]
      }
    ]
  })
}

// Geoscience Agent Target Group
resource "aws_lb_target_group" "geoscience_agent" {
  name        = "${var.DeployName}-tg-geo-agent"
  port        = var.GeoscienceAgentPort
  protocol    = "HTTP"
  vpc_id      = data.aws_vpc.AppVPC.id
  target_type = "ip"

  health_check {
    enabled             = true
    healthy_threshold   = 2
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
    path                = "/health"
    protocol            = "HTTP"
    matcher             = "200"
  }

  deregistration_delay = 30

  tags = {
    Name = "${var.DeployName}-tg-geo-agent"
  }
}

// Geoscience Agent Listener Rule (HTTPS)
resource "aws_lb_listener_rule" "geoscience_agent" {
  listener_arn = data.aws_lb_listener.EdgeHTTPSListener.arn
  priority     = 5

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.geoscience_agent.arn
  }

  condition {
    path_pattern {
      values = ["/geoscience-agent", "/geoscience-agent/*"]
    }
  }
}

// Geoscience Agent Listener Rule (HTTP) - with URL rewrite for API Gateway
resource "aws_lb_listener_rule" "geoscience_agent_http" {
  listener_arn = data.aws_lb_listener.EdgeHTTPListener.arn
  priority     = 6

  condition {
    path_pattern {
      values = ["/spge-${var.ProjectName}-api-stage/geoscience-agent", "/spge-${var.ProjectName}-api-stage/geoscience-agent/*"]
    }
  }

  transform {
    type = "url-rewrite"
    url_rewrite_config {
      rewrite {
        regex   = "^/spge-${var.ProjectName}-api-stage/geoscience-agent"
        replace = ""
      }
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.geoscience_agent.arn
  }
}

// Geoscience Agent Task Definition
resource "aws_ecs_task_definition" "geoscience_agent" {
  family                   = "${var.DeployName}-geoscience-agent-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.GeoscienceAgentCpuUnits
  memory                   = var.GeoscienceAgentMemoryMb
  task_role_arn            = aws_iam_role.geoscience_agent.arn
  execution_role_arn       = aws_iam_role.ECS.arn

  container_definitions = jsonencode([
    {
      name      = "${var.DeployName}-geoscience-agent-container"
      image     = var.GeoscienceAgentImage
      cpu       = var.GeoscienceAgentCpuUnits
      memory    = var.GeoscienceAgentMemoryMb
      essential = true
      portMappings = [
        {
          containerPort = var.GeoscienceAgentPort
          hostPort      = var.GeoscienceAgentPort
          protocol      = "tcp"
        }
      ]
      environment = [
        {
          name  = "USE_DYNAMODB"
          value = "false"
        },
        {
          name  = "DYNAMODB_TABLE_NAME"
          value = "spge-${var.ProjectName}-state-management"
        },
        {
          name  = "AWS_REGION"
          value = var.AWSRegion
        },
        {
          name  = "MLFLOW_TRACKING_URI"
          value = "http://${data.aws_lb.Edge.dns_name}"
        },
        {
          name  = "ROOT_PATH"
          value = "/spge-${var.ProjectName}-api-stage/geoscience-agent"
        }
      ]
      logConfiguration = {
        logDriver = "awslogs"
        options = {
          "awslogs-group"         = "/ecs/${var.DeployName}-geoscience-agent"
          "awslogs-region"        = var.AWSRegion
          "awslogs-stream-prefix" = "geoscience-agent"
          "awslogs-create-group"  = "true"
        }
      }
    }
  ])

  runtime_platform {
    operating_system_family = "LINUX"
  }

  tags = {
    Name = "${var.DeployName}-geoscience-agent-task"
  }
}

// Geoscience Agent ECS Service
resource "aws_ecs_service" "geoscience_agent" {
  name            = "${var.DeployName}-geoscience-agent-service"
  cluster         = data.aws_ecs_cluster.existing.id
  task_definition = aws_ecs_task_definition.geoscience_agent.arn
  desired_count   = 1
  launch_type     = "FARGATE"

  network_configuration {
    subnets = [
      data.aws_subnet.AppSubnetA.id,
      data.aws_subnet.AppSubnetB.id
    ]
    security_groups = [
      aws_security_group.geoscience_agent.id,
      data.aws_security_group.App.id,
      data.aws_security_group.ITSG.id,
      data.aws_security_group.ITServerlessSG.id
    ]
    assign_public_ip = true
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.geoscience_agent.arn
    container_name   = "${var.DeployName}-geoscience-agent-container"
    container_port   = var.GeoscienceAgentPort
  }

  depends_on = [
    data.aws_lb_listener.EdgeHTTPSListener,
    aws_lb_target_group.geoscience_agent
  ]

  lifecycle {
    ignore_changes = [desired_count, task_definition]
  }
}

####################
### Data Sources
####################

data "aws_lb" "Edge" {
  name = "${var.DeployName}-edge"
}

data "aws_lb_listener" "EdgeHTTPListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 80
}

data "aws_lb_listener" "EdgeHTTPSListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 443
}

data "aws_caller_identity" "Me" {}

data "aws_ecs_cluster" "existing" {
  cluster_name = "${var.DeployName}-cluster"
}

data "aws_vpc" "AppVPC" {
  filter {
    name   = "tag:Name"
    values = [var.AppVPC]
  }
}

data "aws_security_group" "App" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = "${var.DeployName}-app-sg"
}

data "aws_security_group" "ITSG" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = var.ITSgName
}

data "aws_security_group" "ITServerlessSG" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = var.ITServerlessSgName
}

data "aws_subnet" "AppSubnetA" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetA]
  }
}

data "aws_subnet" "AppSubnetB" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetB]
  }
}

data "aws_iam_policy_document" "assume_role_policy_ecs" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

####################
### Outputs
####################


#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}

provider "aws" {
  region  = var.AWSRegion
  alias   = "aws-iam-users"
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      Admin-email = var.TagContact
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
      name        = var.DeployName # To satisfy AWS role constraints
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
