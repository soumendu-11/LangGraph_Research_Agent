variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}


variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

######################################
### App Key stored in KMS
###
### Add Keys for Titan as needed here
######################################
# Example
# resource "aws_kms_key" "key" {
#   description = "Symmetric Key used to encrypt Titan traffic"
#   enable_key_rotation = true
#   rotation_period_in_days = 90

#   tags = {
#     name = "${var.DeployName}-key"
#   }
# }

# resource "aws_kms_alias" "key_alias" {
#   name = "alias/${var.DeployName}-key"
#   target_key_id = aws_kms_key.key.id
# }

# resource "aws_kms_key_policy" "key_store_policy" {
#   key_id = aws_kms_key.key.id
#   policy = jsonencode({
#     Version = "2012-10-17"
#     Id = "${var.DeployName}-key"
#     Statement = [
#       {
#         Sid = "Allow administration of the key"
#         Effect = "Allow"
#         Principal = {
#           AWS = "arn:aws:iam::${data.aws_caller_identity.Me.account_id}:root"
#         }
#         Action = [
#           "kms:*"
#         ]
#         Resource = "*"
#       },
#       {
#         Sid = "Allow use of the key"
#         Effect = "Allow"
#         Principal = {
#           AWS = "arn:aws:iam::${data.aws_caller_identity.Me.account_id}:role/${data.aws_iam_role.ECS.id}"
#         }
#         Action = [
#           "kms:Encrypt",
#           "kms:Decrypt",
#           "kms:ReEncrypt*",
#           "kms:GenerateDataKey*",
#           "kms:DescribeKey"
#         ]
#         Resource = "*"
#       }
#     ]
#   })
# }

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

data "aws_iam_role" "ECS" {
  name = "${var.DeployName}-ecs"
}

####################
### Outputs
####################

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
