variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "APIDomainName" {}

variable "AppVPC" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

variable "OktaIssuer" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

#############################
### API Gateway
#############################
resource "aws_apigatewayv2_api" "Api" {
  name          = "${var.DeployName}-http-api"
  protocol_type = "HTTP"

  tags = {
    name       = "${var.DeployName}-http-api"
    FmsEnabled = "True"
  }
}

resource "aws_apigatewayv2_authorizer" "JWTAuthorizer" {
  name             = "${var.DeployName}-jwt-authorizer"
  api_id           = aws_apigatewayv2_api.Api.id
  authorizer_type  = "JWT"
  identity_sources = ["$request.header.Authorization"]
  jwt_configuration {
    issuer   = var.OktaIssuer
    audience = ["api://spglobal"]
  }
}

#############################
### MLflow Integration
#############################
resource "aws_apigatewayv2_vpc_link" "MlflowVpcLink" {
  name               = "${var.DeployName}-mlflow-vpc-link"
  security_group_ids = [data.aws_security_group.App.id]
  subnet_ids         = data.aws_lb.Edge.subnets

  tags = {
    name = "${var.DeployName}-mlflow-vpc-link"
  }
}

resource "aws_apigatewayv2_integration" "MlflowIntegration" {
  api_id             = aws_apigatewayv2_api.Api.id
  integration_type   = "HTTP_PROXY"
  integration_method = "ANY"
  integration_uri    = data.aws_lb_listener.EdgeHttpListener.arn
  connection_type    = "VPC_LINK"
  connection_id      = aws_apigatewayv2_vpc_link.MlflowVpcLink.id
}

resource "aws_apigatewayv2_route" "MlflowRoute" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "ANY /mlflow/{proxy+}"
  target    = "integrations/${aws_apigatewayv2_integration.MlflowIntegration.id}"
}

resource "aws_apigatewayv2_route" "MlflowRootRoute" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "GET /mlflow"
  target    = "integrations/${aws_apigatewayv2_integration.MlflowIntegration.id}"
}

# MLflow API routes - UI calls /api/2.0/mlflow/* for data
resource "aws_apigatewayv2_route" "MlflowApiRoute" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "ANY /api/2.0/mlflow/{proxy+}"
  target    = "integrations/${aws_apigatewayv2_integration.MlflowIntegration.id}"
}


#############################
### Data Product Integration
#############################
resource "aws_apigatewayv2_vpc_link" "data-vpc-link" {
  name               = "${var.DeployName}-data-product-vpc-link"
  security_group_ids = [data.aws_security_group.App.id]
  subnet_ids         = data.aws_lb.Edge.subnets

  tags = {
    name = "${var.DeployName}-data-product-vpc-link"
  }
}

resource "aws_apigatewayv2_integration" "data-api-integration" {
  api_id             = aws_apigatewayv2_api.Api.id
  integration_type   = "HTTP_PROXY"
  integration_method = "ANY"
  integration_uri    = data.aws_lb_listener.EdgeHttpListener.arn
  connection_type    = "VPC_LINK"
  connection_id      = aws_apigatewayv2_vpc_link.data-vpc-link.id
}

resource "aws_apigatewayv2_route" "data-api-route" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "ANY /titan-data-products/{proxy+}"
  target    = "integrations/${aws_apigatewayv2_integration.data-api-integration.id}"
}

resource "aws_apigatewayv2_route" "data-api-root-route" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "GET /titan-data-products"
  target    = "integrations/${aws_apigatewayv2_integration.data-api-integration.id}"
}

#############################
### UserService Integration
#############################
resource "aws_apigatewayv2_vpc_link" "UserServiceVpcLink" {
  name               = "${var.DeployName}-user-service-vpc-link"
  security_group_ids = [data.aws_security_group.App.id]
  subnet_ids         = data.aws_lb.Edge.subnets

  tags = {
    name = "${var.DeployName}-user-service-vpc-link"
  }
}

resource "aws_apigatewayv2_integration" "UserServiceIntegration" {
  api_id             = aws_apigatewayv2_api.Api.id
  integration_type   = "HTTP_PROXY"
  integration_method = "POST"
  integration_uri    = data.aws_lb_listener.EdgeHttpListener.arn
  connection_type    = "VPC_LINK"
  connection_id      = aws_apigatewayv2_vpc_link.UserServiceVpcLink.id
}

resource "aws_apigatewayv2_route" "UserServiceRoute" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "POST /user"
  target    = "integrations/${aws_apigatewayv2_integration.UserServiceIntegration.id}"
}

#############################
### Geoscience Agent Integration
#############################
resource "aws_apigatewayv2_vpc_link" "GeoscienceAgentVpcLink" {
  name               = "${var.DeployName}-geoscience-agent-vpc-link"
  security_group_ids = [data.aws_security_group.App.id]
  subnet_ids         = data.aws_lb.Edge.subnets

  tags = {
    name = "${var.DeployName}-geoscience-agent-vpc-link"
  }
}

resource "aws_apigatewayv2_integration" "GeoscienceAgentIntegration" {
  api_id             = aws_apigatewayv2_api.Api.id
  integration_type   = "HTTP_PROXY"
  integration_method = "ANY"
  integration_uri    = data.aws_lb_listener.EdgeHttpListener.arn
  connection_type    = "VPC_LINK"
  connection_id      = aws_apigatewayv2_vpc_link.GeoscienceAgentVpcLink.id
}

resource "aws_apigatewayv2_route" "GeoscienceAgentRoute" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "ANY /geoscience-agent/{proxy+}"
  target    = "integrations/${aws_apigatewayv2_integration.GeoscienceAgentIntegration.id}"
}

resource "aws_apigatewayv2_route" "GeoscienceAgentRootRoute" {
  api_id    = aws_apigatewayv2_api.Api.id
  route_key = "GET /geoscience-agent"
  target    = "integrations/${aws_apigatewayv2_integration.GeoscienceAgentIntegration.id}"
}

#############################
### Deployment and Stage
#############################
resource "aws_apigatewayv2_deployment" "ApiDeployment" {
  api_id      = aws_apigatewayv2_api.Api.id
  description = "HTTP Api Deployment, created by Terraform"

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [
    aws_apigatewayv2_api.Api,
    aws_apigatewayv2_route.data-api-root-route,
    aws_apigatewayv2_route.data-api-route,
    aws_apigatewayv2_route.MlflowRootRoute,
    aws_apigatewayv2_route.MlflowRoute,
    aws_apigatewayv2_route.UserServiceRoute,
    aws_apigatewayv2_route.GeoscienceAgentRoute,
    aws_apigatewayv2_route.GeoscienceAgentRootRoute
  ]
}

resource "aws_apigatewayv2_stage" "ApiStage" {
  api_id        = aws_apigatewayv2_api.Api.id
  deployment_id = aws_apigatewayv2_deployment.ApiDeployment.id
  name          = "spge-${var.ProjectName}-api-stage"

  depends_on = [
    aws_apigatewayv2_api.Api,
    aws_apigatewayv2_deployment.ApiDeployment
  ]
}

resource "aws_apigatewayv2_domain_name" "ApiDomainName" {
  domain_name  = var.APIDomainName
  routing_mode = "API_MAPPING_ONLY"

  domain_name_configuration {
    certificate_arn = data.aws_acm_certificate.DomainCertificate.arn
    endpoint_type   = "REGIONAL"
    security_policy = "TLS_1_2"
  }
}

resource "aws_apigatewayv2_api_mapping" "ApiMapping" {
  api_id      = aws_apigatewayv2_api.Api.id
  domain_name = aws_apigatewayv2_domain_name.ApiDomainName.domain_name
  stage       = aws_apigatewayv2_stage.ApiStage.id

  depends_on = [
    aws_apigatewayv2_api.Api,
    aws_apigatewayv2_domain_name.ApiDomainName,
    aws_apigatewayv2_stage.ApiStage
  ]
}

#############################
### Cloudfront
#############################
resource "aws_cloudfront_distribution" "ApiCloudfront" {
  enabled         = true
  is_ipv6_enabled = true
  comment         = "${var.DeployName} API Gateway"
  price_class     = "PriceClass_100"

  aliases = [var.APIDomainName]

  origin {
    domain_name = replace(aws_apigatewayv2_api.Api.api_endpoint, "https://", "")
    origin_id   = aws_apigatewayv2_api.Api.id

    custom_origin_config {
      http_port              = 80
      https_port             = 443
      origin_protocol_policy = "https-only"
      origin_ssl_protocols   = ["TLSv1.2"]
    }
  }

  default_cache_behavior {
    allowed_methods  = ["GET", "HEAD", "OPTIONS", "PUT", "POST", "PATCH", "DELETE"]
    cached_methods   = ["GET", "HEAD"]
    target_origin_id = aws_apigatewayv2_api.Api.id

    forwarded_values {
      query_string = true
      cookies {
        forward = "none"
      }
    }

    viewer_protocol_policy = "redirect-to-https"
    min_ttl                = 0
    default_ttl            = 3600
    max_ttl                = 86400
    compress               = true
  }

  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }

  viewer_certificate {
    acm_certificate_arn      = data.aws_acm_certificate.CloudFrontCertificate.arn
    ssl_support_method       = "sni-only"
    minimum_protocol_version = "TLSv1.2_2021"
  }

  tags = {
    name       = "${var.DeployName}-api-gateway-distribution"
    FmsEnabled = "True"
  }

  lifecycle {
    ignore_changes = [web_acl_id]
  }
}

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

data "aws_vpc" "AppVPC" {
  filter {
    name   = "tag:Name"
    values = [var.AppVPC]
  }
}

data "aws_security_group" "App" {
  name   = "${var.DeployName}-app-sg"
  vpc_id = data.aws_vpc.AppVPC.id
}

data "aws_lb" "Edge" {
  name = "${var.DeployName}-edge"
}

data "aws_lb_listener" "EdgeHttpListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 80
}

data "aws_acm_certificate" "DomainCertificate" {
  domain      = var.APIDomainName
  statuses    = ["ISSUED"]
  most_recent = true
}

# CloudFront requires certificates in us-east-1
data "aws_acm_certificate" "CloudFrontCertificate" {
  domain      = var.APIDomainName
  provider    = aws.us-east-1
  statuses    = ["ISSUED"]
  most_recent = true
}

####################
### Outputs
####################

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}

# CloudFront requires ACM certificates in us-east-1 region
provider "aws" {
  alias   = "us-east-1"
  region  = "us-east-1"
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
