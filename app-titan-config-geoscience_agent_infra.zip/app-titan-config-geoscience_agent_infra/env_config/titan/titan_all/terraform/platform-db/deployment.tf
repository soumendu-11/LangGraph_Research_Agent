variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}


variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

####################
### Dynamo DB Table
####################
resource "aws_dynamodb_table" "basic-dynamodb-table" {
  name           = "spge-${var.ProjectName}-user-db"
  hash_key       = "id"
  read_capacity  = 20
  write_capacity = 20

  attribute {
    name = "id"
    type = "S"
  }

  tags = {
    name = "${var.DeployName}-user-db"
  }
}

resource "aws_dynamodb_table" "state-management-table" {
  name           = "spge-${var.ProjectName}-geoscience-state-management"
  hash_key       = "thread_id"
  read_capacity  = 20
  write_capacity = 20

  attribute {
    name = "thread_id"
    type = "S"
  }

  tags = {
    name = "${var.DeployName}-geoscience-state-management"
  }
}

resource "aws_iam_role" "dynamodb-access-role" {
  name               = "${var.DeployName}-dynamodb-access-role"
  assume_role_policy = data.aws_iam_policy_document.assume_role_policy_dynamodb.json

  tags = {
    name = "${var.DeployName}-dynamodb-access-role"
  }
}

resource "aws_iam_role_policy" "dynamodb-access-policy" {
  role   = aws_iam_role.dynamodb-access-role.id
  policy = data.aws_iam_policy_document.access_dynamodb_policy.json
}

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

data "aws_iam_policy_document" "assume_role_policy_dynamodb" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}


data "aws_iam_policy_document" "access_dynamodb_policy" {
  statement {
    actions = [
      "dynamodb:GetItem",
      "dynamodb:PutItem",
      "dynamodb:UpdateItem",
      "dynamodb:DeleteItem",
    ]

    resources = [
      aws_dynamodb_table.basic-dynamodb-table.arn,
      "${aws_dynamodb_table.basic-dynamodb-table.arn}/index/*",
    ]
  }
}

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
