variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "AppHealthCheckPath" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

variable "AppPort" {}
variable "AppCount" {}
variable "FargateCpuUnits" {}
variable "FargateMemoryMb" {}

variable "ITSgName" {}
variable "ITServerlessSgName" {}
variable "NumberOfAZs" {}

variable "AppVPC" {}
variable "AWSRegionShort" {}
variable "AppSubnetA" {}
variable "AppSubnetB" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

###########################
### ECR Repository
###########################

resource "aws_ecr_repository" "UserServiceECR" {
  name                 = "spge-${var.ProjectName}-${var.Environment}-platform/user-service-ecr"
  image_tag_mutability = "IMMUTABLE_WITH_EXCLUSION"
  image_tag_mutability_exclusion_filter {
    filter      = "latest*"
    filter_type = "WILDCARD"
  }

  image_scanning_configuration {
    scan_on_push = true
  }

  tags = {
    Name = "spge-${var.ProjectName}-${var.Environment}-platform/user-service-ecr"
  }
}

resource "aws_ecr_lifecycle_policy" "UserServiceECRLifecycle" {
  repository = aws_ecr_repository.UserServiceECR.name

  policy = jsonencode({
    rules = [
      {
        rulePriority = 1
        description  = "keep latest"
        selection = {
          tagStatus     = "tagged"
          tagPrefixList = ["latest"]
          countType     = "imageCountMoreThan"
          countNumber   = 1
        }
        action = {
          type = "expire"
        }
      },
      {
        rulePriority = 2
        description  = "keep last 5"
        selection = {
          tagStatus   = "any"
          countType   = "imageCountMoreThan"
          countNumber = 6
        }
        action = {
          type = "expire"
        }
      }
    ]
  })
}



#######################
### Task Definition 
#######################
resource "aws_ecs_task_definition" "UserServiceTask" {
  family                   = "${var.DeployName}-app-user-service-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.FargateCpuUnits
  memory                   = var.FargateMemoryMb
  task_role_arn            = data.aws_iam_role.DynamoDbRole.arn
  execution_role_arn       = data.aws_iam_role.ECS.arn

  container_definitions = <<DEFINITION
    [
      {
        "name": "${var.DeployName}-user-service-container",
        "image": "${aws_ecr_repository.UserServiceECR.repository_url}:latest",
        "cpu": ${var.FargateCpuUnits},
        "memory": ${var.FargateMemoryMb},
        "essential": true,
        "environment": [
          { "name": "ASPNETCORE_URLS", "value": "http://0.0.0.0:${var.AppPort}" },
          { "name": "AWS_REGION", "value": "${var.AWSRegion}" },
          { 
            "name": "ASPNETCORE_ENVIRONMENT",
            "value": "${var.Environment == "dev" ? "Development" : var.Environment == "prod" ? "Production" : var.Environment == "qa" ? "Staging" : ""}"
          }
        ],
        "portMappings": [
          {
            "containerPort": ${var.AppPort},
            "hostPort": ${var.AppPort},
            "protocol": "tcp"
          }
        ]
      }
    ]
  DEFINITION

  runtime_platform {
    operating_system_family = "LINUX"
  }
}

#######################
### Target Group (ECS)
#######################
resource "aws_lb_target_group" "UserServiceTarget" {
  name = "spge-${var.ProjectName}-${var.Environment}-tg-user-service"
  health_check {
    path     = var.AppHealthCheckPath
    interval = 30
    protocol = "HTTP"
    port     = var.AppPort
    timeout  = 10
  }
  port        = var.AppPort
  protocol    = "HTTP"
  target_type = "ip"
  vpc_id      = data.aws_vpc.AppVPC.id

  lifecycle {
    create_before_destroy = true
  }

  tags = {
    name = "spge-${var.ProjectName}-${var.Environment}-tg-user-service"
  }
}

#####################
### Compute (ECS)
#####################
resource "aws_ecs_service" "UserService" {
  name                          = "${var.DeployName}-ecs-user-service"
  cluster                       = data.aws_ecs_cluster.App.id
  task_definition               = aws_ecs_task_definition.UserServiceTask.arn
  desired_count                 = var.AppCount
  launch_type                   = "FARGATE"
  availability_zone_rebalancing = "ENABLED"
  enable_execute_command        = true

  network_configuration {
    subnets = [
      data.aws_subnet.AppSubnetA.id,
      data.aws_subnet.AppSubnetB.id
    ]
    security_groups = [
      data.aws_security_group.App.id,
      data.aws_security_group.ITSG.id,
      data.aws_security_group.ITServerlessSG.id
    ]
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.UserServiceTarget.id
    container_name   = "${var.DeployName}-user-service-container"
    container_port   = var.AppPort
  }

  depends_on = [
    data.aws_lb_listener.EdgeHTTPSListener,
    aws_lb_target_group.UserServiceTarget
  ]

  propagate_tags = "TASK_DEFINITION"
}

#######################
### Listener Rules
#######################
resource "aws_lb_listener_rule" "UserServiceHttpTransformAndForward" {
  listener_arn = data.aws_lb_listener.EdgeHTTPListener.arn
  priority     = 3
  condition {
    path_pattern {
      values = [
        "/spge-${var.ProjectName}-api-stage/user/*",
        "*/user/*",
        "/user/",
        "/spge-${var.ProjectName}-api-stage/user"
      ]
    }
  }

  transform {
    type = "url-rewrite"
    url_rewrite_config {
      rewrite {
        regex   = "/spge-${var.ProjectName}-api-stage"
        replace = ""
      }
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.UserServiceTarget.arn
  }
}

resource "aws_lb_listener_rule" "UserServiceHttpsForward" {
  listener_arn = data.aws_lb_listener.EdgeHTTPSListener.arn
  priority     = 3

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.UserServiceTarget.arn
  }

  condition {
    path_pattern {
      values = ["/user", "/user/*"]
    }
  }
}

####################
### Data Sources
####################
data "aws_caller_identity" "Me" {}

// VPC
data "aws_vpc" "AppVPC" {
  filter {
    name   = "tag:Name"
    values = [var.AppVPC]
  }
}

// Security Groups
data "aws_security_group" "App" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = "${var.DeployName}-app-sg"
}

data "aws_security_group" "ITSG" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = var.ITSgName
}

data "aws_security_group" "ITServerlessSG" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = var.ITServerlessSgName
}

// Subnets
data "aws_subnet" "AppSubnetA" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetA]
  }
}

data "aws_subnet" "AppSubnetB" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetB]
  }
}

// Load Balancer
data "aws_lb" "Edge" {
  name = "${var.DeployName}-edge"
}

data "aws_lb_listener" "EdgeHTTPListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 80
}

data "aws_lb_listener" "EdgeHTTPSListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 443
}

// ECS
data "aws_ecs_cluster" "App" {
  cluster_name = "${var.DeployName}-cluster"
}

// IAM Roles
data "aws_iam_role" "DynamoDbRole" {
  name = "${var.DeployName}-dynamodb-access-role"
}

data "aws_iam_role" "ECS" {
  name = "${var.DeployName}-ecs"
}

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}

provider "aws" {
  region  = var.AWSRegion
  alias   = "aws-iam-users"
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      Admin-email = var.TagContact
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
      name        = var.DeployName # To satisfy AWS role constraints
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
