variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "AppHealthCheckPath" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

variable "AppPort" {}
variable "AppCount" {}
variable "FargateCpuUnits" {}
variable "FargateMemoryMb" {}

variable "ITSgName" {}
variable "ITServerlessSgName" {}
variable "NumberOfAZs" {}

variable "AppVPC" {}
variable "AWSRegionShort" {}
variable "AppSubnetA" {}
variable "AppSubnetB" {}


###########################
locals {
  EnvLower = lower(var.Environment)
}

#####################
### Compute (ECS)
#####################
data "aws_iam_role" "ECS" {
  name = "${var.DeployName}-ecs"
}

data "aws_secretsmanager_secret" "spge_titan_snowflake_keypair" {
  name = "spge/titan/${var.Environment}/snowflake_auth_v1"
}

# Allow the execution role to "read" the secret so it can inject it
resource "aws_iam_role_policy" "secrets_policy" {
  role = data.aws_iam_role.ECS.name
  policy = jsonencode({
    Version = "2012-10-17", Statement = [{
      Effect = "Allow", Action = "secretsmanager:GetSecretValue", Resource = [data.aws_secretsmanager_secret.spge_titan_snowflake_keypair.arn]
    }]
  })
}
resource "aws_iam_role_policy" "ecs_data_logs_policy" {
  name = "${var.DeployName}-ecs-data-api-logs-policy"
  role = data.aws_iam_role.ECS.name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "logs:CreateLogGroup",
          "logs:CreateLogStream",
          "logs:PutLogEvents"
        ]
        Resource = "arn:aws:logs:${var.AWSRegion}:*:log-group:/ecs/${var.DeployName}-data*"
      }
    ]
  })
}


resource "aws_ecs_task_definition" "titan-data-api-service-task" {
  family                   = "${var.DeployName}-data-api-service-task"
  network_mode             = "awsvpc"
  requires_compatibilities = ["FARGATE"]
  cpu                      = var.FargateCpuUnits
  memory                   = var.FargateMemoryMb
  execution_role_arn       = data.aws_iam_role.ECS.arn
  task_role_arn            = data.aws_iam_role.ECS.arn

  container_definitions = jsonencode([{
    name      = "${var.DeployName}-data-api-container"
    image     = "${data.aws_caller_identity.Me.account_id}.dkr.ecr.${var.AWSRegion}.amazonaws.com/spge-titan-${var.Environment}-data/snowpark:latest"
    cpu       = var.FargateCpuUnits
    memory    = var.FargateMemoryMb
    essential = true
    portMappings = [
      {
        containerPort = var.AppPort,
        hostPort      = var.AppPort
      }
    ]

    # Injecting Secret from Secrets Manager as an Env Var
    secrets = [{
      name      = "SNOWFLAKE_JSON_CREDS"
      valueFrom = data.aws_secretsmanager_secret.spge_titan_snowflake_keypair.arn
    }]

    runtime_platform = {
      operating_system_family = "LINUX"
    }

    logConfiguration = {
      logDriver = "awslogs"
      options = {
        "awslogs-group"         = "/ecs/${var.DeployName}-data",
        "awslogs-region"        = "${var.AWSRegion}",
        "awslogs-stream-prefix" = "ecs"
        "awslogs-create-group"  = "true"
      }
    }
  }])
}

// Data rest api Security Group
resource "aws_security_group" "titan-data-api-security-group" {
  name        = "${var.DeployName}-data-api-security-group"
  description = "Security group for Data REST api ECS tasks"
  vpc_id      = data.aws_vpc.AppVPC.id

  ingress {
    description = "Allow traffic from VPC to REST API"
    from_port   = var.AppPort
    to_port     = var.AppPort
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }
}


// Data REST API Target Group
resource "aws_lb_target_group" "titan-data-api-target-group" {
  name        = "${var.DeployName}-data-tg-grp"
  port        = var.AppPort
  protocol    = "HTTP"
  vpc_id      = data.aws_vpc.AppVPC.id
  target_type = "ip"

  health_check {
    enabled             = true
    healthy_threshold   = 2
    unhealthy_threshold = 3
    timeout             = 5
    interval            = 30
    path                = "/Home/HealthCheck"
    protocol            = "HTTP"
    matcher             = "200"
  }

  deregistration_delay = 30
}

// DATA REST API Listener Rule
resource "aws_lb_listener_rule" "titan-data-api-listener-rule" {
  listener_arn = data.aws_lb_listener.EdgeHTTPSListener.arn
  priority     = 2

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.titan-data-api-target-group.arn
  }

  condition {
    path_pattern {
      values = ["/titan-data-products", "/titan-data-products/*"]
    }
  }
}

resource "aws_lb_listener_rule" "TransformDataAPIPath" {
  listener_arn = data.aws_lb_listener.EdgeHTTPListener.arn
  priority     = 2
  condition {
    path_pattern {
      values = [
        "/spge-${var.ProjectName}-api-stage/titan-data-products/*",
        "*/titan-data-products/*",
        "/titan-data-products/",
        "/spge-${var.ProjectName}-api-stage/titan-data-products"
      ]
    }
  }

  transform {
    type = "url-rewrite"
    url_rewrite_config {
      rewrite {
        regex   = "/spge-${var.ProjectName}-api-stage"
        replace = ""
      }
    }
  }

  action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.titan-data-api-target-group.arn
  }
}


resource "aws_ecs_service" "titan-data-api-service" {
  name                          = "${var.DeployName}-data-api-ecs-service"
  cluster                       = data.aws_ecs_cluster.App.id
  task_definition               = aws_ecs_task_definition.titan-data-api-service-task.arn
  desired_count                 = var.AppCount
  launch_type                   = "FARGATE"
  availability_zone_rebalancing = "ENABLED"
  enable_execute_command        = true

  network_configuration {
    subnets = [
      data.aws_subnet.AppSubnetA.id,
      data.aws_subnet.AppSubnetB.id
    ]
    security_groups = [
      aws_security_group.titan-data-api-security-group.id,
      data.aws_security_group.App.id,
      data.aws_security_group.ITSG.id,
      data.aws_security_group.ITServerlessSG.id
    ]
    assign_public_ip = true # Set to false if using NAT Gateway
  }

  load_balancer {
    target_group_arn = aws_lb_target_group.titan-data-api-target-group.arn
    container_name   = "${var.DeployName}-data-api-container"
    container_port   = var.AppPort
  }

  depends_on = [
    data.aws_lb_listener.EdgeHTTPSListener,
    aws_lb_target_group.titan-data-api-target-group
  ]

  propagate_tags = "TASK_DEFINITION"
}


####################
### Data Sources
####################
data "aws_ecs_cluster" "App" {
  cluster_name = "${var.DeployName}-cluster"
}

data "aws_iam_policy_document" "assume_role_policy_ecs" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["ecs-tasks.amazonaws.com"]
    }
  }
}

data "aws_caller_identity" "Me" {}

data "aws_vpc" "AppVPC" {
  filter {
    name   = "tag:Name"
    values = [var.AppVPC]
  }
}

data "aws_security_group" "App" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = "${var.DeployName}-app-sg"
}

data "aws_security_group" "ITSG" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = var.ITSgName
}

data "aws_security_group" "ITServerlessSG" {
  vpc_id = data.aws_vpc.AppVPC.id
  name   = var.ITServerlessSgName
}

data "aws_subnet" "AppSubnetA" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetA]
  }
}

data "aws_subnet" "AppSubnetB" {
  vpc_id = data.aws_vpc.AppVPC.id
  filter {
    name   = "tag:Name"
    values = [var.AppSubnetB]
  }
}

data "aws_lb" "Edge" {
  name = "${var.DeployName}-edge"
}

data "aws_lb_listener" "EdgeHTTPListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 80
}

data "aws_lb_listener" "EdgeHTTPSListener" {
  load_balancer_arn = data.aws_lb.Edge.arn
  port              = 443
}

####################
### Outputs
####################

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}

provider "aws" {
  region  = var.AWSRegion
  alias   = "aws-iam-users"
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      Admin-email = var.TagContact
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
      name        = var.DeployName # To satisfy AWS role constraints
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
