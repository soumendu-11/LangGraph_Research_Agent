variable "Environment" {}
variable "ProjectBu" {}
variable "ProjectName" {}
variable "DeployName" {}
variable "AWSRegion" {}
variable "ComponentName" {}

variable "UIDomainName" {}

variable "TagContact" {}
variable "TagOwner" {}
variable "TagAppId" {}
variable "TagTechnology" {}
variable "TagService" {}
variable "TagEnvironment" {}

variable "IsLocal" {}
variable "LocalAWSProfile" {}

###########################
locals {
  EnvLower = lower(var.Environment)
}

###########################
### S3 Bucket
###########################

resource "aws_s3_bucket" "s3_instance" {
  bucket = "${var.DeployName}-ui-s3"

  lifecycle {
    # Prevent accidental deletion
    prevent_destroy = true
  }

  tags = {
    Name = "${var.DeployName}/ui-s3"
  }
}

resource "aws_s3_bucket_lifecycle_configuration" "s3_lifecycle_config" {
  bucket = aws_s3_bucket.s3_instance.id

  rule {
    id     = "c7n-rule"
    status = "Enabled"
    noncurrent_version_expiration {
      noncurrent_days = 14
    }
    transition {
      storage_class = "INTELLIGENT_TIERING"
      days          = 7
    }
  }
}

###########################
### CloudFront Origin Access Control
###########################

resource "aws_cloudfront_origin_access_control" "ui_s3" {
  name                              = "${var.DeployName}-ui-s3-oac"
  description                       = "Origin Access Control for UI S3 bucket"
  origin_access_control_origin_type = "s3"
  signing_behavior                  = "always"
  signing_protocol                  = "sigv4"
}

###########################
### CloudFront Distribution
###########################

resource "aws_cloudfront_distribution" "ui" {
  enabled             = true
  is_ipv6_enabled     = true
  comment             = "${var.DeployName} UI Distribution"
  default_root_object = "index.html"
  price_class         = "PriceClass_100"

  aliases = [var.UIDomainName]

  origin {
    domain_name              = aws_s3_bucket.s3_instance.bucket_regional_domain_name
    origin_id                = "S3-${aws_s3_bucket.s3_instance.id}"
    origin_access_control_id = aws_cloudfront_origin_access_control.ui_s3.id
    origin_path              = "/app"
  }

  default_cache_behavior {
    // TODO: If UI endpoints don't work, investigate this first
    allowed_methods  = ["GET", "HEAD", "OPTIONS"]
    cached_methods   = ["GET", "HEAD"]
    target_origin_id = "S3-${aws_s3_bucket.s3_instance.id}"

    forwarded_values {
      query_string = false
      cookies {
        forward = "none"
      }
    }

    viewer_protocol_policy = "redirect-to-https"
    min_ttl                = 0
    default_ttl            = 0
    max_ttl                = 0
    compress               = true
  }

  # SPA routing - return index.html for 404s
  custom_error_response {
    error_code         = 404
    response_code      = 200
    response_page_path = "/index.html"
  }

  restrictions {
    geo_restriction {
      restriction_type = "none"
    }
  }

  viewer_certificate {
    acm_certificate_arn      = data.aws_acm_certificate.CloudFrontCertificate.arn
    ssl_support_method       = "sni-only"
    minimum_protocol_version = "TLSv1.2_2021"
  }

  tags = {
    name       = "${var.DeployName}-ui-distribution"
    FmsEnabled = "True"
  }
}

###########################
### S3 Bucket Policy
###########################

resource "aws_s3_bucket_policy" "cloudfront_access" {
  bucket = aws_s3_bucket.s3_instance.id
  policy = data.aws_iam_policy_document.s3_policy.json
}

data "aws_iam_policy_document" "s3_policy" {
  # Allow CloudFront to access S3
  statement {
    sid     = "AllowCloudFrontServicePrincipal"
    actions = ["s3:GetObject"]
    resources = [
      "${aws_s3_bucket.s3_instance.arn}/*"
    ]
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["cloudfront.amazonaws.com"]
    }

    condition {
      test     = "StringEquals"
      variable = "AWS:SourceArn"
      values   = [aws_cloudfront_distribution.ui.arn]
    }
  }

  # Deny non-SSL requests
  statement {
    sid     = "DenyInsecureTransport"
    actions = ["s3:*"]
    resources = [
      "${aws_s3_bucket.s3_instance.arn}/*",
      aws_s3_bucket.s3_instance.arn
    ]
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }
}

# CloudFront requires certificates in us-east-1
data "aws_acm_certificate" "CloudFrontCertificate" {
  domain      = var.UIDomainName
  provider    = aws.us-east-1
  statuses    = ["ISSUED"]
  most_recent = true
}

####################
### Outputs
####################

output "app_url" {
  description = "URL to access the React app"
  value       = "https://${aws_cloudfront_distribution.ui.domain_name}"
}

#############################
### Initialization Values ###
#############################
terraform {
  required_version = "~> 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 6.8"
    }
  }
  backend "s3" {}
}

provider "aws" {
  region  = var.AWSRegion
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}

# CloudFront requires ACM certificates in us-east-1 region
provider "aws" {
  alias   = "us-east-1"
  region  = "us-east-1"
  profile = var.IsLocal ? var.LocalAWSProfile : null
  default_tags {
    tags = {
      contact     = var.TagContact
      appid       = var.TagAppId
      bu          = var.ProjectBu
      owner       = var.TagOwner
      technology  = var.TagTechnology
      service     = var.TagService
      environment = var.TagEnvironment
      project     = var.ProjectName
    }
  }
  ignore_tags {
    keys         = ["networktype", "carat_DateTagged", "isasg"]
    key_prefixes = ["c7n:", "carat_"]
  }
}
