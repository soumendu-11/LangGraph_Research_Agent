# Local terraform (IaC) tools for Enerdeq

These tools allow easy updates of Dev from the local machine, and generation of *.tfvars.json files to prepare Ansible roles.

## General Development Workflow

### To prepare a command window, run set-env.cmd:

>set-env {aws_env} {config_env}

(Eg. dev us.dev, qa us.qa or prod us.prod) 

### Then for infrastructure updates, run:

>terraform-init <module>

**IMPORTANT**: You **must** run this every time you modify a variable in a `config.yml` file. If the script fails because it cannot delete the existing `.terraform` folder, delete it manually and try again.

Then:

>terraform-plan <module>

>terraform-apply <module>

**NOTE**: If you run into permission errors when attempting to apply the plan, first ensure that all resources that support it  have a `name` tag associated. If that does not work, reach out to S&P internal to get help.

### For Ansible tf.vars.json update, run:

>update-deploy-vars <module>

Or, for all modules, run:

>run-all-init-update.cmd