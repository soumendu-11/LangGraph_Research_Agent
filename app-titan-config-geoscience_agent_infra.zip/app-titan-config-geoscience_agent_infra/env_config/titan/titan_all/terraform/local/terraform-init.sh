echo init.py titan-$TITAN_AWS_ENV $TITAN_CONFIG_ENV $1 $2
python3 init.py titan-$TITAN_AWS_ENV $TITAN_CONFIG_ENV $1 $2
