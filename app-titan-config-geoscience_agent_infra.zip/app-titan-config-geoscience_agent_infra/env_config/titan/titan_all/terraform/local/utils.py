import traceback
import sys
if __name__ == '__main__':
    import execute
else:
    from . import execute
import boto3
from botocore.exceptions import ClientError


def get_vpc_id(config, vpc_name):
    ec2_client = boto3.client('ec2', region_name=config['AWSRegion'])
    try:
        resp = ec2_client.describe_vpcs(
            Filters=[
                {
                    'Name': 'tag:Name',
                    'Values': [vpc_name]
                }
            ]
        )
    except:
        traceback.print_exc()
        sys.exit(1)
    if len(resp['Vpcs']) != 1:
        print('Cannot find VPC id with tag Name: ' + vpc_name)
        sys.exit(1)
    return resp['Vpcs'][0]['VpcId']


def get_subnet_id(config, vpc_name, subnet_name):
    vpc_id = get_vpc_id(config, vpc_name)
    ec2_client = boto3.client('ec2', region_name=config['AWSRegion'])
    try:
        resp = ec2_client.describe_subnets(
            Filters=[
                {
                    'Name': 'tag:Name',
                    'Values': [subnet_name]
                },
                {
                    'Name': 'vpc-id',
                    'Values': [vpc_id]
                }
            ]
        )
    except:
        traceback.print_exc()
        sys.exit(1)
    if len(resp['Subnets']) != 1:
        print('Cannot find subnet id in VPC: ' + vpc_name + ' with name: ' + subnet_name)
        sys.exit(1)
    return resp['Subnets'][0]['SubnetId']


def get_security_group_id(config, vpc_name, security_group_name):
    vpc_id = get_vpc_id(config, vpc_name)
    ec2_client = boto3.client('ec2', region_name=config['AWSRegion'])
    try:
        resp = ec2_client.describe_security_groups(
            Filters=[
                {
                    'Name': 'group-name',
                    'Values': [security_group_name]
                },
                {
                    'Name': 'vpc-id',
                    'Values': [vpc_id]
                }
            ]
        )
    except:
        traceback.print_exc()
        sys.exit(1)
    if len(resp['SecurityGroups']) != 1:
        print('Cannot find security group id in VPC: ' + vpc_name + ' with name: ' + security_group_name)
        sys.exit(1)
    return resp['SecurityGroups'][0]['GroupId']


def invoke_fargate_task(config, *argv):
    ecs_client = boto3.client('ecs', region_name=config['AWSRegion'])
    task_args = {
        'cluster': config['ContainerClusterName'],
        'launchType': 'FARGATE',
        'networkConfiguration': {
            'awsvpcConfiguration': {
                'assignPublicIp': 'DISABLED',
                'securityGroups': [
                    get_security_group_id(config, config['AppVPC'], config['InvokeSecurityGroup'])
                ],
                'subnets': [
                    get_subnet_id(config, config['AppVPC'], config['AppSubnet1']),
                    get_subnet_id(config, config['AppVPC'], config['AppSubnet2'])
                ]
            }
        },
        'taskDefinition': config['ContainerTaskDefName'],
        'propagateTags': 'TASK_DEFINITION',
        'overrides': {
            'containerOverrides': [
                {
                    'name': config['ContainerTaskDefName'],
                    'command': argv
                }
            ]
        }
    }
    return(ecs_client.run_task(**task_args))


def status_fargate_task(config, task_arn):
    ecs_client = boto3.client('ecs', region_name=config['AWSRegion'])
    return(ecs_client.describe_tasks(
        cluster=config['ContainerClusterName'],
        tasks=[
            task_arn
        ]
    ))


def ensure_ecr_exists(config, ecr_name):
    ecr_exists = True
    ecr_client = boto3.client('ecr', region_name=config['AWSRegion'])
    try:
        resp = ecr_client.describe_repositories(
            registryId=config['AWSAccountId'],
            repositoryNames=[
                ecr_name
            ]
        )
    except ClientError as err:
        if err.response['Error']['Code'] == 'RepositoryNotFoundException':
            ecr_exists = False
        else:
            traceback.print_exc()
            sys.exit(1)
    except:
        traceback.print_exc()
        sys.exit(1)
    if ecr_exists:
        print(ecr_name + ' already exists')
    else:
        print('Creating ' + ecr_name + '...')
        try:
            ecr_client.create_repository(
                repositoryName=ecr_name,
                imageTagMutability='IMMUTABLE',
                imageScanningConfiguration={
                    'scanOnPush': True
                },
                encryptionConfiguration={
                    'encryptionType': 'AES256'
                },
                tags=[
                    {
                        'Key': 'Contact',
                        'Value': config['TagContact']
                    },
                    {
                        'Key': 'Service',
                        'Value': config['TagService']
                    },
                    {
                        'Key': 'Environment',
                        'Value': config['TagEnvironment']
                    },
                    {
                        'Key': 'OrgID',
                        'Value': config['TagOrgID']
                    },
                    {
                        'Key': 'Capacity',
                        'Value': config['TagCapacity']
                    },
                    {
                        'Key': 'DeployedBy',
                        'Value': config['TagDeployedBy']
                    },
                    {
                        'Key': 'RepoURL',
                        'Value': config['TagRepoURL']
                    }
                ]
            )
        except:
            traceback.print_exc()
            sys.exit(1)
        print('Done')


if __name__ == '__main__':
    # os.environ['AWS_PROFILE'] = 'default'
    if sys.argv[1] == 'ensure-ecr':
        config_dirs = sys.argv[2].split(',')
        config = execute.read_config(config_dirs, sys.argv[3])
        ensure_ecr_exists(config, sys.argv[4])
    else:
        print('USAGE: Error')
        sys.exit(1)
