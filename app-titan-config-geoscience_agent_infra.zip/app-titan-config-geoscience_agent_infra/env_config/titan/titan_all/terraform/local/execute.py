import os
import shlex
import subprocess
import yaml
import json
import sys


def cli(cmd, cwd=None):
    command = shlex.split(cmd)
    retval = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=cwd)
    while True:
        line = retval.stdout.readline().rstrip()
        print(line)
        if not line and retval.poll() is not None:
            break
    if retval.returncode != 0:
        raise subprocess.CalledProcessError(retval.returncode, cmd)


def generate_tfvars_json(config_dirs, env, output_json, **kwargs):
    print(os.getcwd())
    if os.path.exists(output_json):
        print('Removing old tf vars file')
        os.remove(output_json)
    tf_vars = read_config(config_dirs, env)
    tf_vars.update(kwargs)
    with open(output_json, 'w') as json_vars_file:
        json.dump(tf_vars, json_vars_file)
    return tf_vars


def append_array_tfvars_json(input_json, variable, *args):
    with open(input_json, 'rt') as json_file:
        tf_vars = json.load(json_file)
    tf_vars[variable] = args
    with open(input_json, 'w') as json_file:
        json.dump(tf_vars, json_file)


def read_config(config_dirs, env):
    retval = {}
    for config_dir in config_dirs:
        # Load in global config
        global_config_path = os.path.join(config_dir, 'config.yml')
        if os.path.exists(global_config_path):
            print('Loading global config from  ' + global_config_path)
            with open(global_config_path, 'rt') as global_config_file:
                global_variables = yaml.load(global_config_file, Loader=yaml.FullLoader)
            retval.update(global_variables['variables'])
        else:
            print('ERROR: Missing global config from  ' + global_config_path + '?')
        # Load in env config
        env_config_path = os.path.join(config_dir, 'config.' + env + '.yml')
        if os.path.exists(env_config_path):
            print('Loading env specific config from  ' + env_config_path)
            with open(env_config_path, 'rt') as env_config_file:
                env_variables = yaml.load(env_config_file, Loader=yaml.FullLoader)
            retval.update(env_variables['variables'])
    # Handle nested variables
    for var in retval:
        if isinstance(retval[var], str):  # Only process string values
            for nest_var in retval:
                if isinstance(retval[nest_var], str):  # Only replace with string values
                    retval[var] = retval[var].replace('$(' + nest_var + ')', retval[nest_var])
    return retval


if __name__ == '__main__':
    if sys.argv[1] == 'generate':
        config_dirs = sys.argv[2].split(',')
        generate_tfvars_json(config_dirs, sys.argv[3], sys.argv[4], **dict(arg.split('=') for arg in sys.argv[5:]))
    elif sys.argv[1] == 'append':
        append_array_tfvars_json(sys.argv[2], sys.argv[3], *list(sys.argv[4:]))
    else:
        print('USAGE: Error')
        sys.exit(1)
