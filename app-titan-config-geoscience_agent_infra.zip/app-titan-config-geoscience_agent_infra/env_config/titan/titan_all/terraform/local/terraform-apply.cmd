@ECHO OFF
SET COMPONENT=%1
PUSHD ..\..\%COMPONENT%
terraform apply tfplan
POPD
