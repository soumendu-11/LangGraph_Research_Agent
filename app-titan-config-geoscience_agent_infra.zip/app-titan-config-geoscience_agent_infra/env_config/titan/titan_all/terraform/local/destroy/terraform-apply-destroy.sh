#!/bin/bash

set -euo pipefail

MODULE=${1:-}

if [[ -z "$MODULE" ]]; then
  echo "Usage: $(basename "$0") <component>"
  exit 1
fi

read -r -p "ARE YOU SURE YOU WANT TO DESTROY ALL AWS RESOURCES FOR COMPONENT ${MODULE}!? [y/N] " CONFIRM
if [[ ! "$CONFIRM" =~ ^[Yy]$ ]]; then
  exit 0
fi

pushd "../../${MODULE}" > /dev/null
terraform apply --destroy
popd > /dev/null
