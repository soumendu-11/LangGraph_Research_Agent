@ECHO OFF
SET COMPONENT=%1

choice /c YN /m "ARE YOU SURE YOU WANT TO DESTROY ALL AWS RESOURCES FOR COMPONENT %COMPONENT%!?"
if %ERRORLEVEL% equ 1 goto :continue
if %ERRORLEVEL% equ 2 goto :eof

:continue
PUSHD ..\..\%COMPONENT%
terraform apply --destroy
POPD
pause
