#!/bin/bash

set -euo pipefail

MODULE=${1:-}

if [[ -z "$MODULE" ]]; then
  echo "Usage: $(basename "$0") <component>"
  exit 1
fi

pushd "../../${MODULE}" > /dev/null
terraform plan -destroy
popd > /dev/null
