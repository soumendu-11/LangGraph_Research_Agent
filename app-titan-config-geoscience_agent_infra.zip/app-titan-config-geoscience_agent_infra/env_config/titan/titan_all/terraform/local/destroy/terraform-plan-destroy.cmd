@ECHO OFF
SET COMPONENT=%1
PUSHD ..\..\%COMPONENT%
terraform plan -destroy
POPD
pause
