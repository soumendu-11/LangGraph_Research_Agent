#!/bin/bash

# Runs terraform init and update-deploy-vars for each component directory.
# Skips non-component config files and the local folder itself.

set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/.."  # Now in .../terraform
echo `pwd`

EXCLUDE=(local config.yml config.us.qa.yml config.dev.yml qa-only dev-only)

is_excluded() {
    local name="$1"
    for e in "${EXCLUDE[@]}"; do
        if [[ "$e" == "$name" ]]; then
            return 0
        fi
    done
    return 1
}

for d in */; do
    d="${d%/}"
    echo $d
    if is_excluded "$d"; then
        echo "Skipping excluded directory $d"
        continue
    fi
    echo "==================================================="
    echo "Processing component: $d"
    echo "--------------------------------------------------"
    pushd local > /dev/null
    echo `pwd`
    echo "Running terraform-init for $d"
    source terraform-init.sh "$d" SKIP_TF_INIT
    echo "Updating deploy vars for $d"
    source update-deploy-vars.sh "$d"
    popd > /dev/null
done

echo "Done."