py ..\init.py titan-%TITAN_AWS_ENV% %TITAN_CONFIG_ENV% %1 %~2
