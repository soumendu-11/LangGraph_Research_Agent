#!/bin/bash

export MODULE=$1
export OUT_TFVARS=../../../titan_us_$TITAN_AWS_ENV/terraform/$MODULE.tfvars.json
cp ../$MODULE/terraform.tfvars.json $OUT_TFVARS
sed -i.bu 's/\"IsLocal\": \"true\",/\"IsLocal\": \"false\",/' $OUT_TFVARS
