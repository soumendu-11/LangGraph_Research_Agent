@ECHO OFF
SET COMPONENT=%1
SET OUT_TFVARS=..\..\..\titan_us_%TITAN_AWS_ENV%\terraform\%COMPONENT%.tfvars.json
copy ..\%COMPONENT%\terraform.tfvars.json %OUT_TFVARS%
powershell -Command "(gc %OUT_TFVARS%) -replace '\"IsLocal\": \"true\",', '\"IsLocal\": \"false\",' | Out-File -encoding ASCII %OUT_TFVARS%"
