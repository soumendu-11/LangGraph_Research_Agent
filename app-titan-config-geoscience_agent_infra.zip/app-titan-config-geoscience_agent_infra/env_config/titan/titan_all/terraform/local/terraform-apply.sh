#!/bin/bash

export MODULE=$1
pushd ../$MODULE
terraform apply tfplan
popd