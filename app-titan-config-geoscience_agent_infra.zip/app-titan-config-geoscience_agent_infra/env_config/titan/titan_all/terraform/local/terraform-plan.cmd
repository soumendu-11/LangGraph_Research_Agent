@ECHO OFF
SET COMPONENT=%1
PUSHD ..\%COMPONENT%
terraform plan -out=tfplan
POPD
