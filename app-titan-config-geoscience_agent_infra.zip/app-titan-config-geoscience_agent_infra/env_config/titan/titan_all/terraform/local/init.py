import sys
import os
import shutil
import execute


DEFAULT_PROFILE = 'default'


def init():
    # Get input values from Command line or user (interactive)
    aws_profile = None
    generic = None
    env = None
    if len(sys.argv) > 1:
        aws_profile = sys.argv[1]
    else:
        aws_profile = input('Enter AWS backend profile (hit ENTER to use ' + DEFAULT_PROFILE + '): ')
        if aws_profile == '':
            aws_profile = DEFAULT_PROFILE
    if len(sys.argv) > 2:
        env = sys.argv[2]
    else:
        env = input("Enter Environment: ")
    if len(sys.argv) > 3:
        generic = sys.argv[3]
    else:
        generic = input("Enter Component: ")
    # Delete previous files
    destPath = os.path.join('..', generic)
    tfLockFile = os.path.join(destPath, '.terraform.lock.hcl')
    tfStateDir = os.path.join(destPath, '.terraform')
    tfVarsFile = os.path.join(destPath, 'terraform.tfvars.json')
    if os.path.exists(tfLockFile) or os.path.exists(tfStateDir) or os.path.exists(tfVarsFile):
        print('Removing old state files')
        if os.path.exists(tfLockFile): os.remove(tfLockFile)
        if os.path.exists(tfStateDir): shutil.rmtree(tfStateDir)
        if os.path.exists(tfVarsFile): os.remove(tfVarsFile)
    # Build variables input file
    tf_vars = execute.generate_tfvars_json([os.path.join('..'), os.path.join('..', generic)], env, os.path.join('..', generic, 'terraform.tfvars.json'), IsLocal='true')

    # Initialize  Terraform
    if len(sys.argv) > 4 and sys.argv[4] == 'SKIP_TF_INIT':
        print('WARNING: Skipping Terraform backend init. Merging variables only.')
    else:
        execute.cli('terraform init -input=false' +
                    ' -backend-config=bucket=' + tf_vars['AWSAppStateBucket'] +
                    ' -backend-config=key=' + tf_vars['AWSAppStateKey'] +
                    ' -backend-config=region=' + tf_vars['AWSAppStateRegion'] +
                    ' -backend-config=profile=' + aws_profile,
                    #' -backend-config=profile=' + aws_profile +
                    #' -backend-config=dynamodb_table=' + tf_vars['AWSAppStateDynamoDBTable'],
                    cwd=os.path.join('..', generic))
    print('Done')
if __name__ == '__main__':
    init()
