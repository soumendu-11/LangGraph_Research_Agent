@ECHO OFF
REM Runs terraform init and update-deploy-vars for each component directory.
REM Skips non-component config files and the local folder itself.

SETLOCAL ENABLEDELAYEDEXPANSION
SET SCRIPT_DIR=%~dp0
PUSHD %SCRIPT_DIR%..
REM Now in ...\terraform

SET EXCLUDE=local config.yml config.us.qa.yml config.dev.yml qa-only dev-only

FOR /D %%D IN (*) DO (
    CALL :IS_EXCLUDED %%D
    IF !IS_SKIP! NEQ 1 (
        ECHO ==================================================
        ECHO Processing component: %%D
        ECHO --------------------------------------------------
        PUSHD local
        ECHO Running terraform-init for %%D
        CALL terraform-init.cmd %%D SKIP_TF_INIT
        ECHO Updating deploy vars for %%D
        CALL update-deploy-vars.cmd %%D
        POPD
    ) ELSE (
        ECHO Skipping excluded directory %%D
    )
)

POPD
ECHO Done.
GOTO :EOF

:IS_EXCLUDED
SET NAME=%1
SET IS_SKIP=0
FOR %%E IN (%EXCLUDE%) DO (
    IF /I "%%E"=="%NAME%" SET IS_SKIP=1
)
GOTO :EOF
