#!/bin/bash

export MODULE=$1
pushd ../$MODULE
terraform plan -out=tfplan
popd